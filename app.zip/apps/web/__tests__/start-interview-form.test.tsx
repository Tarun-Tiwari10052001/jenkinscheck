import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { StartInterviewForm } from '@/components/start-interview-form';
import { interviewsApi, ApiError } from '@/lib/api-client';

const pushMock = jest.fn();
jest.mock('next/navigation', () => ({
  useRouter: () => ({ push: pushMock }),
}));

jest.mock('@/lib/api-client', () => {
  const actual = jest.requireActual('@/lib/api-client');
  return { ...actual, interviewsApi: { start: jest.fn(), list: jest.fn(), get: jest.fn(), answer: jest.fn(), complete: jest.fn() } };
});

const startMock = interviewsApi.start as jest.Mock;

describe('StartInterviewForm', () => {
  beforeEach(() => jest.clearAllMocks());

  it('rejects a role shorter than 2 characters without calling the API', async () => {
    render(<StartInterviewForm />);

    fireEvent.change(screen.getByLabelText('Role'), { target: { value: 'A' } });
    fireEvent.click(screen.getByRole('button', { name: /start interview/i }));

    expect(await screen.findByRole('alert')).toHaveTextContent('role you want to practice');
    expect(startMock).not.toHaveBeenCalled();
  });

  it('starts the interview and redirects to its chat page, with company optional', async () => {
    startMock.mockResolvedValue({
      session: { id: 'session-1', role: 'Backend Engineer', company: null, status: 'IN_PROGRESS', score: null, createdAt: '', completedAt: null },
      question: 'Tell me about yourself.',
    });

    render(<StartInterviewForm />);

    fireEvent.change(screen.getByLabelText('Role'), { target: { value: 'Backend Engineer' } });
    fireEvent.click(screen.getByRole('button', { name: /start interview/i }));

    await waitFor(() => expect(pushMock).toHaveBeenCalledWith('/interview/session-1'));
    expect(startMock).toHaveBeenCalledWith({ role: 'Backend Engineer', company: undefined });
  });

  it('trims the role and passes company when provided', async () => {
    startMock.mockResolvedValue({
      session: { id: 'session-2', role: 'Backend Engineer', company: 'Acme', status: 'IN_PROGRESS', score: null, createdAt: '', completedAt: null },
      question: 'Q1',
    });

    render(<StartInterviewForm />);

    fireEvent.change(screen.getByLabelText('Role'), { target: { value: '  Backend Engineer  ' } });
    fireEvent.change(screen.getByLabelText('Company (optional)'), { target: { value: 'Acme' } });
    fireEvent.click(screen.getByRole('button', { name: /start interview/i }));

    await waitFor(() =>
      expect(startMock).toHaveBeenCalledWith({ role: 'Backend Engineer', company: 'Acme' }),
    );
  });

  it('shows the API error message when starting fails', async () => {
    startMock.mockRejectedValue(new ApiError(500, 'Could not start the interview. Please try again.'));

    render(<StartInterviewForm />);

    fireEvent.change(screen.getByLabelText('Role'), { target: { value: 'Backend Engineer' } });
    fireEvent.click(screen.getByRole('button', { name: /start interview/i }));

    expect(await screen.findByRole('alert')).toHaveTextContent('Could not start the interview');
    expect(pushMock).not.toHaveBeenCalled();
  });
});
