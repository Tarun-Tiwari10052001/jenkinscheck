import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { ResumeDetail } from '@/components/resume-detail';
import { resumesApi, ApiError } from '@/lib/api-client';

const pushMock = jest.fn();
jest.mock('next/navigation', () => ({
  useRouter: () => ({ push: pushMock }),
}));

jest.mock('@/lib/api-client', () => {
  const actual = jest.requireActual('@/lib/api-client');
  return {
    ...actual,
    resumesApi: { create: jest.fn(), list: jest.fn(), get: jest.fn(), remove: jest.fn(), tailor: jest.fn(), coverLetter: jest.fn() },
  };
});

const getMock = resumesApi.get as jest.Mock;
const tailorMock = resumesApi.tailor as jest.Mock;
const coverLetterMock = resumesApi.coverLetter as jest.Mock;
const removeMock = resumesApi.remove as jest.Mock;

const longJobDescription = 'We are hiring a backend engineer with Kubernetes experience. '.repeat(3);

const baseResume = {
  id: 'resume-1',
  content: 'Experienced backend engineer with 5 years building distributed systems.',
  latestFeedback: '{"score": 82, "strengths": ["Clear impact"], "improvements": ["Add a summary"]}',
  createdAt: '',
  updatedAt: '',
};

describe('ResumeDetail', () => {
  beforeEach(() => jest.clearAllMocks());

  it('shows a loading state, then the parsed feedback', async () => {
    getMock.mockResolvedValue(baseResume);

    render(<ResumeDetail resumeId="resume-1" />);

    expect(screen.getByText(/loading resume/i)).toBeInTheDocument();
    expect(await screen.findByText('Clear impact')).toBeInTheDocument();
    expect(screen.getByText('82')).toBeInTheDocument();
    expect(screen.getByText('Add a summary')).toBeInTheDocument();
  });

  it('falls back to raw feedback text when it is not valid JSON', async () => {
    getMock.mockResolvedValue({ ...baseResume, latestFeedback: 'Could not evaluate this resume.' });

    render(<ResumeDetail resumeId="resume-1" />);

    expect(await screen.findByText('Could not evaluate this resume.')).toBeInTheDocument();
  });

  it('shows an error when the resume fails to load', async () => {
    getMock.mockRejectedValue(new ApiError(404, 'Resume not found.'));

    render(<ResumeDetail resumeId="missing" />);

    expect(await screen.findByRole('alert')).toHaveTextContent('Resume not found.');
  });

  it('rejects a tailor request with a job description shorter than 50 characters', async () => {
    getMock.mockResolvedValue(baseResume);
    render(<ResumeDetail resumeId="resume-1" />);
    await screen.findByText('Clear impact');

    fireEvent.change(screen.getByLabelText('Job description', { selector: '#tailor-jd' }), {
      target: { value: 'too short' },
    });
    fireEvent.click(screen.getByRole('button', { name: /compare to this job/i }));

    expect(await screen.findByRole('alert')).toHaveTextContent('at least 50 characters');
    expect(tailorMock).not.toHaveBeenCalled();
  });

  it('shows the tailor match result on success', async () => {
    getMock.mockResolvedValue(baseResume);
    tailorMock.mockResolvedValue({
      matchScore: 61,
      missingKeywords: ['Kubernetes'],
      suggestions: ['Mention container orchestration'],
    });

    render(<ResumeDetail resumeId="resume-1" />);
    await screen.findByText('Clear impact');

    fireEvent.change(screen.getByLabelText('Job description', { selector: '#tailor-jd' }), {
      target: { value: longJobDescription },
    });
    fireEvent.click(screen.getByRole('button', { name: /compare to this job/i }));

    expect(await screen.findByText('Kubernetes')).toBeInTheDocument();
    expect(screen.getByText('Mention container orchestration')).toBeInTheDocument();
    expect(tailorMock).toHaveBeenCalledWith('resume-1', longJobDescription.trim());
  });

  it('generates and displays a cover letter', async () => {
    getMock.mockResolvedValue(baseResume);
    coverLetterMock.mockResolvedValue({ content: 'Dear Hiring Manager, I am excited to apply...' });

    render(<ResumeDetail resumeId="resume-1" />);
    await screen.findByText('Clear impact');

    fireEvent.change(screen.getByLabelText('Role'), { target: { value: 'Backend Engineer' } });
    fireEvent.change(screen.getByLabelText('Company'), { target: { value: 'Acme' } });
    fireEvent.change(screen.getByLabelText('Job description', { selector: '#cover-jd' }), {
      target: { value: longJobDescription },
    });
    fireEvent.click(screen.getByRole('button', { name: /generate cover letter/i }));

    expect(await screen.findByText(/Dear Hiring Manager/)).toBeInTheDocument();
    expect(coverLetterMock).toHaveBeenCalledWith('resume-1', {
      jobDescription: longJobDescription.trim(),
      company: 'Acme',
      role: 'Backend Engineer',
    });
  });

  it('requires a two-step confirmation before deleting, then redirects to the dashboard', async () => {
    getMock.mockResolvedValue(baseResume);
    removeMock.mockResolvedValue(undefined);

    render(<ResumeDetail resumeId="resume-1" />);
    await screen.findByText('Clear impact');

    fireEvent.click(screen.getByRole('button', { name: /^delete$/i }));
    expect(removeMock).not.toHaveBeenCalled();

    fireEvent.click(screen.getByRole('button', { name: /yes, delete/i }));

    await waitFor(() => expect(removeMock).toHaveBeenCalledWith('resume-1'));
    await waitFor(() => expect(pushMock).toHaveBeenCalledWith('/dashboard'));
  });

  it('cancels the delete confirmation without calling the API', async () => {
    getMock.mockResolvedValue(baseResume);

    render(<ResumeDetail resumeId="resume-1" />);
    await screen.findByText('Clear impact');

    fireEvent.click(screen.getByRole('button', { name: /^delete$/i }));
    fireEvent.click(screen.getByRole('button', { name: /cancel/i }));

    expect(removeMock).not.toHaveBeenCalled();
    expect(screen.getByRole('button', { name: /^delete$/i })).toBeInTheDocument();
  });
});
