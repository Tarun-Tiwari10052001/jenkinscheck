import { render, screen, fireEvent, waitFor, act } from '@testing-library/react';
import { InterviewChat } from '@/components/interview-chat';
import { interviewsApi, ApiError } from '@/lib/api-client';
import {
  isSpeechRecognitionSupported,
  isSpeechSynthesisSupported,
  createSpeechRecognition,
  speak,
  cancelSpeech,
} from '@/lib/speech';

const pushMock = jest.fn();
jest.mock('next/navigation', () => ({
  useRouter: () => ({ push: pushMock }),
}));

jest.mock('@/lib/api-client', () => {
  const actual = jest.requireActual('@/lib/api-client');
  return {
    ...actual,
    interviewsApi: { start: jest.fn(), list: jest.fn(), get: jest.fn(), answer: jest.fn(), complete: jest.fn() },
  };
});

jest.mock('@/lib/speech', () => ({
  isSpeechRecognitionSupported: jest.fn(),
  isSpeechSynthesisSupported: jest.fn(),
  createSpeechRecognition: jest.fn(),
  speak: jest.fn(),
  cancelSpeech: jest.fn(),
}));

const getMock = interviewsApi.get as jest.Mock;
const answerMock = interviewsApi.answer as jest.Mock;
const completeMock = interviewsApi.complete as jest.Mock;

const isSpeechRecognitionSupportedMock = isSpeechRecognitionSupported as jest.Mock;
const isSpeechSynthesisSupportedMock = isSpeechSynthesisSupported as jest.Mock;
const createSpeechRecognitionMock = createSpeechRecognition as jest.Mock;
const speakMock = speak as jest.Mock;
const cancelSpeechMock = cancelSpeech as jest.Mock;

const inProgressSession = {
  id: 'session-1',
  role: 'Backend Engineer',
  company: 'Acme',
  status: 'IN_PROGRESS' as const,
  score: null,
  feedback: null,
  createdAt: '',
  completedAt: null,
  messages: [
    { id: 'm1', role: 'INTERVIEWER' as const, content: 'Tell me about yourself.', sequenceNumber: 1 },
  ],
};

describe('InterviewChat', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    // Default: no browser speech support, matching real jsdom behavior —
    // individual voice-mode tests opt into support explicitly.
    isSpeechRecognitionSupportedMock.mockReturnValue(false);
    isSpeechSynthesisSupportedMock.mockReturnValue(false);
    createSpeechRecognitionMock.mockReturnValue(null);
  });

  it('shows a loading state, then the opening question', async () => {
    getMock.mockResolvedValue(inProgressSession);

    render(<InterviewChat sessionId="session-1" />);

    expect(screen.getByText(/loading interview/i)).toBeInTheDocument();
    expect(await screen.findByText('Tell me about yourself.')).toBeInTheDocument();
    expect(screen.getByRole('heading', { name: /backend engineer at acme/i })).toBeInTheDocument();
  });

  it('disables "end interview" until at least one question has been answered', async () => {
    getMock.mockResolvedValue(inProgressSession);

    render(<InterviewChat sessionId="session-1" />);

    const endButton = await screen.findByRole('button', { name: /end interview/i });
    expect(endButton).toBeDisabled();
  });

  it('shows a validation error and does not call the API for an empty answer', async () => {
    getMock.mockResolvedValue(inProgressSession);
    render(<InterviewChat sessionId="session-1" />);
    await screen.findByText('Tell me about yourself.');

    fireEvent.click(screen.getByRole('button', { name: /send answer/i }));

    expect(await screen.findByRole('alert')).toHaveTextContent('Enter an answer');
    expect(answerMock).not.toHaveBeenCalled();
  });

  it('submits an answer and appends the next question', async () => {
    getMock.mockResolvedValue(inProgressSession);
    answerMock.mockResolvedValue({
      question: 'What was the hardest bug you fixed?',
      questionCount: 2,
      suggestWrapUp: false,
    });

    render(<InterviewChat sessionId="session-1" />);
    await screen.findByText('Tell me about yourself.');

    fireEvent.change(screen.getByLabelText('Your answer'), {
      target: { value: 'I led a migration that reduced latency by 40%.' },
    });
    fireEvent.click(screen.getByRole('button', { name: /send answer/i }));

    expect(await screen.findByText('I led a migration that reduced latency by 40%.')).toBeInTheDocument();
    expect(await screen.findByText('What was the hardest bug you fixed?')).toBeInTheDocument();
    expect(answerMock).toHaveBeenCalledWith('session-1', 'I led a migration that reduced latency by 40%.');
  });

  it('enables "end interview" after an answer has been sent, and shows feedback on completion', async () => {
    getMock.mockResolvedValue(inProgressSession);
    answerMock.mockResolvedValue({ question: 'Next question?', questionCount: 2, suggestWrapUp: false });
    completeMock.mockResolvedValue({
      ...inProgressSession,
      status: 'COMPLETED',
      score: 88,
      feedback: JSON.stringify({
        score: 88,
        strengths: ['Clear examples'],
        improvements: ['Quantify impact more'],
      }),
    });

    render(<InterviewChat sessionId="session-1" />);
    await screen.findByText('Tell me about yourself.');

    fireEvent.change(screen.getByLabelText('Your answer'), { target: { value: 'My answer.' } });
    fireEvent.click(screen.getByRole('button', { name: /send answer/i }));
    await screen.findByText('Next question?');

    const endButton = screen.getByRole('button', { name: /end interview/i });
    expect(endButton).not.toBeDisabled();
    fireEvent.click(endButton);

    expect(await screen.findByText('Feedback')).toBeInTheDocument();
    expect(screen.getByText('88')).toBeInTheDocument();
    expect(screen.getByText('Clear examples')).toBeInTheDocument();
    expect(screen.getByText('Quantify impact more')).toBeInTheDocument();
  });

  it('falls back to raw feedback text when the stored feedback is not valid JSON', async () => {
    getMock.mockResolvedValue({
      ...inProgressSession,
      status: 'COMPLETED',
      feedback: 'Could not evaluate this interview.',
      score: null,
    });

    render(<InterviewChat sessionId="session-1" />);

    expect(await screen.findByText('Could not evaluate this interview.')).toBeInTheDocument();
  });

  it('shows an error message when loading the session fails', async () => {
    getMock.mockRejectedValue(new ApiError(404, 'Interview session not found.'));

    render(<InterviewChat sessionId="missing" />);

    expect(await screen.findByRole('alert')).toHaveTextContent('Interview session not found.');
  });

  describe('voice mode', () => {
    it('does not show the voice mode toggle when speech synthesis is unsupported', async () => {
      getMock.mockResolvedValue(inProgressSession);

      render(<InterviewChat sessionId="session-1" />);
      await screen.findByText('Tell me about yourself.');

      expect(screen.queryByLabelText('Voice mode')).not.toBeInTheDocument();
    });

    it('shows the voice mode toggle when speech synthesis is supported', async () => {
      isSpeechSynthesisSupportedMock.mockReturnValue(true);
      getMock.mockResolvedValue(inProgressSession);

      render(<InterviewChat sessionId="session-1" />);
      await screen.findByText('Tell me about yourself.');

      expect(screen.getByLabelText('Voice mode')).toBeInTheDocument();
    });

    it('speaks the current question when voice mode is turned on', async () => {
      isSpeechSynthesisSupportedMock.mockReturnValue(true);
      getMock.mockResolvedValue(inProgressSession);

      render(<InterviewChat sessionId="session-1" />);
      await screen.findByText('Tell me about yourself.');

      fireEvent.click(screen.getByLabelText('Voice mode'));

      expect(speakMock).toHaveBeenCalledWith('Tell me about yourself.', expect.any(Object));
    });

    it('speaks each new question as it arrives once voice mode is on', async () => {
      isSpeechSynthesisSupportedMock.mockReturnValue(true);
      getMock.mockResolvedValue(inProgressSession);
      answerMock.mockResolvedValue({ question: 'Next question?', questionCount: 2, suggestWrapUp: false });

      render(<InterviewChat sessionId="session-1" />);
      await screen.findByText('Tell me about yourself.');
      fireEvent.click(screen.getByLabelText('Voice mode'));
      speakMock.mockClear();

      fireEvent.change(screen.getByLabelText('Your answer'), { target: { value: 'My answer.' } });
      fireEvent.click(screen.getByRole('button', { name: /send answer/i }));
      await screen.findByText('Next question?');

      expect(speakMock).toHaveBeenCalledWith('Next question?', expect.any(Object));
    });

    it('does not re-speak the same question on unrelated re-renders', async () => {
      isSpeechSynthesisSupportedMock.mockReturnValue(true);
      getMock.mockResolvedValue(inProgressSession);

      render(<InterviewChat sessionId="session-1" />);
      await screen.findByText('Tell me about yourself.');
      fireEvent.click(screen.getByLabelText('Voice mode'));
      expect(speakMock).toHaveBeenCalledTimes(1);

      fireEvent.change(screen.getByLabelText('Your answer'), { target: { value: 'typing...' } });

      expect(speakMock).toHaveBeenCalledTimes(1);
    });

    it('cancels speech when voice mode is turned back off', async () => {
      isSpeechSynthesisSupportedMock.mockReturnValue(true);
      getMock.mockResolvedValue(inProgressSession);

      render(<InterviewChat sessionId="session-1" />);
      await screen.findByText('Tell me about yourself.');

      const toggle = screen.getByLabelText('Voice mode');
      fireEvent.click(toggle);
      fireEvent.click(toggle);

      expect(cancelSpeechMock).toHaveBeenCalled();
    });

    it('shows a fallback note instead of a mic button when recognition is unsupported', async () => {
      isSpeechSynthesisSupportedMock.mockReturnValue(true);
      isSpeechRecognitionSupportedMock.mockReturnValue(false);
      getMock.mockResolvedValue(inProgressSession);

      render(<InterviewChat sessionId="session-1" />);
      await screen.findByText('Tell me about yourself.');
      fireEvent.click(screen.getByLabelText('Voice mode'));

      expect(screen.queryByRole('button', { name: /speak your answer/i })).not.toBeInTheDocument();
      expect(screen.getByText(/voice input isn.t supported/i)).toBeInTheDocument();
    });

    it('fills the answer field from a speech transcript, and stops on request', async () => {
      isSpeechSynthesisSupportedMock.mockReturnValue(true);
      isSpeechRecognitionSupportedMock.mockReturnValue(true);
      const startMock = jest.fn();
      const stopMock = jest.fn();
      createSpeechRecognitionMock.mockReturnValue({ start: startMock, stop: stopMock });
      getMock.mockResolvedValue(inProgressSession);

      render(<InterviewChat sessionId="session-1" />);
      await screen.findByText('Tell me about yourself.');
      fireEvent.click(screen.getByLabelText('Voice mode'));

      fireEvent.click(screen.getByRole('button', { name: /speak your answer/i }));
      expect(startMock).toHaveBeenCalledTimes(1);

      const callbacks = createSpeechRecognitionMock.mock.calls[0][0];
      act(() => {
        callbacks.onResult({ transcript: 'I led a migration that reduced latency.', isFinal: true });
      });

      expect(screen.getByLabelText('Your answer')).toHaveValue('I led a migration that reduced latency.');

      fireEvent.click(screen.getByRole('button', { name: /stop/i }));
      expect(stopMock).toHaveBeenCalledTimes(1);
    });

    it('shows an error message when speech recognition reports an error', async () => {
      isSpeechSynthesisSupportedMock.mockReturnValue(true);
      isSpeechRecognitionSupportedMock.mockReturnValue(true);
      createSpeechRecognitionMock.mockReturnValue({ start: jest.fn(), stop: jest.fn() });
      getMock.mockResolvedValue(inProgressSession);

      render(<InterviewChat sessionId="session-1" />);
      await screen.findByText('Tell me about yourself.');
      fireEvent.click(screen.getByLabelText('Voice mode'));
      fireEvent.click(screen.getByRole('button', { name: /speak your answer/i }));

      const callbacks = createSpeechRecognitionMock.mock.calls[0][0];
      act(() => {
        callbacks.onError('no-speech');
      });

      expect(await screen.findByRole('alert')).toHaveTextContent('Voice input error: no-speech');
    });

    it('cancels any in-progress speech before starting to listen, to avoid audio overlap', async () => {
      isSpeechSynthesisSupportedMock.mockReturnValue(true);
      isSpeechRecognitionSupportedMock.mockReturnValue(true);
      createSpeechRecognitionMock.mockReturnValue({ start: jest.fn(), stop: jest.fn() });
      getMock.mockResolvedValue(inProgressSession);

      render(<InterviewChat sessionId="session-1" />);
      await screen.findByText('Tell me about yourself.');
      fireEvent.click(screen.getByLabelText('Voice mode'));
      cancelSpeechMock.mockClear();

      fireEvent.click(screen.getByRole('button', { name: /speak your answer/i }));

      expect(cancelSpeechMock).toHaveBeenCalled();
    });
  });
});
