import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { ResumeUploadForm } from '@/components/resume-upload-form';
import { resumesApi, ApiError } from '@/lib/api-client';

const pushMock = jest.fn();
jest.mock('next/navigation', () => ({
  useRouter: () => ({ push: pushMock }),
}));

jest.mock('@/lib/api-client', () => {
  const actual = jest.requireActual('@/lib/api-client');
  return {
    ...actual,
    resumesApi: { create: jest.fn(), list: jest.fn(), get: jest.fn(), remove: jest.fn(), tailor: jest.fn(), coverLetter: jest.fn() },
  };
});

const createMock = resumesApi.create as jest.Mock;
const longText = 'Experienced backend engineer. '.repeat(5);

describe('ResumeUploadForm', () => {
  beforeEach(() => jest.clearAllMocks());

  it('rejects resume text shorter than 50 characters without calling the API', async () => {
    render(<ResumeUploadForm />);

    fireEvent.change(screen.getByLabelText('Paste your resume text'), { target: { value: 'too short' } });
    fireEvent.click(screen.getByRole('button', { name: /get feedback/i }));

    expect(await screen.findByRole('alert')).toHaveTextContent('at least 50 characters');
    expect(createMock).not.toHaveBeenCalled();
  });

  it('creates the resume and redirects to its detail page', async () => {
    createMock.mockResolvedValue({ id: 'resume-1', content: longText, latestFeedback: null, createdAt: '', updatedAt: '' });

    render(<ResumeUploadForm />);

    fireEvent.change(screen.getByLabelText('Paste your resume text'), { target: { value: longText } });
    fireEvent.click(screen.getByRole('button', { name: /get feedback/i }));

    await waitFor(() => expect(pushMock).toHaveBeenCalledWith('/resume/resume-1'));
    expect(createMock).toHaveBeenCalledWith(longText.trim());
  });

  it('shows the API error message when saving fails', async () => {
    createMock.mockRejectedValue(new ApiError(500, 'Could not save your resume. Please try again.'));

    render(<ResumeUploadForm />);

    fireEvent.change(screen.getByLabelText('Paste your resume text'), { target: { value: longText } });
    fireEvent.click(screen.getByRole('button', { name: /get feedback/i }));

    expect(await screen.findByRole('alert')).toHaveTextContent('Could not save your resume');
    expect(pushMock).not.toHaveBeenCalled();
  });
});
