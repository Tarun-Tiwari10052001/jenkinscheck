import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { QuestionBank } from '@/components/question-bank';
import { questionsApi, ApiError } from '@/lib/api-client';

jest.mock('@/lib/api-client', () => {
  const actual = jest.requireActual('@/lib/api-client');
  return {
    ...actual,
    questionsApi: { list: jest.fn(), filters: jest.fn(), generate: jest.fn() },
  };
});

const listMock = questionsApi.list as jest.Mock;
const filtersMock = questionsApi.filters as jest.Mock;
const generateMock = questionsApi.generate as jest.Mock;

const sampleQuestion = {
  id: 'q-1',
  role: 'Backend Engineer',
  company: 'Acme',
  topic: null,
  category: 'behavioral',
  question: 'Tell me about a time you disagreed with a teammate.',
  createdAt: '',
};

describe('QuestionBank', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    listMock.mockResolvedValue([]);
    filtersMock.mockResolvedValue({ roles: [], companies: [], topics: [] });
  });

  it('shows an empty state when there are no questions yet', async () => {
    render(<QuestionBank />);

    expect(await screen.findByText(/no questions match yet/i)).toBeInTheDocument();
  });

  it('lists existing questions with their tags', async () => {
    listMock.mockResolvedValue([sampleQuestion]);
    filtersMock.mockResolvedValue({ roles: ['Backend Engineer'], companies: ['Acme'], topics: [] });

    render(<QuestionBank />);

    expect(await screen.findByText('Tell me about a time you disagreed with a teammate.')).toBeInTheDocument();
    expect(screen.getAllByText('Acme').length).toBeGreaterThan(0);
    expect(screen.getAllByText('behavioral').length).toBeGreaterThan(0);
  });

  it('shows a validation error and does not call the API when generating without a role', async () => {
    render(<QuestionBank />);
    await screen.findByText(/no questions match yet/i);

    fireEvent.click(screen.getByRole('button', { name: /generate questions/i }));

    expect(await screen.findByRole('alert')).toHaveTextContent('Enter the role');
    expect(generateMock).not.toHaveBeenCalled();
  });

  it('generates questions and prepends them to the list', async () => {
    generateMock.mockResolvedValue([sampleQuestion]);

    render(<QuestionBank />);
    await screen.findByText(/no questions match yet/i);

    fireEvent.change(screen.getByLabelText('Role'), { target: { value: 'Backend Engineer' } });
    fireEvent.click(screen.getByRole('button', { name: /generate questions/i }));

    expect(await screen.findByText('Tell me about a time you disagreed with a teammate.')).toBeInTheDocument();
    expect(generateMock).toHaveBeenCalledWith({
      role: 'Backend Engineer',
      company: undefined,
      topic: undefined,
      category: undefined,
      count: 5,
    });
  });

  it('shows the API error message when generation fails', async () => {
    generateMock.mockRejectedValue(new ApiError(502, 'Could not generate questions right now.'));

    render(<QuestionBank />);
    await screen.findByText(/no questions match yet/i);

    fireEvent.change(screen.getByLabelText('Role'), { target: { value: 'Backend Engineer' } });
    fireEvent.click(screen.getByRole('button', { name: /generate questions/i }));

    expect(await screen.findByRole('alert')).toHaveTextContent('Could not generate questions right now.');
  });

  it('filters the list by role when searching', async () => {
    filtersMock.mockResolvedValue({ roles: ['Backend Engineer'], companies: [], topics: [] });
    listMock.mockResolvedValueOnce([]).mockResolvedValueOnce([sampleQuestion]);

    render(<QuestionBank />);
    await screen.findByText(/no questions match yet/i);

    fireEvent.change(screen.getByLabelText('Filter by role'), { target: { value: 'Backend Engineer' } });
    fireEvent.click(screen.getByRole('button', { name: /^search$/i }));

    await waitFor(() =>
      expect(listMock).toHaveBeenLastCalledWith({
        role: 'Backend Engineer',
        company: undefined,
        topic: undefined,
        category: undefined,
      }),
    );
    expect(await screen.findByText('Tell me about a time you disagreed with a teammate.')).toBeInTheDocument();
  });

  it('shows an error message when the initial load fails', async () => {
    listMock.mockRejectedValue(new ApiError(500, 'Could not load questions.'));

    render(<QuestionBank />);

    expect(await screen.findByRole('alert')).toHaveTextContent('Could not load questions.');
  });
});
