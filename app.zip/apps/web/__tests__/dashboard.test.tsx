import { render, screen, waitFor } from '@testing-library/react';
import DashboardPage from '@/app/dashboard/page';
import { interviewsApi, resumesApi, meetingAssistantApi } from '@/lib/api-client';

const pushMock = jest.fn();
jest.mock('next/navigation', () => ({
  useRouter: () => ({ push: pushMock }),
}));

jest.mock('@/lib/api-client', () => {
  const actual = jest.requireActual('@/lib/api-client');
  return {
    ...actual,
    interviewsApi: { start: jest.fn(), list: jest.fn(), get: jest.fn(), answer: jest.fn(), complete: jest.fn() },
    resumesApi: { create: jest.fn(), list: jest.fn(), get: jest.fn(), remove: jest.fn(), tailor: jest.fn(), coverLetter: jest.fn() },
    meetingAssistantApi: {
      start: jest.fn(),
      list: jest.fn(),
      get: jest.fn(),
      remove: jest.fn(),
      suggest: jest.fn(),
      logTurn: jest.fn(),
      end: jest.fn(),
    },
  };
});

const listSessionsMock = interviewsApi.list as jest.Mock;
const listResumesMock = resumesApi.list as jest.Mock;
const listMeetingsMock = meetingAssistantApi.list as jest.Mock;

describe('DashboardPage', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    localStorage.clear();
    listSessionsMock.mockResolvedValue([]);
    listResumesMock.mockResolvedValue([]);
    listMeetingsMock.mockResolvedValue([]);
  });

  it('redirects to /login when there is no token, without calling any API', async () => {
    render(<DashboardPage />);

    await waitFor(() => expect(pushMock).toHaveBeenCalledWith('/login'));
    expect(listSessionsMock).not.toHaveBeenCalled();
    expect(listResumesMock).not.toHaveBeenCalled();
    expect(listMeetingsMock).not.toHaveBeenCalled();
  });

  it('shows empty states when the user has no interviews, resumes, or meeting sessions', async () => {
    localStorage.setItem('accessToken', 'test-token');

    render(<DashboardPage />);

    expect(await screen.findByText(/no interviews yet/i)).toBeInTheDocument();
    expect(await screen.findByText(/no resumes yet/i)).toBeInTheDocument();
    expect(await screen.findByText(/no sessions yet/i)).toBeInTheDocument();
  });

  it('lists past interviews with their status', async () => {
    localStorage.setItem('accessToken', 'test-token');
    listSessionsMock.mockResolvedValue([
      { id: 'session-1', role: 'Backend Engineer', company: 'Acme', status: 'COMPLETED', score: 88, createdAt: '', completedAt: '' },
      { id: 'session-2', role: 'Frontend Engineer', company: null, status: 'IN_PROGRESS', score: null, createdAt: '', completedAt: null },
    ]);

    render(<DashboardPage />);

    expect(await screen.findByText('Backend Engineer at Acme')).toBeInTheDocument();
    expect(screen.getByText('Score: 88')).toBeInTheDocument();
    expect(screen.getByText('Frontend Engineer')).toBeInTheDocument();
    expect(screen.getByText('In progress')).toBeInTheDocument();
  });

  it('lists resumes with their parsed score and a content preview', async () => {
    localStorage.setItem('accessToken', 'test-token');
    listResumesMock.mockResolvedValue([
      {
        id: 'resume-1',
        content: 'Experienced backend engineer with 5 years building distributed systems at scale.',
        latestFeedback: '{"score": 82, "strengths": ["Clear"], "improvements": ["Add metrics"]}',
        createdAt: '',
        updatedAt: '',
      },
    ]);

    render(<DashboardPage />);

    expect(await screen.findByText(/Experienced backend engineer/)).toBeInTheDocument();
    expect(screen.getByText('Score: 82')).toBeInTheDocument();
  });

  it('lists meeting sessions with their status', async () => {
    localStorage.setItem('accessToken', 'test-token');
    listMeetingsMock.mockResolvedValue([
      { id: 'meeting-1', title: 'Customer renewal call', status: 'ACTIVE', createdAt: '', endedAt: null },
      { id: 'meeting-2', title: 'Weekly standup', status: 'ENDED', createdAt: '', endedAt: '' },
    ]);

    render(<DashboardPage />);

    expect(await screen.findByText('Customer renewal call')).toBeInTheDocument();
    expect(screen.getByText('Active')).toBeInTheDocument();
    expect(screen.getByText('Weekly standup')).toBeInTheDocument();
    expect(screen.getByText('Ended')).toBeInTheDocument();
  });

  it('shows an error message when the resume list fails to load, independent of the others', async () => {
    localStorage.setItem('accessToken', 'test-token');
    listResumesMock.mockRejectedValue(new Error('network down'));

    render(<DashboardPage />);

    expect(await screen.findByRole('alert')).toHaveTextContent('Could not load your resumes.');
    expect(await screen.findByText(/no interviews yet/i)).toBeInTheDocument();
    expect(await screen.findByText(/no sessions yet/i)).toBeInTheDocument();
  });

  it('shows an error message when the meeting session list fails to load, independent of the others', async () => {
    localStorage.setItem('accessToken', 'test-token');
    listMeetingsMock.mockRejectedValue(new Error('network down'));

    render(<DashboardPage />);

    expect(await screen.findByRole('alert')).toHaveTextContent('Could not load your meeting sessions.');
    expect(await screen.findByText(/no interviews yet/i)).toBeInTheDocument();
    expect(await screen.findByText(/no resumes yet/i)).toBeInTheDocument();
  });
});
