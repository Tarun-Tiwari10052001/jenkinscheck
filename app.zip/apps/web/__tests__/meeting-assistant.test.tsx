import { render, screen, fireEvent, waitFor, act } from '@testing-library/react';
import { MeetingAssistant } from '@/components/meeting-assistant';
import { meetingAssistantApi, ApiError } from '@/lib/api-client';
import { isSpeechRecognitionSupported, createSpeechRecognition } from '@/lib/speech';

jest.mock('next/navigation', () => ({
  useRouter: () => ({ push: jest.fn() }),
}));

jest.mock('@/lib/api-client', () => {
  const actual = jest.requireActual('@/lib/api-client');
  return {
    ...actual,
    meetingAssistantApi: {
      start: jest.fn(),
      list: jest.fn(),
      get: jest.fn(),
      remove: jest.fn(),
      suggest: jest.fn(),
      logTurn: jest.fn(),
      end: jest.fn(),
    },
  };
});

jest.mock('@/lib/speech', () => ({
  isSpeechRecognitionSupported: jest.fn(),
  isSpeechSynthesisSupported: jest.fn(),
  createSpeechRecognition: jest.fn(),
  speak: jest.fn(),
  cancelSpeech: jest.fn(),
}));

const getMock = meetingAssistantApi.get as jest.Mock;
const suggestMock = meetingAssistantApi.suggest as jest.Mock;
const logTurnMock = meetingAssistantApi.logTurn as jest.Mock;
const endMock = meetingAssistantApi.end as jest.Mock;

const isSpeechRecognitionSupportedMock = isSpeechRecognitionSupported as jest.Mock;
const createSpeechRecognitionMock = createSpeechRecognition as jest.Mock;

const activeSession = {
  id: 'meeting-1',
  title: 'Customer renewal call',
  contextNotes: null,
  status: 'ACTIVE' as const,
  createdAt: '',
  endedAt: null,
  turns: [],
};

describe('MeetingAssistant', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    isSpeechRecognitionSupportedMock.mockReturnValue(false);
    createSpeechRecognitionMock.mockReturnValue(null);
  });

  it('shows a visible, persistent "active" indicator while the session is active', async () => {
    getMock.mockResolvedValue(activeSession);

    render(<MeetingAssistant sessionId="meeting-1" />);

    expect(await screen.findByText(/meeting assistant is active/i)).toBeInTheDocument();
    expect(screen.getByText(/visible on your screen only/i)).toBeInTheDocument();
  });

  it('does not show the active indicator once the session has ended', async () => {
    getMock.mockResolvedValue({ ...activeSession, status: 'ENDED' });

    render(<MeetingAssistant sessionId="meeting-1" />);

    await screen.findByText('Customer renewal call');
    expect(screen.queryByText(/meeting assistant is active/i)).not.toBeInTheDocument();
  });

  it('shows an error message when loading the session fails', async () => {
    getMock.mockRejectedValue(new ApiError(404, 'Meeting session not found.'));

    render(<MeetingAssistant sessionId="missing" />);

    expect(await screen.findByRole('alert')).toHaveTextContent('Meeting session not found.');
  });

  it('gets a suggestion for a manually typed transcript and displays it', async () => {
    getMock.mockResolvedValue(activeSession);
    suggestMock.mockResolvedValue({ suggestion: 'I can offer a multi-year discount instead.' });

    render(<MeetingAssistant sessionId="meeting-1" />);
    await screen.findByText('Customer renewal call');

    fireEvent.change(screen.getByPlaceholderText('Or type it here'), {
      target: { value: 'Can you lower the price?' },
    });
    fireEvent.click(screen.getByRole('button', { name: /get suggestion/i }));

    expect(await screen.findByText('I can offer a multi-year discount instead.')).toBeInTheDocument();
    expect(suggestMock).toHaveBeenCalledWith('meeting-1', 'Can you lower the price?');
    expect(screen.getByText('Can you lower the price?')).toBeInTheDocument(); // added to transcript
  });

  it('rejects an empty manual transcript without calling the API', async () => {
    getMock.mockResolvedValue(activeSession);

    render(<MeetingAssistant sessionId="meeting-1" />);
    await screen.findByText('Customer renewal call');

    fireEvent.click(screen.getByRole('button', { name: /get suggestion/i }));

    expect(await screen.findByRole('alert')).toHaveTextContent('Type what the other person said');
    expect(suggestMock).not.toHaveBeenCalled();
  });

  it('shows an error message when getting a suggestion fails', async () => {
    getMock.mockResolvedValue(activeSession);
    suggestMock.mockRejectedValue(new ApiError(502, 'Could not get a suggestion. Please try again.'));

    render(<MeetingAssistant sessionId="meeting-1" />);
    await screen.findByText('Customer renewal call');

    fireEvent.change(screen.getByPlaceholderText('Or type it here'), { target: { value: 'hello' } });
    fireEvent.click(screen.getByRole('button', { name: /get suggestion/i }));

    expect(await screen.findByRole('alert')).toHaveTextContent('Could not get a suggestion');
  });

  it('does not show a mic button when speech recognition is unsupported', async () => {
    getMock.mockResolvedValue(activeSession);

    render(<MeetingAssistant sessionId="meeting-1" />);
    await screen.findByText('Customer renewal call');

    expect(screen.queryByRole('button', { name: /listen/i })).not.toBeInTheDocument();
  });

  it('automatically requests a suggestion once a final voice transcript is captured', async () => {
    isSpeechRecognitionSupportedMock.mockReturnValue(true);
    const startMock = jest.fn();
    createSpeechRecognitionMock.mockReturnValue({ start: startMock, stop: jest.fn() });
    getMock.mockResolvedValue(activeSession);
    suggestMock.mockResolvedValue({ suggestion: 'Sounds good, let me check on that.' });

    render(<MeetingAssistant sessionId="meeting-1" />);
    await screen.findByText('Customer renewal call');

    fireEvent.click(screen.getByRole('button', { name: /🎤 listen/i }));
    expect(startMock).toHaveBeenCalledTimes(1);

    const callbacks = createSpeechRecognitionMock.mock.calls[0][0];
    act(() => {
      callbacks.onResult({ transcript: 'partial...', isFinal: false });
    });
    expect(suggestMock).not.toHaveBeenCalled();

    act(() => {
      callbacks.onResult({ transcript: 'Can we discuss pricing?', isFinal: true });
    });

    expect(await screen.findByText('Sounds good, let me check on that.')).toBeInTheDocument();
    expect(suggestMock).toHaveBeenCalledWith('meeting-1', 'Can we discuss pricing?');
  });

  it('logs what the user actually said', async () => {
    getMock.mockResolvedValue(activeSession);
    logTurnMock.mockResolvedValue({ id: 'turn-1', speaker: 'ME', content: 'Let me look into that.', sequenceNumber: 1 });

    render(<MeetingAssistant sessionId="meeting-1" />);
    await screen.findByText('Customer renewal call');

    fireEvent.change(screen.getByLabelText('What you actually said'), {
      target: { value: 'Let me look into that.' },
    });
    fireEvent.click(screen.getByRole('button', { name: /log it/i }));

    expect(await screen.findByText('Let me look into that.')).toBeInTheDocument();
    expect(logTurnMock).toHaveBeenCalledWith('meeting-1', 'Let me look into that.');
  });

  it('ends the session and hides the active controls', async () => {
    getMock.mockResolvedValue(activeSession);
    endMock.mockResolvedValue({ ...activeSession, status: 'ENDED' });

    render(<MeetingAssistant sessionId="meeting-1" />);
    await screen.findByText('Customer renewal call');

    fireEvent.click(screen.getByRole('button', { name: /end session/i }));

    await waitFor(() => expect(screen.getByText('Ended')).toBeInTheDocument());
    expect(screen.queryByText(/meeting assistant is active/i)).not.toBeInTheDocument();
    expect(screen.getByRole('button', { name: /back to dashboard/i })).toBeInTheDocument();
  });
});
