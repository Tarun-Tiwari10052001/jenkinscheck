import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { LoginForm } from '@/components/login-form';
import { authApi, ApiError } from '@/lib/api-client';

const pushMock = jest.fn();
jest.mock('next/navigation', () => ({
  useRouter: () => ({ push: pushMock }),
}));

jest.mock('@/lib/api-client', () => {
  const actual = jest.requireActual('@/lib/api-client');
  return { ...actual, authApi: { login: jest.fn(), register: jest.fn() } };
});

const loginMock = authApi.login as jest.Mock;

describe('LoginForm', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    localStorage.clear();
  });

  it('shows a validation error and does not call the API for an invalid email', async () => {
    render(<LoginForm />);

    fireEvent.change(screen.getByLabelText('Email'), { target: { value: 'not-an-email' } });
    fireEvent.change(screen.getByLabelText('Password'), { target: { value: 'password123' } });
    fireEvent.click(screen.getByRole('button', { name: /log in/i }));

    expect(await screen.findByRole('alert')).toHaveTextContent('valid email');
    expect(loginMock).not.toHaveBeenCalled();
  });

  it('shows a validation error when the password is empty', async () => {
    render(<LoginForm />);

    fireEvent.change(screen.getByLabelText('Email'), { target: { value: 'user@example.com' } });
    fireEvent.click(screen.getByRole('button', { name: /log in/i }));

    expect(await screen.findByRole('alert')).toHaveTextContent('password');
    expect(loginMock).not.toHaveBeenCalled();
  });

  it('logs in and redirects to the dashboard on success', async () => {
    loginMock.mockResolvedValue({
      accessToken: 'test-token',
      user: { id: '1', email: 'user@example.com', name: null },
    });

    render(<LoginForm />);

    fireEvent.change(screen.getByLabelText('Email'), { target: { value: 'user@example.com' } });
    fireEvent.change(screen.getByLabelText('Password'), { target: { value: 'correct-password' } });
    fireEvent.click(screen.getByRole('button', { name: /log in/i }));

    await waitFor(() => expect(pushMock).toHaveBeenCalledWith('/dashboard'));
    expect(localStorage.getItem('accessToken')).toBe('test-token');
    expect(loginMock).toHaveBeenCalledWith({ email: 'user@example.com', password: 'correct-password' });
  });

  it('shows the API error message when login fails', async () => {
    loginMock.mockRejectedValue(new ApiError(401, 'Invalid email or password'));

    render(<LoginForm />);

    fireEvent.change(screen.getByLabelText('Email'), { target: { value: 'user@example.com' } });
    fireEvent.change(screen.getByLabelText('Password'), { target: { value: 'wrong-password' } });
    fireEvent.click(screen.getByRole('button', { name: /log in/i }));

    expect(await screen.findByRole('alert')).toHaveTextContent('Invalid email or password');
    expect(pushMock).not.toHaveBeenCalled();
  });
});
