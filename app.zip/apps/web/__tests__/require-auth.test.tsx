import { render, screen, waitFor } from '@testing-library/react';
import { RequireAuth } from '@/components/require-auth';

const pushMock = jest.fn();
jest.mock('next/navigation', () => ({
  useRouter: () => ({ push: pushMock }),
}));

describe('RequireAuth', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    localStorage.clear();
  });

  it('redirects to /login and renders nothing when there is no token', async () => {
    render(
      <RequireAuth>
        <p>secret dashboard content</p>
      </RequireAuth>,
    );

    await waitFor(() => expect(pushMock).toHaveBeenCalledWith('/login'));
    expect(screen.queryByText('secret dashboard content')).not.toBeInTheDocument();
  });

  it('renders its children when a token is present', async () => {
    localStorage.setItem('accessToken', 'test-token');

    render(
      <RequireAuth>
        <p>secret dashboard content</p>
      </RequireAuth>,
    );

    expect(await screen.findByText('secret dashboard content')).toBeInTheDocument();
    expect(pushMock).not.toHaveBeenCalled();
  });
});
