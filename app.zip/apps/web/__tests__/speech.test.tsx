import {
  isSpeechRecognitionSupported,
  isSpeechSynthesisSupported,
  createSpeechRecognition,
  speak,
  cancelSpeech,
} from '@/lib/speech';

describe('speech', () => {
  afterEach(() => {
    delete (window as any).SpeechRecognition;
    delete (window as any).webkitSpeechRecognition;
    delete (window as any).speechSynthesis;
    delete (global as any).SpeechSynthesisUtterance;
  });

  describe('isSpeechRecognitionSupported', () => {
    it('returns false when neither SpeechRecognition nor webkitSpeechRecognition exist', () => {
      expect(isSpeechRecognitionSupported()).toBe(false);
    });

    it('returns true when SpeechRecognition exists', () => {
      (window as any).SpeechRecognition = function () {};
      expect(isSpeechRecognitionSupported()).toBe(true);
    });

    it('returns true when only webkitSpeechRecognition exists', () => {
      (window as any).webkitSpeechRecognition = function () {};
      expect(isSpeechRecognitionSupported()).toBe(true);
    });
  });

  describe('isSpeechSynthesisSupported', () => {
    it('returns false when speechSynthesis does not exist', () => {
      expect(isSpeechSynthesisSupported()).toBe(false);
    });

    it('returns true when speechSynthesis exists', () => {
      (window as any).speechSynthesis = {};
      expect(isSpeechSynthesisSupported()).toBe(true);
    });
  });

  describe('createSpeechRecognition', () => {
    it('returns null when unsupported', () => {
      const controller = createSpeechRecognition({ onResult: jest.fn(), onEnd: jest.fn(), onError: jest.fn() });
      expect(controller).toBeNull();
    });

    it('wires up start/stop to the underlying recognition instance', () => {
      const startMock = jest.fn();
      const stopMock = jest.fn();
      (window as any).SpeechRecognition = jest.fn().mockImplementation(() => ({
        start: startMock,
        stop: stopMock,
      }));

      const controller = createSpeechRecognition({ onResult: jest.fn(), onEnd: jest.fn(), onError: jest.fn() });
      controller?.start();
      controller?.stop();

      expect(startMock).toHaveBeenCalledTimes(1);
      expect(stopMock).toHaveBeenCalledTimes(1);
    });

    it('calls onResult with the transcript and finality of the latest result', () => {
      let instance: any;
      (window as any).SpeechRecognition = jest.fn().mockImplementation(function (this: any) {
        instance = this;
      });

      const onResult = jest.fn();
      createSpeechRecognition({ onResult, onEnd: jest.fn(), onError: jest.fn() });

      instance.onresult({
        results: [
          { 0: { transcript: 'first' }, isFinal: true },
          { 0: { transcript: 'hello world' }, isFinal: false },
        ],
      });

      expect(onResult).toHaveBeenCalledWith({ transcript: 'hello world', isFinal: false });
    });

    it('calls onError with the event error, or a fallback message when none is given', () => {
      let instance: any;
      (window as any).SpeechRecognition = jest.fn().mockImplementation(function (this: any) {
        instance = this;
      });

      const onError = jest.fn();
      createSpeechRecognition({ onResult: jest.fn(), onEnd: jest.fn(), onError });

      instance.onerror({ error: 'no-speech' });
      expect(onError).toHaveBeenCalledWith('no-speech');

      instance.onerror({});
      expect(onError).toHaveBeenCalledWith('Speech recognition error');
    });

    it('calls onEnd when recognition ends', () => {
      let instance: any;
      (window as any).SpeechRecognition = jest.fn().mockImplementation(function (this: any) {
        instance = this;
      });

      const onEnd = jest.fn();
      createSpeechRecognition({ onResult: jest.fn(), onEnd, onError: jest.fn() });

      instance.onend();
      expect(onEnd).toHaveBeenCalledTimes(1);
    });
  });

  describe('speak', () => {
    it('does nothing when speech synthesis is unsupported', () => {
      expect(() => speak('hello')).not.toThrow();
    });

    it('cancels any prior utterance, then speaks the given text', () => {
      const cancelMock = jest.fn();
      const speakMock = jest.fn();
      (window as any).speechSynthesis = { cancel: cancelMock, speak: speakMock };
      (global as any).SpeechSynthesisUtterance = jest.fn().mockImplementation((text: string) => ({ text }));

      speak('Tell me about yourself.');

      expect(cancelMock).toHaveBeenCalled();
      expect(SpeechSynthesisUtterance).toHaveBeenCalledWith('Tell me about yourself.');
      expect(speakMock).toHaveBeenCalled();
    });

    it('wires up onStart/onEnd callbacks on the utterance', () => {
      const speakMock = jest.fn();
      (window as any).speechSynthesis = { cancel: jest.fn(), speak: speakMock };
      const utteranceInstance: any = {};
      (global as any).SpeechSynthesisUtterance = jest.fn().mockImplementation(() => utteranceInstance);

      const onStart = jest.fn();
      const onEnd = jest.fn();
      speak('hello', { onStart, onEnd });

      expect(utteranceInstance.onstart).toBe(onStart);
      expect(utteranceInstance.onend).toBe(onEnd);
    });
  });

  describe('cancelSpeech', () => {
    it('does nothing when unsupported', () => {
      expect(() => cancelSpeech()).not.toThrow();
    });

    it('calls cancel on speechSynthesis when supported', () => {
      const cancelMock = jest.fn();
      (window as any).speechSynthesis = { cancel: cancelMock };

      cancelSpeech();

      expect(cancelMock).toHaveBeenCalledTimes(1);
    });
  });
});
