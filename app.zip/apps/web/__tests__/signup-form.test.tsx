import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { SignupForm } from '@/components/signup-form';
import { authApi, ApiError } from '@/lib/api-client';

const pushMock = jest.fn();
jest.mock('next/navigation', () => ({
  useRouter: () => ({ push: pushMock }),
}));

jest.mock('@/lib/api-client', () => {
  const actual = jest.requireActual('@/lib/api-client');
  return { ...actual, authApi: { login: jest.fn(), register: jest.fn() } };
});

const registerMock = authApi.register as jest.Mock;

describe('SignupForm', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    localStorage.clear();
  });

  it('rejects a password shorter than 8 characters without calling the API', async () => {
    render(<SignupForm />);

    fireEvent.change(screen.getByLabelText('Email'), { target: { value: 'user@example.com' } });
    fireEvent.change(screen.getByLabelText('Password'), { target: { value: 'short' } });
    fireEvent.click(screen.getByRole('button', { name: /create account/i }));

    expect(await screen.findByRole('alert')).toHaveTextContent('8 characters');
    expect(registerMock).not.toHaveBeenCalled();
  });

  it('registers and redirects to the dashboard on success, name is optional', async () => {
    registerMock.mockResolvedValue({
      accessToken: 'test-token',
      user: { id: '1', email: 'user@example.com', name: null },
    });

    render(<SignupForm />);

    fireEvent.change(screen.getByLabelText('Email'), { target: { value: 'user@example.com' } });
    fireEvent.change(screen.getByLabelText('Password'), { target: { value: 'password123' } });
    fireEvent.click(screen.getByRole('button', { name: /create account/i }));

    await waitFor(() => expect(pushMock).toHaveBeenCalledWith('/dashboard'));
    expect(registerMock).toHaveBeenCalledWith({
      email: 'user@example.com',
      password: 'password123',
      name: undefined,
    });
    expect(localStorage.getItem('accessToken')).toBe('test-token');
  });

  it('shows the API error message when the email is already taken', async () => {
    registerMock.mockRejectedValue(new ApiError(409, 'An account with this email already exists'));

    render(<SignupForm />);

    fireEvent.change(screen.getByLabelText('Email'), { target: { value: 'taken@example.com' } });
    fireEvent.change(screen.getByLabelText('Password'), { target: { value: 'password123' } });
    fireEvent.click(screen.getByRole('button', { name: /create account/i }));

    expect(await screen.findByRole('alert')).toHaveTextContent('already exists');
  });
});
