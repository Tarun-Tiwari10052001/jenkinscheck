import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { StartMeetingForm } from '@/components/start-meeting-form';
import { meetingAssistantApi, ApiError } from '@/lib/api-client';

const pushMock = jest.fn();
jest.mock('next/navigation', () => ({
  useRouter: () => ({ push: pushMock }),
}));

jest.mock('@/lib/api-client', () => {
  const actual = jest.requireActual('@/lib/api-client');
  return {
    ...actual,
    meetingAssistantApi: {
      start: jest.fn(),
      list: jest.fn(),
      get: jest.fn(),
      remove: jest.fn(),
      suggest: jest.fn(),
      logTurn: jest.fn(),
      end: jest.fn(),
    },
  };
});

const startMock = meetingAssistantApi.start as jest.Mock;

describe('StartMeetingForm', () => {
  beforeEach(() => jest.clearAllMocks());

  it('shows the consent/visibility reminder', () => {
    render(<StartMeetingForm />);

    expect(screen.getByRole('note')).toHaveTextContent(/visible on your own screen only/i);
    expect(screen.getByRole('note')).toHaveTextContent(/notifying other participants/i);
  });

  it('rejects a title shorter than 2 characters without calling the API', async () => {
    render(<StartMeetingForm />);

    fireEvent.change(screen.getByLabelText("What's this call?"), { target: { value: 'A' } });
    fireEvent.click(screen.getByRole('button', { name: /start session/i }));

    expect(await screen.findByRole('alert')).toHaveTextContent('title');
    expect(startMock).not.toHaveBeenCalled();
  });

  it('starts the session and redirects to it, with context notes optional', async () => {
    startMock.mockResolvedValue({ id: 'meeting-1', title: 'Customer call', status: 'ACTIVE' });

    render(<StartMeetingForm />);

    fireEvent.change(screen.getByLabelText("What's this call?"), { target: { value: 'Customer call' } });
    fireEvent.click(screen.getByRole('button', { name: /start session/i }));

    await waitFor(() => expect(pushMock).toHaveBeenCalledWith('/assistant/meeting-1'));
    expect(startMock).toHaveBeenCalledWith({ title: 'Customer call', contextNotes: undefined });
  });

  it('passes context notes when provided', async () => {
    startMock.mockResolvedValue({ id: 'meeting-2', title: 'Renewal', status: 'ACTIVE' });

    render(<StartMeetingForm />);

    fireEvent.change(screen.getByLabelText("What's this call?"), { target: { value: 'Renewal' } });
    fireEvent.change(screen.getByLabelText('Context (optional)'), {
      target: { value: 'Customer is price-sensitive' },
    });
    fireEvent.click(screen.getByRole('button', { name: /start session/i }));

    await waitFor(() =>
      expect(startMock).toHaveBeenCalledWith({
        title: 'Renewal',
        contextNotes: 'Customer is price-sensitive',
      }),
    );
  });

  it('shows the API error message when starting fails', async () => {
    startMock.mockRejectedValue(new ApiError(500, 'Could not start the session. Please try again.'));

    render(<StartMeetingForm />);

    fireEvent.change(screen.getByLabelText("What's this call?"), { target: { value: 'Customer call' } });
    fireEvent.click(screen.getByRole('button', { name: /start session/i }));

    expect(await screen.findByRole('alert')).toHaveTextContent('Could not start the session');
    expect(pushMock).not.toHaveBeenCalled();
  });
});
