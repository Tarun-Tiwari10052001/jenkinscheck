'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { RequireAuth } from '@/components/require-auth';
import {
  ApiError,
  InterviewSessionSummary,
  MeetingSessionSummary,
  ResumeSummary,
  interviewsApi,
  meetingAssistantApi,
  resumesApi,
} from '@/lib/api-client';
import { parseFeedback } from '@/lib/parse-feedback';

export default function DashboardPage() {
  return (
    <RequireAuth>
      <DashboardContent />
    </RequireAuth>
  );
}

/**
 * Split from DashboardPage so RequireAuth's redirect can run before this
 * ever tries to fetch anything — see components/require-auth.tsx.
 */
function DashboardContent() {
  const [sessions, setSessions] = useState<InterviewSessionSummary[]>([]);
  const [sessionsLoading, setSessionsLoading] = useState(true);
  const [sessionsError, setSessionsError] = useState<string | null>(null);

  const [resumes, setResumes] = useState<ResumeSummary[]>([]);
  const [resumesLoading, setResumesLoading] = useState(true);
  const [resumesError, setResumesError] = useState<string | null>(null);

  const [meetings, setMeetings] = useState<MeetingSessionSummary[]>([]);
  const [meetingsLoading, setMeetingsLoading] = useState(true);
  const [meetingsError, setMeetingsError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;

    interviewsApi
      .list()
      .then((data) => {
        if (!cancelled) setSessions(data);
      })
      .catch((err) => {
        if (!cancelled) {
          setSessionsError(err instanceof ApiError ? err.message : 'Could not load your interviews.');
        }
      })
      .finally(() => {
        if (!cancelled) setSessionsLoading(false);
      });

    resumesApi
      .list()
      .then((data) => {
        if (!cancelled) setResumes(data);
      })
      .catch((err) => {
        if (!cancelled) {
          setResumesError(err instanceof ApiError ? err.message : 'Could not load your resumes.');
        }
      })
      .finally(() => {
        if (!cancelled) setResumesLoading(false);
      });

    meetingAssistantApi
      .list()
      .then((data) => {
        if (!cancelled) setMeetings(data);
      })
      .catch((err) => {
        if (!cancelled) {
          setMeetingsError(err instanceof ApiError ? err.message : 'Could not load your meeting sessions.');
        }
      })
      .finally(() => {
        if (!cancelled) setMeetingsLoading(false);
      });

    return () => {
      cancelled = true;
    };
  }, []);

  return (
    <main className="mx-auto max-w-3xl px-6 py-16">
      <h1 className="text-2xl font-semibold">Dashboard</h1>

      <section className="mt-4">
        <Link
          href="/questions"
          className="inline-block rounded-md border border-slate-300 px-4 py-2 text-sm font-medium hover:bg-slate-100"
        >
          Browse the question bank
        </Link>
      </section>

      <section className="mt-8">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold">Your interviews</h2>
          <Link
            href="/interview/new"
            className="rounded-md bg-slate-900 px-4 py-2 text-sm font-medium text-white hover:bg-slate-700"
          >
            Start a mock interview
          </Link>
        </div>

        {sessionsLoading && <p className="mt-2 text-sm text-slate-500">Loading…</p>}
        {sessionsError && (
          <p role="alert" className="mt-2 text-sm text-red-600">
            {sessionsError}
          </p>
        )}
        {!sessionsLoading && !sessionsError && sessions.length === 0 && (
          <p className="mt-2 text-sm text-slate-500">No interviews yet — start your first one above.</p>
        )}

        <ul className="mt-4 flex flex-col gap-2">
          {sessions.map((s) => (
            <li key={s.id}>
              <Link
                href={`/interview/${s.id}`}
                className="flex items-center justify-between rounded-md border border-slate-200 px-4 py-3 text-sm hover:bg-slate-50"
              >
                <span>
                  {s.role}
                  {s.company ? ` at ${s.company}` : ''}
                </span>
                <span className="text-slate-500">
                  {s.status === 'COMPLETED' ? `Score: ${s.score ?? '—'}` : 'In progress'}
                </span>
              </Link>
            </li>
          ))}
        </ul>
      </section>

      <section className="mt-10">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold">Your resumes</h2>
          <Link
            href="/resume/new"
            className="rounded-md bg-slate-900 px-4 py-2 text-sm font-medium text-white hover:bg-slate-700"
          >
            Get resume feedback
          </Link>
        </div>

        {resumesLoading && <p className="mt-2 text-sm text-slate-500">Loading…</p>}
        {resumesError && (
          <p role="alert" className="mt-2 text-sm text-red-600">
            {resumesError}
          </p>
        )}
        {!resumesLoading && !resumesError && resumes.length === 0 && (
          <p className="mt-2 text-sm text-slate-500">No resumes yet — add one above.</p>
        )}

        <ul className="mt-4 flex flex-col gap-2">
          {resumes.map((r) => {
            const feedback = parseFeedback(r.latestFeedback);
            return (
              <li key={r.id}>
                <Link
                  href={`/resume/${r.id}`}
                  className="flex items-center justify-between rounded-md border border-slate-200 px-4 py-3 text-sm hover:bg-slate-50"
                >
                  <span>{r.content.slice(0, 60)}{r.content.length > 60 ? '…' : ''}</span>
                  <span className="text-slate-500">Score: {feedback?.score ?? '—'}</span>
                </Link>
              </li>
            );
          })}
        </ul>
      </section>

      <section className="mt-10">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold">Meeting Assistant</h2>
          <Link
            href="/assistant/new"
            className="rounded-md bg-slate-900 px-4 py-2 text-sm font-medium text-white hover:bg-slate-700"
          >
            Start a session
          </Link>
        </div>
        <p className="mt-1 text-sm text-slate-500">
          Real-time help during your own work calls — visible on your screen only.
        </p>

        {meetingsLoading && <p className="mt-2 text-sm text-slate-500">Loading…</p>}
        {meetingsError && (
          <p role="alert" className="mt-2 text-sm text-red-600">
            {meetingsError}
          </p>
        )}
        {!meetingsLoading && !meetingsError && meetings.length === 0 && (
          <p className="mt-2 text-sm text-slate-500">No sessions yet — start one above.</p>
        )}

        <ul className="mt-4 flex flex-col gap-2">
          {meetings.map((m) => (
            <li key={m.id}>
              <Link
                href={`/assistant/${m.id}`}
                className="flex items-center justify-between rounded-md border border-slate-200 px-4 py-3 text-sm hover:bg-slate-50"
              >
                <span>{m.title}</span>
                <span className="text-slate-500">{m.status === 'ACTIVE' ? 'Active' : 'Ended'}</span>
              </Link>
            </li>
          ))}
        </ul>
      </section>
    </main>
  );
}
