import Link from 'next/link';

export default function HomePage() {
  return (
    <main className="mx-auto flex min-h-screen max-w-3xl flex-col items-center justify-center gap-6 px-6 text-center">
      <h1 className="text-4xl font-semibold tracking-tight">Interview Prep Platform</h1>
      <p className="max-w-xl text-slate-600">
        Practice with an AI interviewer, tailor your resume to the role, and walk in prepared.
      </p>
      <div className="flex gap-3">
        <Link
          href="/signup"
          className="rounded-md bg-slate-900 px-5 py-2.5 text-sm font-medium text-white hover:bg-slate-700"
        >
          Get started
        </Link>
        <Link
          href="/login"
          className="rounded-md border border-slate-300 px-5 py-2.5 text-sm font-medium hover:bg-slate-100"
        >
          Log in
        </Link>
      </div>
    </main>
  );
}
