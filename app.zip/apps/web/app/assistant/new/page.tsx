import { RequireAuth } from '@/components/require-auth';
import { StartMeetingForm } from '@/components/start-meeting-form';

export default function NewMeetingPage() {
  return (
    <RequireAuth>
      <main className="mx-auto flex min-h-screen max-w-lg flex-col items-center justify-center gap-6 px-6 py-12">
        <h1 className="text-2xl font-semibold">Meeting Assistant</h1>
        <StartMeetingForm />
      </main>
    </RequireAuth>
  );
}
