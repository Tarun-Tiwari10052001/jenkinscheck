import { RequireAuth } from '@/components/require-auth';
import { MeetingAssistant } from '@/components/meeting-assistant';

export default function MeetingPage({ params }: { params: { id: string } }) {
  return (
    <RequireAuth>
      <main className="mx-auto flex min-h-screen max-w-2xl flex-col items-center gap-6 px-6 py-12">
        <MeetingAssistant sessionId={params.id} />
      </main>
    </RequireAuth>
  );
}
