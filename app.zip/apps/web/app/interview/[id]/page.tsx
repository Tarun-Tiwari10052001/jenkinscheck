import { RequireAuth } from '@/components/require-auth';
import { InterviewChat } from '@/components/interview-chat';

export default function InterviewPage({ params }: { params: { id: string } }) {
  return (
    <RequireAuth>
      <main className="mx-auto flex min-h-screen max-w-2xl flex-col items-center gap-6 px-6 py-12">
        <InterviewChat sessionId={params.id} />
      </main>
    </RequireAuth>
  );
}
