import { RequireAuth } from '@/components/require-auth';
import { StartInterviewForm } from '@/components/start-interview-form';

export default function NewInterviewPage() {
  return (
    <RequireAuth>
      <main className="mx-auto flex min-h-screen max-w-md flex-col items-center justify-center gap-6 px-6">
        <h1 className="text-2xl font-semibold">Start a mock interview</h1>
        <StartInterviewForm />
      </main>
    </RequireAuth>
  );
}
