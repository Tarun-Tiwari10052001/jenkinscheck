import { RequireAuth } from '@/components/require-auth';
import { ResumeDetail } from '@/components/resume-detail';

export default function ResumePage({ params }: { params: { id: string } }) {
  return (
    <RequireAuth>
      <main className="mx-auto flex min-h-screen max-w-2xl flex-col items-center gap-6 px-6 py-12">
        <ResumeDetail resumeId={params.id} />
      </main>
    </RequireAuth>
  );
}
