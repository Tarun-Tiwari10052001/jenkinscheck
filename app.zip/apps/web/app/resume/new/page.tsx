import { RequireAuth } from '@/components/require-auth';
import { ResumeUploadForm } from '@/components/resume-upload-form';

export default function NewResumePage() {
  return (
    <RequireAuth>
      <main className="mx-auto flex min-h-screen max-w-xl flex-col items-center justify-center gap-6 px-6 py-12">
        <h1 className="text-2xl font-semibold">Get resume feedback</h1>
        <ResumeUploadForm />
      </main>
    </RequireAuth>
  );
}
