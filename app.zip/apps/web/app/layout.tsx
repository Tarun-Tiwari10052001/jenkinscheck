import './globals.css';
import type { ReactNode } from 'react';
import { TransparencySettings } from '@/components/transparency-settings';

export const metadata = {
  title: 'Interview Prep Platform',
  description: 'Practice interviews, tailor your resume, walk in prepared.',
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="min-h-screen text-slate-900 antialiased">{children}<TransparencySettings /></body>
    </html>
  );
}
