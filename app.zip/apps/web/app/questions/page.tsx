import { RequireAuth } from '@/components/require-auth';
import { QuestionBank } from '@/components/question-bank';

export default function QuestionsPage() {
  return (
    <RequireAuth>
      <main className="mx-auto flex min-h-screen max-w-3xl flex-col items-center gap-6 px-6 py-12">
        <QuestionBank />
      </main>
    </RequireAuth>
  );
}
