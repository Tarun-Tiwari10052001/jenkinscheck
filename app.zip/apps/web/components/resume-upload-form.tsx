'use client';

import { FormEvent, useState } from 'react';
import { useRouter } from 'next/navigation';
import { resumesApi, ApiError } from '@/lib/api-client';

/**
 * MVP accepts pasted resume text, not a file upload — see
 * docs/CHANGE-GUIDE.md / docs/DATABASE.md for why. Feedback is generated
 * immediately on submit, so this can take a few seconds.
 */
export function ResumeUploadForm() {
  const router = useRouter();
  const [content, setContent] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);

    if (content.trim().length < 50) {
      setError('Paste your full resume text (at least 50 characters).');
      return;
    }

    setSubmitting(true);
    try {
      const resume = await resumesApi.create(content.trim());
      router.push(`/resume/${resume.id}`);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not save your resume. Please try again.');
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} className="flex w-full max-w-xl flex-col gap-4" noValidate>
      <div className="flex flex-col gap-1">
        <label htmlFor="content" className="text-sm font-medium">
          Paste your resume text
        </label>
        <textarea
          id="content"
          value={content}
          onChange={(e) => setContent(e.target.value)}
          rows={14}
          placeholder="Paste the full text of your resume here…"
          className="rounded-md border border-slate-300 px-3 py-2 text-sm"
        />
      </div>

      {error && (
        <p role="alert" className="text-sm text-red-600">
          {error}
        </p>
      )}

      <button
        type="submit"
        disabled={submitting}
        className="self-start rounded-md bg-slate-900 px-4 py-2 text-sm font-medium text-white disabled:opacity-50"
      >
        {submitting ? 'Analyzing…' : 'Get feedback'}
      </button>
    </form>
  );
}
