'use client';

import { FormEvent, useEffect, useRef, useState } from 'react';
import { useRouter } from 'next/navigation';
import {
  ApiError,
  MeetingSessionStatus,
  MeetingTurn,
  meetingAssistantApi,
} from '@/lib/api-client';
import {
  createSpeechRecognition,
  isSpeechRecognitionSupported,
  SpeechRecognitionController,
} from '@/lib/speech';

interface Props {
  sessionId: string;
}

/**
 * The live Meeting Assistant session: shows a persistent, visible
 * "active" indicator (never hidden from screen sharing or anyone on the
 * call — see docs/CHANGE-GUIDE.md), transcribes what the other person
 * said (by mic, or typed as a fallback), and shows an AI-suggested
 * response the user can say in their own words. Nothing here is
 * auto-spoken or auto-sent anywhere — every suggestion is just text on
 * the user's own screen for them to read and decide what to do with.
 */
export function MeetingAssistant({ sessionId }: Props) {
  const router = useRouter();
  const [title, setTitle] = useState('');
  const [status, setStatus] = useState<MeetingSessionStatus | null>(null);
  const [turns, setTurns] = useState<MeetingTurn[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);

  const [manualTranscript, setManualTranscript] = useState('');
  const [suggestion, setSuggestion] = useState<string | null>(null);
  const [suggesting, setSuggesting] = useState(false);
  const [suggestError, setSuggestError] = useState<string | null>(null);

  const [actualSaid, setActualSaid] = useState('');
  const [logging, setLogging] = useState(false);

  const [listening, setListening] = useState(false);
  const recognitionRef = useRef<SpeechRecognitionController | null>(null);
  const recognitionSupported = isSpeechRecognitionSupported();

  const [ending, setEnding] = useState(false);

  useEffect(() => {
    let cancelled = false;
    meetingAssistantApi
      .get(sessionId)
      .then((session) => {
        if (cancelled) return;
        setTitle(session.title);
        setStatus(session.status);
        setTurns(session.turns);
      })
      .catch((err) => {
        if (!cancelled) setLoadError(err instanceof ApiError ? err.message : 'Could not load this session.');
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [sessionId]);

  useEffect(() => {
    return () => {
      recognitionRef.current?.stop();
    };
  }, []);

  async function requestSuggestion(transcript: string) {
    setSuggestError(null);
    setSuggesting(true);
    setTurns((prev) => [
      ...prev,
      { id: `local-${prev.length}`, speaker: 'OTHER', content: transcript, sequenceNumber: prev.length + 1 },
    ]);
    try {
      const res = await meetingAssistantApi.suggest(sessionId, transcript);
      setSuggestion(res.suggestion);
    } catch (err) {
      setSuggestError(err instanceof ApiError ? err.message : 'Could not get a suggestion. Please try again.');
    } finally {
      setSuggesting(false);
    }
  }

  function handleManualSubmit(e: FormEvent) {
    e.preventDefault();
    const trimmed = manualTranscript.trim();
    if (!trimmed) {
      setSuggestError('Type what the other person said first.');
      return;
    }
    setManualTranscript('');
    requestSuggestion(trimmed);
  }

  function toggleListening() {
    if (listening) {
      recognitionRef.current?.stop();
      return;
    }

    setSuggestError(null);
    const controller = createSpeechRecognition({
      onResult: (result) => {
        if (result.isFinal) requestSuggestion(result.transcript);
      },
      onEnd: () => setListening(false),
      onError: (message) => {
        setListening(false);
        setSuggestError(`Voice input error: ${message}`);
      },
    });

    if (!controller) return;
    recognitionRef.current = controller;
    setListening(true);
    controller.start();
  }

  async function handleLogActual(e: FormEvent) {
    e.preventDefault();
    const trimmed = actualSaid.trim();
    if (!trimmed) return;

    setLogging(true);
    try {
      const turn = await meetingAssistantApi.logTurn(sessionId, trimmed);
      setTurns((prev) => [...prev, turn]);
      setActualSaid('');
    } catch {
      // Non-critical — logging is for future-suggestion context, not required.
    } finally {
      setLogging(false);
    }
  }

  async function handleEnd() {
    setEnding(true);
    try {
      await meetingAssistantApi.end(sessionId);
      setStatus('ENDED');
    } catch {
      setEnding(false);
    }
  }

  if (loading) {
    return <p className="text-sm text-slate-500">Loading session…</p>;
  }

  if (loadError) {
    return (
      <p role="alert" className="text-sm text-red-600">
        {loadError}
      </p>
    );
  }

  return (
    <div className="flex w-full max-w-2xl flex-col gap-6">
      {status === 'ACTIVE' && (
        <div className="flex items-center gap-2 rounded-md bg-emerald-50 px-4 py-2 text-sm font-medium text-emerald-800">
          <span aria-hidden>🟢</span>
          Meeting Assistant is active — visible on your screen only
        </div>
      )}

      <div>
        <h1 className="text-xl font-semibold">{title}</h1>
        <p className="text-sm text-slate-500">{status === 'ENDED' ? 'Ended' : 'In progress'}</p>
      </div>

      <ul className="flex flex-col gap-2">
        {turns.map((t) => (
          <li
            key={t.id}
            className={
              t.speaker === 'OTHER'
                ? 'max-w-lg rounded-lg bg-slate-100 px-4 py-2 text-sm'
                : 'ml-auto max-w-lg rounded-lg bg-slate-900 px-4 py-2 text-sm text-white'
            }
          >
            {t.content}
          </li>
        ))}
      </ul>

      {status === 'ACTIVE' && (
        <>
          <section className="rounded-lg border border-slate-200 p-4">
            <h2 className="text-sm font-medium">What did they just say?</h2>
            <div className="mt-2 flex flex-col gap-2">
              {recognitionSupported && (
                <button
                  type="button"
                  onClick={toggleListening}
                  className="self-start rounded-md border border-slate-300 px-4 py-2 text-sm font-medium hover:bg-slate-100"
                >
                  {listening ? '⏹ Stop listening' : '🎤 Listen'}
                </button>
              )}
              {listening && <p className="text-sm text-slate-500">🎤 Listening…</p>}

              <form onSubmit={handleManualSubmit} className="flex gap-2">
                <label htmlFor="manual-transcript" className="sr-only">
                  Type what they said
                </label>
                <input
                  id="manual-transcript"
                  type="text"
                  value={manualTranscript}
                  onChange={(e) => setManualTranscript(e.target.value)}
                  placeholder="Or type it here"
                  className="flex-1 rounded-md border border-slate-300 px-3 py-2 text-sm"
                />
                <button
                  type="submit"
                  disabled={suggesting}
                  className="rounded-md bg-slate-900 px-4 py-2 text-sm font-medium text-white disabled:opacity-50"
                >
                  {suggesting ? 'Thinking…' : 'Get suggestion'}
                </button>
              </form>
            </div>

            {suggestError && (
              <p role="alert" className="mt-2 text-sm text-red-600">
                {suggestError}
              </p>
            )}

            {suggestion && (
              <div className="mt-4 rounded-lg bg-indigo-50 p-4">
                <h3 className="text-sm font-medium text-indigo-900">Suggested response</h3>
                <p className="mt-1 text-sm text-indigo-950">{suggestion}</p>
              </div>
            )}
          </section>

          <section className="rounded-lg border border-slate-200 p-4">
            <h2 className="text-sm font-medium">What did you actually say? (optional)</h2>
            <p className="mt-1 text-xs text-slate-500">
              Logging this helps later suggestions stay consistent with what you've already said.
            </p>
            <form onSubmit={handleLogActual} className="mt-2 flex gap-2">
              <label htmlFor="actual-said" className="sr-only">
                What you actually said
              </label>
              <input
                id="actual-said"
                type="text"
                value={actualSaid}
                onChange={(e) => setActualSaid(e.target.value)}
                className="flex-1 rounded-md border border-slate-300 px-3 py-2 text-sm"
              />
              <button
                type="submit"
                disabled={logging}
                className="rounded-md border border-slate-300 px-4 py-2 text-sm font-medium hover:bg-slate-100 disabled:opacity-50"
              >
                {logging ? 'Saving…' : 'Log it'}
              </button>
            </form>
          </section>

          <button
            type="button"
            onClick={handleEnd}
            disabled={ending}
            className="self-start rounded-md border border-slate-300 px-4 py-2 text-sm font-medium hover:bg-slate-100 disabled:opacity-50"
          >
            {ending ? 'Ending…' : 'End session'}
          </button>
        </>
      )}

      {status === 'ENDED' && (
        <button
          type="button"
          onClick={() => router.push('/dashboard')}
          className="self-start rounded-md bg-slate-900 px-4 py-2 text-sm font-medium text-white"
        >
          Back to dashboard
        </button>
      )}
    </div>
  );
}
