'use client';

import { FormEvent, useEffect, useState } from 'react';
import {
  ApiError,
  QuestionBankItem,
  QuestionFilters,
  questionsApi,
} from '@/lib/api-client';
import { QUESTION_CATEGORIES } from '@/lib/question-categories';

/**
 * Browse/filter the shared question bank, and generate new questions with
 * AI when it's thin for a role/company/topic combo. Talks only to
 * questionsApi from lib/api-client.ts — see docs/CHANGE-GUIDE.md.
 */
export function QuestionBank() {
  const [questions, setQuestions] = useState<QuestionBankItem[]>([]);
  const [filterOptions, setFilterOptions] = useState<QuestionFilters>({
    roles: [],
    companies: [],
    topics: [],
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [roleFilter, setRoleFilter] = useState('');
  const [companyFilter, setCompanyFilter] = useState('');
  const [topicFilter, setTopicFilter] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('');

  const [genRole, setGenRole] = useState('');
  const [genCompany, setGenCompany] = useState('');
  const [genTopic, setGenTopic] = useState('');
  const [genCategory, setGenCategory] = useState('');
  const [genCount, setGenCount] = useState(5);
  const [genError, setGenError] = useState<string | null>(null);
  const [generating, setGenerating] = useState(false);

  useEffect(() => {
    let cancelled = false;
    Promise.all([questionsApi.list(), questionsApi.filters()])
      .then(([q, f]) => {
        if (!cancelled) {
          setQuestions(q);
          setFilterOptions(f);
        }
      })
      .catch((err) => {
        if (!cancelled) setError(err instanceof ApiError ? err.message : 'Could not load questions.');
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  async function handleFilter(e: FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      setQuestions(
        await questionsApi.list({
          role: roleFilter || undefined,
          company: companyFilter || undefined,
          topic: topicFilter || undefined,
          category: categoryFilter || undefined,
        }),
      );
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not load questions.');
    } finally {
      setLoading(false);
    }
  }

  async function handleGenerate(e: FormEvent) {
    e.preventDefault();
    setGenError(null);

    if (genRole.trim().length < 2) {
      setGenError('Enter the role to generate questions for.');
      return;
    }

    setGenerating(true);
    try {
      const generated = await questionsApi.generate({
        role: genRole.trim(),
        company: genCompany.trim() || undefined,
        topic: genTopic.trim() || undefined,
        category: genCategory || undefined,
        count: genCount,
      });
      setQuestions((prev) => [...generated, ...prev]);
      questionsApi.filters().then(setFilterOptions).catch(() => {});
    } catch (err) {
      setGenError(err instanceof ApiError ? err.message : 'Could not generate questions. Please try again.');
    } finally {
      setGenerating(false);
    }
  }

  return (
    <div className="flex w-full max-w-3xl flex-col gap-8">
      <div>
        <h1 className="text-2xl font-semibold">Question bank</h1>
        <p className="mt-1 text-sm text-slate-600">
          Browse shared practice questions, or generate new ones for a role that&apos;s thin on questions.
        </p>
      </div>

      <section className="rounded-lg border border-slate-200 p-4">
        <h2 className="text-lg font-semibold">Generate questions</h2>
        <form onSubmit={handleGenerate} className="mt-2 flex flex-col gap-2">
          <div className="flex flex-wrap gap-2">
            <div className="flex flex-col gap-1">
              <label htmlFor="gen-role" className="text-sm font-medium">
                Role
              </label>
              <input
                id="gen-role"
                type="text"
                value={genRole}
                onChange={(e) => setGenRole(e.target.value)}
                placeholder="e.g. Backend Engineer"
                className="rounded-md border border-slate-300 px-3 py-2 text-sm"
              />
            </div>
            <div className="flex flex-col gap-1">
              <label htmlFor="gen-company" className="text-sm font-medium">
                Company (optional)
              </label>
              <input
                id="gen-company"
                type="text"
                value={genCompany}
                onChange={(e) => setGenCompany(e.target.value)}
                className="rounded-md border border-slate-300 px-3 py-2 text-sm"
              />
            </div>
            <div className="flex flex-col gap-1">
              <label htmlFor="gen-topic" className="text-sm font-medium">
                Topic (optional)
              </label>
              <input
                id="gen-topic"
                type="text"
                value={genTopic}
                onChange={(e) => setGenTopic(e.target.value)}
                className="rounded-md border border-slate-300 px-3 py-2 text-sm"
              />
            </div>
            <div className="flex flex-col gap-1">
              <label htmlFor="gen-category" className="text-sm font-medium">
                Category (optional)
              </label>
              <select
                id="gen-category"
                value={genCategory}
                onChange={(e) => setGenCategory(e.target.value)}
                className="rounded-md border border-slate-300 px-3 py-2 text-sm"
              >
                <option value="">Any</option>
                {QUESTION_CATEGORIES.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </div>
            <div className="flex flex-col gap-1">
              <label htmlFor="gen-count" className="text-sm font-medium">
                How many
              </label>
              <input
                id="gen-count"
                type="number"
                min={1}
                max={10}
                value={genCount}
                onChange={(e) => setGenCount(Number(e.target.value))}
                className="w-20 rounded-md border border-slate-300 px-3 py-2 text-sm"
              />
            </div>
          </div>

          {genError && (
            <p role="alert" className="text-sm text-red-600">
              {genError}
            </p>
          )}

          <button
            type="submit"
            disabled={generating}
            className="self-start rounded-md bg-slate-900 px-4 py-2 text-sm font-medium text-white disabled:opacity-50"
          >
            {generating ? 'Generating…' : 'Generate questions'}
          </button>
        </form>
      </section>

      <section>
        <h2 className="text-lg font-semibold">Browse</h2>
        <form onSubmit={handleFilter} className="mt-2 flex flex-wrap gap-2">
          <select
            aria-label="Filter by role"
            value={roleFilter}
            onChange={(e) => setRoleFilter(e.target.value)}
            className="rounded-md border border-slate-300 px-3 py-2 text-sm"
          >
            <option value="">All roles</option>
            {filterOptions.roles.map((r) => (
              <option key={r} value={r}>
                {r}
              </option>
            ))}
          </select>

          <select
            aria-label="Filter by company"
            value={companyFilter}
            onChange={(e) => setCompanyFilter(e.target.value)}
            className="rounded-md border border-slate-300 px-3 py-2 text-sm"
          >
            <option value="">All companies</option>
            {filterOptions.companies.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>

          <select
            aria-label="Filter by topic"
            value={topicFilter}
            onChange={(e) => setTopicFilter(e.target.value)}
            className="rounded-md border border-slate-300 px-3 py-2 text-sm"
          >
            <option value="">All topics</option>
            {filterOptions.topics.map((t) => (
              <option key={t} value={t}>
                {t}
              </option>
            ))}
          </select>

          <select
            aria-label="Filter by category"
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            className="rounded-md border border-slate-300 px-3 py-2 text-sm"
          >
            <option value="">All categories</option>
            {QUESTION_CATEGORIES.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>

          <button
            type="submit"
            className="rounded-md border border-slate-300 px-4 py-2 text-sm font-medium hover:bg-slate-100"
          >
            Search
          </button>
        </form>

        {error && (
          <p role="alert" className="mt-3 text-sm text-red-600">
            {error}
          </p>
        )}

        {loading ? (
          <p className="mt-4 text-sm text-slate-500">Loading…</p>
        ) : questions.length === 0 ? (
          <p className="mt-4 text-sm text-slate-500">
            No questions match yet — try generating some above.
          </p>
        ) : (
          <ul className="mt-4 flex flex-col gap-3">
            {questions.map((q) => (
              <li key={q.id} className="rounded-lg border border-slate-200 p-4">
                <p className="text-sm">{q.question}</p>
                <div className="mt-2 flex flex-wrap gap-2 text-xs text-slate-500">
                  <span className="rounded-full bg-slate-100 px-2 py-0.5">{q.role}</span>
                  {q.company && <span className="rounded-full bg-slate-100 px-2 py-0.5">{q.company}</span>}
                  {q.topic && <span className="rounded-full bg-slate-100 px-2 py-0.5">{q.topic}</span>}
                  {q.category && <span className="rounded-full bg-slate-100 px-2 py-0.5">{q.category}</span>}
                </div>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}
