'use client';

import { ReactNode, useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';

/**
 * Wrap any page that requires login with this. It redirects to /login if
 * there's no stored token. This is the pattern referenced in
 * docs/CHANGE-GUIDE.md under "How do I add a new protected page" — copy
 * app/dashboard/page.tsx, not this file itself.
 */
export function RequireAuth({ children }: { children: ReactNode }) {
  const router = useRouter();
  const [authorized, setAuthorized] = useState(false);

  useEffect(() => {
    const token = localStorage.getItem('accessToken');
    if (!token) {
      router.push('/login');
      return;
    }
    setAuthorized(true);
  }, [router]);

  if (!authorized) return null;
  return <>{children}</>;
}
