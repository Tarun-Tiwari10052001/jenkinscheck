'use client';

import { FormEvent, useState } from 'react';
import { useRouter } from 'next/navigation';
import { meetingAssistantApi, ApiError } from '@/lib/api-client';

export function StartMeetingForm() {
  const router = useRouter();
  const [title, setTitle] = useState('');
  const [contextNotes, setContextNotes] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);

    if (title.trim().length < 2) {
      setError('Give this session a title, e.g. "Customer renewal call".');
      return;
    }

    setSubmitting(true);
    try {
      const session = await meetingAssistantApi.start({
        title: title.trim(),
        contextNotes: contextNotes.trim() || undefined,
      });
      router.push(`/assistant/${session.id}`);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not start the session. Please try again.');
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="flex w-full max-w-lg flex-col gap-6">
      <div
        role="note"
        className="rounded-lg border border-amber-200 bg-amber-50 p-4 text-sm text-amber-900"
      >
        <p className="font-medium">Before you start:</p>
        <p className="mt-1">
          This assistant is visible on your own screen only — it doesn&apos;t hide itself from
          screen sharing or anyone on the call. Recording or transcribing a call may require
          notifying other participants, depending on your jurisdiction and company policy. Check
          before you start.
        </p>
      </div>

      <form onSubmit={handleSubmit} className="flex flex-col gap-4" noValidate>
        <div className="flex flex-col gap-1">
          <label htmlFor="title" className="text-sm font-medium">
            What&apos;s this call?
          </label>
          <input
            id="title"
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="e.g. Customer renewal call"
            className="rounded-md border border-slate-300 px-3 py-2 text-sm"
          />
        </div>

        <div className="flex flex-col gap-1">
          <label htmlFor="contextNotes" className="text-sm font-medium">
            Context (optional)
          </label>
          <textarea
            id="contextNotes"
            value={contextNotes}
            onChange={(e) => setContextNotes(e.target.value)}
            rows={4}
            placeholder="Anything that helps — what the call is about, your role, what you're trying to accomplish."
            className="rounded-md border border-slate-300 px-3 py-2 text-sm"
          />
        </div>

        {error && (
          <p role="alert" className="text-sm text-red-600">
            {error}
          </p>
        )}

        <button
          type="submit"
          disabled={submitting}
          className="self-start rounded-md bg-slate-900 px-4 py-2 text-sm font-medium text-white disabled:opacity-50"
        >
          {submitting ? 'Starting…' : 'Start session'}
        </button>
      </form>
    </div>
  );
}
