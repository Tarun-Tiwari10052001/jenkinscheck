'use client';

import { FormEvent, useState } from 'react';
import { useRouter } from 'next/navigation';
import { interviewsApi, ApiError } from '@/lib/api-client';

export function StartInterviewForm() {
  const router = useRouter();
  const [role, setRole] = useState('');
  const [company, setCompany] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);

    if (role.trim().length < 2) {
      setError('Enter the role you want to practice for.');
      return;
    }

    setSubmitting(true);
    try {
      const res = await interviewsApi.start({
        role: role.trim(),
        company: company.trim() || undefined,
      });
      router.push(`/interview/${res.session.id}`);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not start the interview. Please try again.');
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} className="flex w-full max-w-sm flex-col gap-4" noValidate>
      <div className="flex flex-col gap-1">
        <label htmlFor="role" className="text-sm font-medium">
          Role
        </label>
        <input
          id="role"
          type="text"
          value={role}
          onChange={(e) => setRole(e.target.value)}
          placeholder="e.g. Backend Engineer"
          className="rounded-md border border-slate-300 px-3 py-2 text-sm"
        />
      </div>

      <div className="flex flex-col gap-1">
        <label htmlFor="company" className="text-sm font-medium">
          Company (optional)
        </label>
        <input
          id="company"
          type="text"
          value={company}
          onChange={(e) => setCompany(e.target.value)}
          placeholder="e.g. Acme"
          className="rounded-md border border-slate-300 px-3 py-2 text-sm"
        />
      </div>

      {error && (
        <p role="alert" className="text-sm text-red-600">
          {error}
        </p>
      )}

      <button
        type="submit"
        disabled={submitting}
        className="rounded-md bg-slate-900 px-4 py-2 text-sm font-medium text-white disabled:opacity-50"
      >
        {submitting ? 'Starting…' : 'Start interview'}
      </button>
    </form>
  );
}
