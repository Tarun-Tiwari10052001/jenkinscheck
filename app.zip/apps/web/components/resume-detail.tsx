'use client';

import { FormEvent, useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import {
  ApiError,
  CoverLetterResult,
  ResumeSummary,
  TailorResult,
  resumesApi,
} from '@/lib/api-client';
import { parseFeedback } from '@/lib/parse-feedback';

interface Props {
  resumeId: string;
}

/**
 * Everything on the resume detail page: the general feedback, the "tailor
 * to a job description" tool, the cover letter generator, and delete.
 * Talks only to resumesApi from lib/api-client.ts — see docs/CHANGE-GUIDE.md.
 */
export function ResumeDetail({ resumeId }: Props) {
  const router = useRouter();
  const [resume, setResume] = useState<ResumeSummary | null>(null);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);

  const [jobDescription, setJobDescription] = useState('');
  const [tailorResult, setTailorResult] = useState<TailorResult | null>(null);
  const [tailorSubmitting, setTailorSubmitting] = useState(false);
  const [tailorError, setTailorError] = useState<string | null>(null);

  const [coverJobDescription, setCoverJobDescription] = useState('');
  const [coverCompany, setCoverCompany] = useState('');
  const [coverRole, setCoverRole] = useState('');
  const [coverLetter, setCoverLetter] = useState<CoverLetterResult | null>(null);
  const [coverSubmitting, setCoverSubmitting] = useState(false);
  const [coverError, setCoverError] = useState<string | null>(null);

  const [confirmingDelete, setConfirmingDelete] = useState(false);
  const [deleting, setDeleting] = useState(false);

  useEffect(() => {
    let cancelled = false;
    resumesApi
      .get(resumeId)
      .then((data) => {
        if (!cancelled) setResume(data);
      })
      .catch((err) => {
        if (!cancelled) setLoadError(err instanceof ApiError ? err.message : 'Could not load this resume.');
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [resumeId]);

  async function handleTailor(e: FormEvent) {
    e.preventDefault();
    setTailorError(null);
    setTailorResult(null);

    if (jobDescription.trim().length < 50) {
      setTailorError('Paste the full job description (at least 50 characters).');
      return;
    }

    setTailorSubmitting(true);
    try {
      setTailorResult(await resumesApi.tailor(resumeId, jobDescription.trim()));
    } catch (err) {
      setTailorError(err instanceof ApiError ? err.message : 'Could not compare against that job. Please try again.');
    } finally {
      setTailorSubmitting(false);
    }
  }

  async function handleCoverLetter(e: FormEvent) {
    e.preventDefault();
    setCoverError(null);
    setCoverLetter(null);

    if (coverJobDescription.trim().length < 50) {
      setCoverError('Paste the full job description (at least 50 characters).');
      return;
    }

    setCoverSubmitting(true);
    try {
      setCoverLetter(
        await resumesApi.coverLetter(resumeId, {
          jobDescription: coverJobDescription.trim(),
          company: coverCompany.trim() || undefined,
          role: coverRole.trim() || undefined,
        }),
      );
    } catch (err) {
      setCoverError(err instanceof ApiError ? err.message : 'Could not generate a cover letter. Please try again.');
    } finally {
      setCoverSubmitting(false);
    }
  }

  async function handleDelete() {
    setDeleting(true);
    try {
      await resumesApi.remove(resumeId);
      router.push('/dashboard');
    } catch {
      setDeleting(false);
      setConfirmingDelete(false);
    }
  }

  if (loading) {
    return <p className="text-sm text-slate-500">Loading resume…</p>;
  }

  if (loadError || !resume) {
    return (
      <p role="alert" className="text-sm text-red-600">
        {loadError ?? 'Resume not found.'}
      </p>
    );
  }

  const feedback = parseFeedback(resume.latestFeedback);

  return (
    <div className="flex w-full max-w-2xl flex-col gap-8">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-semibold">Your resume</h1>
        {!confirmingDelete ? (
          <button
            type="button"
            onClick={() => setConfirmingDelete(true)}
            className="text-sm text-red-600 hover:underline"
          >
            Delete
          </button>
        ) : (
          <span className="flex items-center gap-2 text-sm">
            Delete this resume?
            <button type="button" onClick={handleDelete} disabled={deleting} className="font-medium text-red-600">
              {deleting ? 'Deleting…' : 'Yes, delete'}
            </button>
            <button type="button" onClick={() => setConfirmingDelete(false)} className="text-slate-500">
              Cancel
            </button>
          </span>
        )}
      </div>

      <section>
        <h2 className="text-lg font-semibold">Feedback</h2>
        {feedback ? (
          <>
            <p className="mt-1 text-sm">
              Score: <strong>{feedback.score}</strong>/100
            </p>
            <div className="mt-2">
              <h3 className="text-sm font-medium">Strengths</h3>
              <ul className="list-disc pl-5 text-sm text-slate-600">
                {feedback.strengths.map((s, i) => (
                  <li key={i}>{s}</li>
                ))}
              </ul>
            </div>
            <div className="mt-2">
              <h3 className="text-sm font-medium">Improvements</h3>
              <ul className="list-disc pl-5 text-sm text-slate-600">
                {feedback.improvements.map((s, i) => (
                  <li key={i}>{s}</li>
                ))}
              </ul>
            </div>
          </>
        ) : (
          <p className="mt-1 text-sm text-slate-600">{resume.latestFeedback ?? 'No feedback available.'}</p>
        )}
      </section>

      <section>
        <h2 className="text-lg font-semibold">Tailor to a job description</h2>
        <form onSubmit={handleTailor} className="mt-2 flex flex-col gap-2">
          <label htmlFor="tailor-jd" className="text-sm font-medium">
            Job description
          </label>
          <textarea
            id="tailor-jd"
            value={jobDescription}
            onChange={(e) => setJobDescription(e.target.value)}
            rows={6}
            className="rounded-md border border-slate-300 px-3 py-2 text-sm"
          />
          {tailorError && (
            <p role="alert" className="text-sm text-red-600">
              {tailorError}
            </p>
          )}
          <button
            type="submit"
            disabled={tailorSubmitting}
            className="self-start rounded-md bg-slate-900 px-4 py-2 text-sm font-medium text-white disabled:opacity-50"
          >
            {tailorSubmitting ? 'Comparing…' : 'Compare to this job'}
          </button>
        </form>

        {tailorResult && (
          <div className="mt-4 rounded-lg border border-slate-200 p-4">
            <p className="text-sm">
              Match score: <strong>{tailorResult.matchScore ?? '—'}</strong>/100
            </p>
            {tailorResult.missingKeywords.length > 0 && (
              <div className="mt-2">
                <h3 className="text-sm font-medium">Missing keywords</h3>
                <ul className="list-disc pl-5 text-sm text-slate-600">
                  {tailorResult.missingKeywords.map((k, i) => (
                    <li key={i}>{k}</li>
                  ))}
                </ul>
              </div>
            )}
            <div className="mt-2">
              <h3 className="text-sm font-medium">Suggestions</h3>
              <ul className="list-disc pl-5 text-sm text-slate-600">
                {tailorResult.suggestions.map((s, i) => (
                  <li key={i}>{s}</li>
                ))}
              </ul>
            </div>
          </div>
        )}
      </section>

      <section>
        <h2 className="text-lg font-semibold">Generate a cover letter</h2>
        <form onSubmit={handleCoverLetter} className="mt-2 flex flex-col gap-2">
          <div className="flex gap-2">
            <input
              type="text"
              value={coverRole}
              onChange={(e) => setCoverRole(e.target.value)}
              placeholder="Role (optional)"
              aria-label="Role"
              className="w-1/2 rounded-md border border-slate-300 px-3 py-2 text-sm"
            />
            <input
              type="text"
              value={coverCompany}
              onChange={(e) => setCoverCompany(e.target.value)}
              placeholder="Company (optional)"
              aria-label="Company"
              className="w-1/2 rounded-md border border-slate-300 px-3 py-2 text-sm"
            />
          </div>
          <label htmlFor="cover-jd" className="text-sm font-medium">
            Job description
          </label>
          <textarea
            id="cover-jd"
            value={coverJobDescription}
            onChange={(e) => setCoverJobDescription(e.target.value)}
            rows={6}
            className="rounded-md border border-slate-300 px-3 py-2 text-sm"
          />
          {coverError && (
            <p role="alert" className="text-sm text-red-600">
              {coverError}
            </p>
          )}
          <button
            type="submit"
            disabled={coverSubmitting}
            className="self-start rounded-md bg-slate-900 px-4 py-2 text-sm font-medium text-white disabled:opacity-50"
          >
            {coverSubmitting ? 'Writing…' : 'Generate cover letter'}
          </button>
        </form>

        {coverLetter && (
          <div className="mt-4 rounded-lg border border-slate-200 p-4">
            <p className="whitespace-pre-wrap text-sm">{coverLetter.content}</p>
          </div>
        )}
      </section>
    </div>
  );
}
