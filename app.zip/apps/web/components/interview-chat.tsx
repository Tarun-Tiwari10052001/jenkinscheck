'use client';

import { FormEvent, useEffect, useRef, useState } from 'react';
import { useRouter } from 'next/navigation';
import {
  ApiError,
  InterviewMessage,
  InterviewStatus,
  interviewsApi,
} from '@/lib/api-client';
import { parseFeedback } from '@/lib/parse-feedback';
import {
  cancelSpeech,
  createSpeechRecognition,
  isSpeechRecognitionSupported,
  isSpeechSynthesisSupported,
  speak,
  SpeechRecognitionController,
} from '@/lib/speech';

interface Props {
  sessionId: string;
}

/**
 * The whole mock-interview chat flow: loads existing history, sends
 * answers, ends the interview, shows feedback. Talks only to
 * `interviewsApi` from lib/api-client.ts — see docs/CHANGE-GUIDE.md.
 *
 * Voice mode (see lib/speech.ts) is purely additive on top of this: the
 * interviewer's questions can be read aloud, and an answer can be
 * dictated into the same `answer` textarea used for typing. The backend
 * never knows or cares whether an answer was typed or spoken — voice
 * mode only ever produces the same plain text `POST /interviews/:id/answer`
 * call that typing does.
 */
export function InterviewChat({ sessionId }: Props) {
  const router = useRouter();
  const [messages, setMessages] = useState<InterviewMessage[]>([]);
  const [status, setStatus] = useState<InterviewStatus | null>(null);
  const [role, setRole] = useState('');
  const [company, setCompany] = useState<string | null>(null);
  const [feedbackRaw, setFeedbackRaw] = useState<string | null>(null);
  const [score, setScore] = useState<number | null>(null);
  const [answer, setAnswer] = useState('');
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [completing, setCompleting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [voiceMode, setVoiceMode] = useState(false);
  const [listening, setListening] = useState(false);
  const [speaking, setSpeaking] = useState(false);
  const recognitionRef = useRef<SpeechRecognitionController | null>(null);
  const lastSpokenMessageId = useRef<string | null>(null);

  const recognitionSupported = isSpeechRecognitionSupported();
  const synthesisSupported = isSpeechSynthesisSupported();

  useEffect(() => {
    let cancelled = false;

    async function load() {
      try {
        const session = await interviewsApi.get(sessionId);
        if (cancelled) return;
        setMessages(session.messages);
        setStatus(session.status);
        setRole(session.role);
        setCompany(session.company);
        setFeedbackRaw(session.feedback);
        setScore(session.score);
      } catch (err) {
        if (!cancelled) {
          setError(err instanceof ApiError ? err.message : 'Could not load this interview.');
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    }

    load();
    return () => {
      cancelled = true;
    };
  }, [sessionId]);

  // Speaks the current interviewer question aloud whenever voice mode is
  // on and a question we haven't already spoken is the latest message —
  // covers both "a new question just arrived" and "voice mode was just
  // turned on partway through the interview" in one effect.
  useEffect(() => {
    if (!voiceMode || messages.length === 0) return;
    const last = messages[messages.length - 1];
    if (last.role !== 'INTERVIEWER' || last.id === lastSpokenMessageId.current) return;

    lastSpokenMessageId.current = last.id;
    speak(last.content, {
      onStart: () => setSpeaking(true),
      onEnd: () => setSpeaking(false),
    });
  }, [voiceMode, messages]);

  // Stop any speech/listening in flight when leaving the page.
  useEffect(() => {
    return () => {
      cancelSpeech();
      recognitionRef.current?.stop();
    };
  }, []);

  function toggleVoiceMode() {
    setVoiceMode((prev) => {
      const next = !prev;
      if (!next) {
        cancelSpeech();
        recognitionRef.current?.stop();
        setListening(false);
        setSpeaking(false);
      }
      return next;
    });
  }

  function toggleListening() {
    if (listening) {
      recognitionRef.current?.stop();
      return;
    }

    cancelSpeech();
    setSpeaking(false);
    setError(null);

    const controller = createSpeechRecognition({
      onResult: (result) => {
        setAnswer(result.transcript);
      },
      onEnd: () => {
        setListening(false);
      },
      onError: (message) => {
        setListening(false);
        setError(`Voice input error: ${message}`);
      },
    });

    if (!controller) return;
    recognitionRef.current = controller;
    setListening(true);
    controller.start();
  }

  async function handleSubmitAnswer(e: FormEvent) {
    e.preventDefault();
    setError(null);

    if (listening) {
      recognitionRef.current?.stop();
      setListening(false);
    }

    const trimmed = answer.trim();
    if (trimmed.length === 0) {
      setError('Enter an answer before sending.');
      return;
    }

    setSubmitting(true);
    setMessages((prev) => [
      ...prev,
      { id: `local-${prev.length}-a`, role: 'CANDIDATE', content: trimmed, sequenceNumber: prev.length + 1 },
    ]);
    setAnswer('');

    try {
      const res = await interviewsApi.answer(sessionId, trimmed);
      setMessages((prev) => [
        ...prev,
        { id: `local-${prev.length}-q`, role: 'INTERVIEWER', content: res.question, sequenceNumber: prev.length + 1 },
      ]);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not send your answer. Please try again.');
    } finally {
      setSubmitting(false);
    }
  }

  async function handleComplete() {
    setError(null);
    setCompleting(true);
    try {
      const session = await interviewsApi.complete(sessionId);
      setStatus(session.status);
      setFeedbackRaw(session.feedback);
      setScore(session.score);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not end the interview. Please try again.');
    } finally {
      setCompleting(false);
    }
  }

  if (loading) {
    return <p className="text-sm text-slate-500">Loading interview…</p>;
  }

  const feedback = parseFeedback(feedbackRaw);
  const canComplete = messages.length >= 2;

  return (
    <div className="flex w-full max-w-2xl flex-col gap-6">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h1 className="text-xl font-semibold">
            {role}
            {company ? ` at ${company}` : ''}
          </h1>
          <p className="text-sm text-slate-500">
            {status === 'COMPLETED' ? 'Completed' : 'In progress'}
          </p>
        </div>

        {status === 'IN_PROGRESS' && synthesisSupported && (
          <label className="flex items-center gap-2 text-sm">
            <input
              type="checkbox"
              checked={voiceMode}
              onChange={toggleVoiceMode}
              aria-label="Voice mode"
            />
            Voice mode
          </label>
        )}
      </div>

      {status === 'IN_PROGRESS' && voiceMode && speaking && (
        <p className="text-sm text-slate-500">🔊 Speaking the question…</p>
      )}

      <ul className="flex flex-col gap-3">
        {messages.map((m) => (
          <li
            key={m.id}
            className={
              m.role === 'INTERVIEWER'
                ? 'max-w-lg rounded-lg bg-slate-100 px-4 py-2 text-sm'
                : 'ml-auto max-w-lg rounded-lg bg-slate-900 px-4 py-2 text-sm text-white'
            }
          >
            {m.content}
          </li>
        ))}
      </ul>

      {error && (
        <p role="alert" className="text-sm text-red-600">
          {error}
        </p>
      )}

      {status === 'IN_PROGRESS' && (
        <>
          <form onSubmit={handleSubmitAnswer} className="flex flex-col gap-2">
            <label htmlFor="answer" className="text-sm font-medium">
              Your answer
            </label>
            <textarea
              id="answer"
              value={answer}
              onChange={(e) => setAnswer(e.target.value)}
              rows={4}
              className="rounded-md border border-slate-300 px-3 py-2 text-sm"
            />
            {listening && <p className="text-sm text-slate-500">🎤 Listening…</p>}
            <div className="flex gap-2">
              <button
                type="submit"
                disabled={submitting}
                className="self-start rounded-md bg-slate-900 px-4 py-2 text-sm font-medium text-white disabled:opacity-50"
              >
                {submitting ? 'Sending…' : 'Send answer'}
              </button>
              {voiceMode && recognitionSupported && (
                <button
                  type="button"
                  onClick={toggleListening}
                  className="self-start rounded-md border border-slate-300 px-4 py-2 text-sm font-medium hover:bg-slate-100"
                >
                  {listening ? '⏹ Stop' : '🎤 Speak your answer'}
                </button>
              )}
            </div>
            {voiceMode && !recognitionSupported && (
              <p className="text-sm text-slate-500">
                Voice input isn&apos;t supported in this browser — try Chrome or Edge. Questions will
                still be read aloud.
              </p>
            )}
          </form>

          <button
            type="button"
            onClick={handleComplete}
            disabled={completing || !canComplete}
            title={!canComplete ? 'Answer at least one question first' : undefined}
            className="self-start rounded-md border border-slate-300 px-4 py-2 text-sm font-medium disabled:opacity-50"
          >
            {completing ? 'Ending interview…' : 'End interview & get feedback'}
          </button>
        </>
      )}

      {status === 'COMPLETED' && (
        <div className="rounded-lg border border-slate-200 p-4">
          <h2 className="text-lg font-semibold">Feedback</h2>
          {feedback ? (
            <>
              <p className="mt-1 text-sm">
                Score: <strong>{feedback.score}</strong>/100
              </p>
              <div className="mt-3">
                <h3 className="text-sm font-medium">Strengths</h3>
                <ul className="list-disc pl-5 text-sm text-slate-600">
                  {feedback.strengths.map((s, i) => (
                    <li key={i}>{s}</li>
                  ))}
                </ul>
              </div>
              <div className="mt-3">
                <h3 className="text-sm font-medium">Improvements</h3>
                <ul className="list-disc pl-5 text-sm text-slate-600">
                  {feedback.improvements.map((s, i) => (
                    <li key={i}>{s}</li>
                  ))}
                </ul>
              </div>
            </>
          ) : (
            <p className="mt-1 text-sm text-slate-600">{feedbackRaw ?? `Score: ${score ?? '—'}`}</p>
          )}
          <button
            type="button"
            onClick={() => router.push('/dashboard')}
            className="mt-4 rounded-md bg-slate-900 px-4 py-2 text-sm font-medium text-white"
          >
            Back to dashboard
          </button>
        </div>
      )}
    </div>
  );
}
