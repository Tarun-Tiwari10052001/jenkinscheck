'use client';

import { useEffect, useState } from 'react';

const STORAGE_KEY = 'app-transparency';
const DEFAULT_TRANSPARENCY = 100;

export function TransparencySettings() {
  const [transparency, setTransparency] = useState(DEFAULT_TRANSPARENCY);

  useEffect(() => {
    const saved = window.localStorage.getItem(STORAGE_KEY);
    if (saved !== null) {
      const value = Number(saved);
      if (Number.isFinite(value)) setTransparency(Math.min(100, Math.max(0, value)));
    }
  }, []);

  useEffect(() => {
    document.documentElement.style.setProperty('--app-bg-alpha', String(transparency / 100));
    window.localStorage.setItem(STORAGE_KEY, String(transparency));
  }, [transparency]);

  return (
    <details className="fixed bottom-4 right-4 z-50 w-64 rounded-lg border border-slate-300 bg-white/95 p-3 shadow-lg backdrop-blur">
      <summary className="cursor-pointer text-sm font-medium select-none">
        Display transparency
      </summary>
      <div className="mt-3">
        <div className="flex items-center justify-between text-xs text-slate-600">
          <span>Transparent</span>
          <span>{transparency}% opaque</span>
        </div>
        <input
          aria-label="Display transparency"
          type="range"
          min="0"
          max="100"
          step="5"
          value={transparency}
          onChange={(event) => setTransparency(Number(event.target.value))}
          className="mt-2 w-full"
        />
        <p className="mt-2 text-xs text-slate-500">
          Lower the value to make the app background more transparent. Your text and controls stay fully visible.
        </p>
        <button
          type="button"
          onClick={() => setTransparency(DEFAULT_TRANSPARENCY)}
          className="mt-2 rounded-md border border-slate-300 px-3 py-1.5 text-xs font-medium hover:bg-slate-100"
        >
          Reset
        </button>
      </div>
    </details>
  );
}
