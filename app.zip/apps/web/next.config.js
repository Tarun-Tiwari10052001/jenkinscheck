/** @type {import('next').NextConfig} */
const nextConfig = {
  // Produces a minimal, self-contained server (.next/standalone) instead of
  // requiring the full node_modules tree at runtime. apps/desktop spawns
  // this as a child process — see apps/desktop/README.md.
  output: 'standalone',
};
module.exports = nextConfig;
