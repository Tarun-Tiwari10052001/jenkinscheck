# Web (Next.js)

See `../../docs/CHANGE-GUIDE.md` first.

## What's here

- `app/page.tsx` — landing page
- `app/login`, `app/signup` — thin pages wrapping `components/login-form.tsx`
  and `components/signup-form.tsx`, which own all form logic and state
- `app/dashboard` — lists the user's past sessions, resumes, and
  Meeting Assistant sessions, links to start each, and links to the
  question bank, behind `components/require-auth.tsx`
- `app/interview/new` — thin page wrapping `components/start-interview-form.tsx`
- `app/interview/[id]` — the practice chat itself, thin page wrapping
  `components/interview-chat.tsx` (all the state/logic lives there,
  including voice mode — see below)
- `app/resume/new` — thin page wrapping `components/resume-upload-form.tsx`
- `app/resume/[id]` — resume feedback, job-description tailoring, and
  cover letter generation, thin page wrapping `components/resume-detail.tsx`
- `app/questions` — thin page wrapping `components/question-bank.tsx`
  (generate new questions, browse/filter the shared bank)
- `app/assistant/new` — thin page wrapping `components/start-meeting-form.tsx`
  (includes a visible consent/visibility reminder before a session starts)
- `app/assistant/[id]` — the live Meeting Assistant session, thin page
  wrapping `components/meeting-assistant.tsx` — see
  `docs/CHANGE-GUIDE.md`'s Meeting Assistant row before changing this
  one; it exists inside a deliberate scope boundary, not an incidental one
- `lib/api-client.ts` — the only place that talks to the backend; every
  component calls through this, never `fetch` directly
- `lib/parse-feedback.ts` — parses the JSON feedback string returned by
  both a completed interview and a resume's general feedback (same shape
  on purpose — see `apps/api/src/ai/feedback-parser.ts`)
- `lib/speech.ts` — wraps the browser's native Web Speech API (dictation
  + text-to-speech), used by both `interview-chat.tsx` (voice mode) and
  `meeting-assistant.tsx` (live transcription). No API key, no backend
  involvement — see "Why voice mode uses the browser's Web Speech API"
  in `../../ARCHITECTURE.md` for the trade-offs, notably that dictation
  currently only works in Chrome/Edge.

## Voice mode browser support

Reading questions aloud (`speechSynthesis`) works in effectively every
modern browser. Dictating an answer (`SpeechRecognition`) currently only
works in Chrome and Edge — Firefox and Safari don't support it, or
support it only partially. `interview-chat.tsx` checks
`isSpeechRecognitionSupported()` / `isSpeechSynthesisSupported()` from
`lib/speech.ts` before showing the relevant controls, so unsupported
browsers just don't see a broken button — voice mode quietly falls back
to "questions read aloud, answers still typed" rather than offering
dictation that wouldn't work.

## Auth storage note

The access token is stored in `localStorage` for this scaffold. That's fine
for local development but worth revisiting before a real launch — an
httpOnly cookie set by the API is the more XSS-resistant option and is a
reasonable Phase 1 follow-up, not a Phase 0 blocker.

## Commands

```bash
npm run dev      # local dev server, http://localhost:3000
npm run build    # production build (also type-checks)
npm test         # component tests
```

## Environment

Set `NEXT_PUBLIC_API_URL` if the API isn't running on the default
`http://localhost:3001`.
