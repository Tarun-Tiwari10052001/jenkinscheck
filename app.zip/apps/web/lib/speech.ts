// Explicit reference, not relying on tsconfig's include glob to pick up
// speech.d.ts automatically — it should, but empirically didn't reliably
// across TypeScript versions in this monorepo (observed failing on 5.9.3
// after npm workspace hoisting changed which TS version actually got
// resolved, despite working fine before that). This line makes the
// ambient SpeechRecognition types load regardless of that.
/// <reference path="./speech.d.ts" />

/**
 * Thin wrapper around the browser's native Web Speech API — no API key,
 * no backend change, no third-party vendor. This is the same "simplest
 * version first" call made elsewhere in this app: the browser's built-in
 * speech-to-text and text-to-speech are free, require no network round trip
 * through our backend, and are good enough for this experience. A dedicated
 * STT/TTS vendor (Deepgram, ElevenLabs,
 * etc.) remains a reasonable upgrade later — swapping it in would only
 * mean changing this one file; nothing in InterviewChat would need to
 * change, since it only calls the functions below.
 *
 * Kept framework-agnostic (no React) so it's plain-function testable —
 * see speech.spec.ts. Everything here touches `window`/browser globals
 * defensively (checked, never assumed present), since Web Speech API
 * support varies: Chrome and Edge support both speech recognition and
 * synthesis; Firefox and Safari have partial/no SpeechRecognition
 * support as of this writing. Always check `isSpeechRecognitionSupported`
 * / `isSpeechSynthesisSupported` before offering voice controls in the UI.
 */

export interface SpeechRecognitionResult {
  transcript: string;
  isFinal: boolean;
}

export interface SpeechRecognitionController {
  start(): void;
  stop(): void;
}

export function isSpeechRecognitionSupported(): boolean {
  if (typeof window === 'undefined') return false;
  return Boolean(window.SpeechRecognition || (window as any).webkitSpeechRecognition);
}

export function isSpeechSynthesisSupported(): boolean {
  return typeof window !== 'undefined' && Boolean(window.speechSynthesis);
}

/**
 * Returns null when unsupported — callers should check
 * isSpeechRecognitionSupported() first and hide voice input entirely
 * rather than relying on this returning null, but it's a safe fallback
 * either way.
 */
export function createSpeechRecognition(callbacks: {
  onResult: (result: SpeechRecognitionResult) => void;
  onEnd: () => void;
  onError: (message: string) => void;
}): SpeechRecognitionController | null {
  if (typeof window === 'undefined') return null;
  const SpeechRecognitionCtor = window.SpeechRecognition || (window as any).webkitSpeechRecognition;
  if (!SpeechRecognitionCtor) return null;

  const recognition = new SpeechRecognitionCtor();
  recognition.continuous = false;
  recognition.interimResults = true;
  recognition.lang = 'en-US';

  recognition.onresult = (event: any) => {
    const result = event.results[event.results.length - 1];
    callbacks.onResult({ transcript: result[0].transcript, isFinal: result.isFinal });
  };
  recognition.onerror = (event: any) => callbacks.onError(event.error ?? 'Speech recognition error');
  recognition.onend = () => callbacks.onEnd();

  return {
    start: () => recognition.start(),
    stop: () => recognition.stop(),
  };
}

/** Speaks text aloud. No-ops silently if speech synthesis isn't supported. */
export function speak(text: string, callbacks?: { onStart?: () => void; onEnd?: () => void }): void {
  if (!isSpeechSynthesisSupported()) return;
  window.speechSynthesis.cancel(); // never overlap with a prior utterance
  const utterance = new SpeechSynthesisUtterance(text);
  if (callbacks?.onStart) utterance.onstart = callbacks.onStart;
  if (callbacks?.onEnd) utterance.onend = callbacks.onEnd;
  window.speechSynthesis.speak(utterance);
}

export function cancelSpeech(): void {
  if (isSpeechSynthesisSupported()) window.speechSynthesis.cancel();
}
