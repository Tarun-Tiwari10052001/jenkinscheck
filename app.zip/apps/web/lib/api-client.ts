const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL ?? 'http://localhost:3001';

export class ApiError extends Error {
  constructor(public status: number, message: string) {
    super(message);
  }
}

/**
 * The only file that calls the backend. Every component goes through
 * `authApi` or `interviewsApi`, never `fetch` directly — see
 * docs/CHANGE-GUIDE.md. Pass `auth: true` for any endpoint that requires
 * the JWT guard on the API side; the token is read from localStorage,
 * see components/require-auth.tsx for where it's set.
 */
async function request<T>(
  path: string,
  options: RequestInit = {},
  opts: { auth?: boolean } = {},
): Promise<T> {
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(options.headers as Record<string, string> | undefined),
  };

  if (opts.auth) {
    const token = typeof window !== 'undefined' ? localStorage.getItem('accessToken') : null;
    if (token) headers.Authorization = `Bearer ${token}`;
  }

  const res = await fetch(`${API_BASE_URL}${path}`, { ...options, headers });
  const body = await res.json().catch(() => null);

  if (!res.ok) {
    throw new ApiError(res.status, body?.message ?? 'Something went wrong. Please try again.');
  }

  return body as T;
}

export interface AuthResponse {
  accessToken: string;
  user: { id: string; email: string; name: string | null };
}

export const authApi = {
  register: (data: { email: string; password: string; name?: string }) =>
    request<AuthResponse>('/auth/register', { method: 'POST', body: JSON.stringify(data) }),

  login: (data: { email: string; password: string }) =>
    request<AuthResponse>('/auth/login', { method: 'POST', body: JSON.stringify(data) }),
};

export type InterviewStatus = 'IN_PROGRESS' | 'COMPLETED' | 'ABANDONED';

export interface InterviewSessionSummary {
  id: string;
  role: string;
  company: string | null;
  status: InterviewStatus;
  score: number | null;
  createdAt: string;
  completedAt: string | null;
}

export interface InterviewMessage {
  id: string;
  role: 'INTERVIEWER' | 'CANDIDATE';
  content: string;
  sequenceNumber: number;
}

export interface InterviewSessionDetail extends InterviewSessionSummary {
  feedback: string | null;
  messages: InterviewMessage[];
}

export interface StartInterviewResponse {
  session: InterviewSessionSummary;
  question: string;
}

export interface AnswerResponse {
  question: string;
  questionCount: number;
  suggestWrapUp: boolean;
}

export const interviewsApi = {
  start: (data: { role: string; company?: string }) =>
    request<StartInterviewResponse>(
      '/interviews',
      { method: 'POST', body: JSON.stringify(data) },
      { auth: true },
    ),

  list: () => request<InterviewSessionSummary[]>('/interviews', {}, { auth: true }),

  get: (id: string) => request<InterviewSessionDetail>(`/interviews/${id}`, {}, { auth: true }),

  answer: (id: string, content: string) =>
    request<AnswerResponse>(
      `/interviews/${id}/answer`,
      { method: 'POST', body: JSON.stringify({ content }) },
      { auth: true },
    ),

  complete: (id: string) =>
    request<InterviewSessionDetail>(`/interviews/${id}/complete`, { method: 'POST' }, { auth: true }),
};

export interface ResumeSummary {
  id: string;
  content: string;
  latestFeedback: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface TailorResult {
  matchScore: number | null;
  missingKeywords: string[];
  suggestions: string[];
}

export interface CoverLetterResult {
  content: string;
}

export const resumesApi = {
  create: (content: string) =>
    request<ResumeSummary>('/resumes', { method: 'POST', body: JSON.stringify({ content }) }, { auth: true }),

  list: () => request<ResumeSummary[]>('/resumes', {}, { auth: true }),

  get: (id: string) => request<ResumeSummary>(`/resumes/${id}`, {}, { auth: true }),

  remove: (id: string) => request<void>(`/resumes/${id}`, { method: 'DELETE' }, { auth: true }),

  tailor: (id: string, jobDescription: string) =>
    request<TailorResult>(
      `/resumes/${id}/tailor`,
      { method: 'POST', body: JSON.stringify({ jobDescription }) },
      { auth: true },
    ),

  coverLetter: (id: string, data: { jobDescription: string; company?: string; role?: string }) =>
    request<CoverLetterResult>(
      `/resumes/${id}/cover-letter`,
      { method: 'POST', body: JSON.stringify(data) },
      { auth: true },
    ),
};

export interface QuestionBankItem {
  id: string;
  role: string;
  company: string | null;
  topic: string | null;
  category: string | null;
  question: string;
  createdAt: string;
}

export interface QuestionFilters {
  roles: string[];
  companies: string[];
  topics: string[];
}

export const questionsApi = {
  list: (params: { role?: string; company?: string; topic?: string; category?: string } = {}) => {
    const search = new URLSearchParams(
      Object.entries(params).filter(([, v]) => v) as [string, string][],
    ).toString();
    return request<QuestionBankItem[]>(`/questions${search ? `?${search}` : ''}`, {}, { auth: true });
  },

  filters: () => request<QuestionFilters>('/questions/filters', {}, { auth: true }),

  generate: (data: { role: string; company?: string; topic?: string; category?: string; count?: number }) =>
    request<QuestionBankItem[]>(
      '/questions/generate',
      { method: 'POST', body: JSON.stringify(data) },
      { auth: true },
    ),
};

export type MeetingSessionStatus = 'ACTIVE' | 'ENDED';

export interface MeetingSessionSummary {
  id: string;
  title: string;
  status: MeetingSessionStatus;
  createdAt: string;
  endedAt: string | null;
}

export interface MeetingTurn {
  id: string;
  speaker: 'OTHER' | 'ME';
  content: string;
  sequenceNumber: number;
}

export interface MeetingSessionDetail extends MeetingSessionSummary {
  contextNotes: string | null;
  turns: MeetingTurn[];
}

export const meetingAssistantApi = {
  start: (data: { title: string; contextNotes?: string }) =>
    request<MeetingSessionDetail>(
      '/meeting-assistant/sessions',
      { method: 'POST', body: JSON.stringify(data) },
      { auth: true },
    ),

  list: () => request<MeetingSessionSummary[]>('/meeting-assistant/sessions', {}, { auth: true }),

  get: (id: string) =>
    request<MeetingSessionDetail>(`/meeting-assistant/sessions/${id}`, {}, { auth: true }),

  remove: (id: string) =>
    request<void>(`/meeting-assistant/sessions/${id}`, { method: 'DELETE' }, { auth: true }),

  suggest: (id: string, transcript: string) =>
    request<{ suggestion: string }>(
      `/meeting-assistant/sessions/${id}/suggest`,
      { method: 'POST', body: JSON.stringify({ transcript }) },
      { auth: true },
    ),

  logTurn: (id: string, content: string) =>
    request<MeetingTurn>(
      `/meeting-assistant/sessions/${id}/log`,
      { method: 'POST', body: JSON.stringify({ content }) },
      { auth: true },
    ),

  end: (id: string) =>
    request<MeetingSessionDetail>(
      `/meeting-assistant/sessions/${id}/end`,
      { method: 'POST' },
      { auth: true },
    ),
};
