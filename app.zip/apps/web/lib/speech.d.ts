/**
 * SpeechRecognition isn't part of TypeScript's standard DOM lib (it's
 * still a non-standard/experimental Web API), so it needs an ambient
 * declaration here. Only the members speech.ts actually uses are typed —
 * this isn't a complete spec implementation.
 */
interface SpeechRecognitionEventResult {
  0: { transcript: string };
  isFinal: boolean;
}

interface SpeechRecognitionEvent extends Event {
  results: ArrayLike<SpeechRecognitionEventResult>;
}

interface SpeechRecognitionErrorEvent extends Event {
  error: string;
}

declare class SpeechRecognition extends EventTarget {
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  onresult: ((event: SpeechRecognitionEvent) => void) | null;
  onerror: ((event: SpeechRecognitionErrorEvent) => void) | null;
  onend: (() => void) | null;
  start(): void;
  stop(): void;
  abort(): void;
}

interface Window {
  SpeechRecognition?: typeof SpeechRecognition;
  webkitSpeechRecognition?: typeof SpeechRecognition;
}
