/**
 * Mirrors apps/api/src/questions/question-prompts.ts's QUESTION_CATEGORIES.
 * Duplicated on purpose, not imported — frontend and backend are separate
 * deployables. Keep the two lists in sync by hand if this ever changes.
 */
export const QUESTION_CATEGORIES = [
  'behavioral',
  'technical',
  'system-design',
  'culture-fit',
  'other',
] as const;
