/**
 * Parses the JSON feedback string stored by the application. Never throws —
 * returns null on anything unexpected, so
 * the UI can fall back to showing the raw text instead of crashing.
 */
export interface ParsedFeedback {
  score: number;
  strengths: string[];
  improvements: string[];
}

export function parseFeedback(raw: string | null): ParsedFeedback | null {
  if (!raw) return null;
  try {
    const parsed = JSON.parse(raw);
    if (
      typeof parsed.score === 'number' &&
      Array.isArray(parsed.strengths) &&
      Array.isArray(parsed.improvements)
    ) {
      return parsed;
    }
    return null;
  } catch {
    return null;
  }
}
