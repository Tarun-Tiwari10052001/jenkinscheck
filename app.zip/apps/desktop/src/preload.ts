import { contextBridge } from 'electron';

/**
 * No privileged APIs are exposed to the renderer today — this app is the
 * existing web frontend running inside a native window, nothing more. If
 * a future feature needs native capabilities (e.g. local file access,
 * native notifications), expose it here via contextBridge rather than
 * enabling nodeIntegration on the window. `window.desktopApp.isElectron`
 * lets the web app detect it's running inside the shell if that's ever
 * useful (e.g. hiding a "download our desktop app" banner).
 */
contextBridge.exposeInMainWorld('desktopApp', {
  isElectron: true,
});
