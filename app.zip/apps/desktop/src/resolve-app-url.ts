/**
 * Decides which URL the Electron window should load. No Electron imports
 * — pure function, testable directly. See resolve-app-url.spec.ts.
 */
export const DEFAULT_DEV_URL = 'http://localhost:3000';
export const DEFAULT_PACKAGED_PORT = 4300;

export interface ResolveAppUrlOptions {
  /** Pass app.isPackaged from Electron's main process — kept as a plain
   * boolean parameter here so this file never imports 'electron'. */
  isPackaged: boolean;
  env?: NodeJS.ProcessEnv;
}

export function resolveAppUrl(options: ResolveAppUrlOptions): string {
  const env = options.env ?? process.env;

  // Escape hatch for advanced users pointing the shell at a custom
  // deployment (e.g. a staging web build) — wins in either mode.
  if (env.DESKTOP_WEB_URL) return env.DESKTOP_WEB_URL;

  if (!options.isPackaged) {
    // Dev mode assumes `npm run dev:web` is already running separately —
    // see apps/desktop/README.md. The desktop shell doesn't spawn the dev
    // server itself; Next.js's dev server has its own hot-reload process
    // management that a wrapper would only get in the way of.
    return DEFAULT_DEV_URL;
  }

  return `http://localhost:${resolveServerPort({ env })}`;
}

export function resolveServerPort(options: { env?: NodeJS.ProcessEnv } = {}): number {
  const env = options.env ?? process.env;
  return env.DESKTOP_SERVER_PORT ? Number(env.DESKTOP_SERVER_PORT) : DEFAULT_PACKAGED_PORT;
}
