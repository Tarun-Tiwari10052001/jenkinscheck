import { DEFAULT_DEV_URL, DEFAULT_PACKAGED_PORT, resolveAppUrl, resolveServerPort } from './resolve-app-url';

describe('resolveAppUrl', () => {
  it('returns the default dev URL when not packaged and no override is set', () => {
    expect(resolveAppUrl({ isPackaged: false, env: {} })).toBe(DEFAULT_DEV_URL);
  });

  it('returns the default packaged port when packaged and no override is set', () => {
    expect(resolveAppUrl({ isPackaged: true, env: {} })).toBe(`http://localhost:${DEFAULT_PACKAGED_PORT}`);
  });

  it('respects DESKTOP_SERVER_PORT when packaged', () => {
    expect(resolveAppUrl({ isPackaged: true, env: { DESKTOP_SERVER_PORT: '5000' } })).toBe(
      'http://localhost:5000',
    );
  });

  it('DESKTOP_WEB_URL overrides everything, even in dev mode', () => {
    expect(
      resolveAppUrl({ isPackaged: false, env: { DESKTOP_WEB_URL: 'https://staging.example.com' } }),
    ).toBe('https://staging.example.com');
  });

  it('DESKTOP_WEB_URL overrides everything when packaged too', () => {
    expect(
      resolveAppUrl({ isPackaged: true, env: { DESKTOP_WEB_URL: 'https://staging.example.com' } }),
    ).toBe('https://staging.example.com');
  });

  it('ignores DESKTOP_SERVER_PORT in dev mode (dev always uses the default dev URL)', () => {
    expect(resolveAppUrl({ isPackaged: false, env: { DESKTOP_SERVER_PORT: '5000' } })).toBe(
      DEFAULT_DEV_URL,
    );
  });
});

describe('resolveServerPort', () => {
  it('returns the default port when not set', () => {
    expect(resolveServerPort({ env: {} })).toBe(DEFAULT_PACKAGED_PORT);
  });

  it('returns the env-provided port as a number', () => {
    expect(resolveServerPort({ env: { DESKTOP_SERVER_PORT: '9999' } })).toBe(9999);
  });
});
