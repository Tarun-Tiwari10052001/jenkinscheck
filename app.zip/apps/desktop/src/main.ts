import { app, BrowserWindow, Menu, MenuItemConstructorOptions, shell } from 'electron';
import { spawn, ChildProcess } from 'child_process';
import * as path from 'path';
import { resolveAppUrl, resolveServerPort } from './resolve-app-url';
import { waitForServer } from './wait-for-server';

/**
 * The whole desktop app: a native window pointed at the same web frontend
 * from apps/web. In dev, it loads the already-running `next dev` server
 * (start that separately — see README.md). In a packaged build, it spawns
 * the bundled Next.js standalone server (see electron-builder's
 * extraResources in package.json) as a child process, waits for it to be
 * ready, then loads it.
 *
 * This file intentionally has no unit tests — it's Electron shell/wiring
 * code (window creation, process spawning), which doesn't unit test
 * meaningfully. The logic that *can* be tested without Electron is
 * factored out into resolve-app-url.ts and wait-for-server.ts, which do
 * have tests. See README.md's "How this was actually verified" for what
 * was confirmed by actually launching this file under a headless
 * display, and what's still unverified without a real machine.
 */

let mainWindow: BrowserWindow | null = null;
let serverProcess: ChildProcess | null = null;

function startBundledServer(): void {
  const serverPath = path.join(process.resourcesPath, 'web-standalone', 'apps', 'web', 'server.js');
  const port = resolveServerPort();

  serverProcess = spawn(process.execPath, [serverPath], {
    env: { ...process.env, PORT: String(port), HOSTNAME: '127.0.0.1', ELECTRON_RUN_AS_NODE: '1' },
    stdio: 'inherit',
  });

  serverProcess.on('exit', (code) => {
    if (code !== 0 && code !== null) {
      console.error(`Bundled web server exited unexpectedly with code ${code}`);
    }
  });
}

async function createWindow(): Promise<void> {
  const isPackaged = app.isPackaged;

  if (isPackaged && !process.env.DESKTOP_WEB_URL) {
    startBundledServer();
  }

  const url = resolveAppUrl({ isPackaged });

  mainWindow = new BrowserWindow({
    width: 1280,
    height: 860,
    minWidth: 900,
    minHeight: 600,
    title: 'Interview Prep',
    // Keep the native window transparent so the web app's transparency slider
    // can reveal the desktop content behind the Electron window.
    transparent: true,
    backgroundColor: '#00000000',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
    },
  });

  // Anything that would open a new window (none in the app today) opens
  // in the OS browser instead of a second Electron window.
  mainWindow.webContents.setWindowOpenHandler(({ url: targetUrl }) => {
    shell.openExternal(targetUrl);
    return { action: 'deny' };
  });

  try {
    await waitForServer(url);
    await mainWindow.loadURL(url);
    console.log(`[desktop] Loaded ${url}`);
  } catch (err) {
    console.error(`Could not reach ${url}:`, err);
    const message = err instanceof Error ? err.message : String(err);
    await mainWindow.loadURL(
      'data:text/html,' +
        encodeURIComponent(
          `<body style="font-family: sans-serif; padding: 2rem;">
             <h1>Could not connect</h1>
             <p>${message}</p>
             <p>Is the app server running? See the desktop app's README.md.</p>
           </body>`,
        ),
    );
  }

  mainWindow.on('closed', () => {
    mainWindow = null;
  });
}

function buildMenu(): Menu {
  const isMac = process.platform === 'darwin';

  const template: MenuItemConstructorOptions[] = [
    ...(isMac
      ? [
          {
            label: app.name,
            submenu: [{ role: 'about' }, { type: 'separator' }, { role: 'quit' }],
          } as MenuItemConstructorOptions,
        ]
      : []),
    {
      label: 'Edit',
      submenu: [
        { role: 'undo' },
        { role: 'redo' },
        { type: 'separator' },
        { role: 'cut' },
        { role: 'copy' },
        { role: 'paste' },
        { role: 'selectAll' },
      ],
    },
    {
      label: 'View',
      submenu: [
        { role: 'reload' },
        { role: 'toggleDevTools' },
        { type: 'separator' },
        { role: 'resetZoom' },
        { role: 'zoomIn' },
        { role: 'zoomOut' },
        { type: 'separator' },
        { role: 'togglefullscreen' },
      ],
    },
    {
      label: 'Window',
      submenu: [{ role: 'minimize' }, { role: 'close' }],
    },
  ];

  return Menu.buildFromTemplate(template);
}

app.whenReady().then(() => {
  Menu.setApplicationMenu(buildMenu());
  createWindow();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

app.on('before-quit', () => {
  serverProcess?.kill();
});
