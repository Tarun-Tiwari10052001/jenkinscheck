import { waitForServer } from './wait-for-server';

describe('waitForServer', () => {
  it('resolves immediately when the first request succeeds', async () => {
    const fetchMock = jest.fn().mockResolvedValue({ ok: true });

    await waitForServer('http://localhost:3000', { fetchImpl: fetchMock as any, intervalMs: 5 });

    expect(fetchMock).toHaveBeenCalledTimes(1);
  });

  it('retries after a failed fetch (connection refused) until it succeeds', async () => {
    const fetchMock = jest
      .fn()
      .mockRejectedValueOnce(new Error('ECONNREFUSED'))
      .mockRejectedValueOnce(new Error('ECONNREFUSED'))
      .mockResolvedValueOnce({ ok: true });

    await waitForServer('http://localhost:3000', { fetchImpl: fetchMock as any, intervalMs: 5 });

    expect(fetchMock).toHaveBeenCalledTimes(3);
  });

  it('retries after a non-ok response until it succeeds', async () => {
    const fetchMock = jest
      .fn()
      .mockResolvedValueOnce({ ok: false })
      .mockResolvedValueOnce({ ok: true });

    await waitForServer('http://localhost:3000', { fetchImpl: fetchMock as any, intervalMs: 5 });

    expect(fetchMock).toHaveBeenCalledTimes(2);
  });

  it('throws a clear error after the timeout elapses without success', async () => {
    const fetchMock = jest.fn().mockRejectedValue(new Error('ECONNREFUSED'));

    await expect(
      waitForServer('http://localhost:3000', { fetchImpl: fetchMock as any, intervalMs: 5, timeoutMs: 20 }),
    ).rejects.toThrow('did not become ready within 20ms');
  });
});
