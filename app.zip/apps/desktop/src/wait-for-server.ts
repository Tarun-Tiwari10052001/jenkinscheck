/**
 * Polls a URL until it responds successfully, or gives up after a
 * timeout. Used to wait for the spawned Next.js standalone server (or,
 * in dev, the already-running `next dev` server) to be ready before the
 * Electron window loads it — without this, the window would briefly show
 * a connection-refused error on every launch.
 *
 * Deliberately framework-agnostic (no Electron imports) so it's testable
 * with plain Jest — see wait-for-server.spec.ts.
 */
export interface WaitForServerOptions {
  intervalMs?: number;
  timeoutMs?: number;
  fetchImpl?: typeof fetch;
}

export async function waitForServer(url: string, options: WaitForServerOptions = {}): Promise<void> {
  const intervalMs = options.intervalMs ?? 300;
  const timeoutMs = options.timeoutMs ?? 30_000;
  const fetchImpl = options.fetchImpl ?? fetch;
  const deadline = Date.now() + timeoutMs;

  while (Date.now() < deadline) {
    try {
      const res = await fetchImpl(url);
      if (res.ok) return;
    } catch {
      // Server not up yet — expected while it's still starting. Keep polling.
    }
    await sleep(intervalMs);
  }

  throw new Error(`Server at ${url} did not become ready within ${timeoutMs}ms`);
}

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
