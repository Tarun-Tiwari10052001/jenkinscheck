# Desktop (Electron)

Wraps `apps/web` in a native window — same frontend, no rewrite. See
`../../docs/CHANGE-GUIDE.md` first.

## What's here

- `src/main.ts` — the Electron main process: creates the window, and in a
  packaged build spawns the bundled Next.js server as a child process
- `src/preload.ts` — minimal preload script; no privileged APIs exposed
  to the renderer yet (see the comment in the file for when/how to add
  some)
- `src/resolve-app-url.ts` — pure logic deciding which URL to load (dev
  server vs. bundled server vs. an env override); **unit tested**
- `src/wait-for-server.ts` — polls a URL until it responds, so the window
  doesn't briefly show a connection error on launch; **unit tested**

## Running in development

The desktop shell does not start the web or API servers itself — start
them the normal way first, in separate terminals, from the repo root:

```bash
npm run dev:api     # http://localhost:3001
npm run dev:web      # http://localhost:3000
```

Then, from `apps/desktop`:

```bash
npm run start        # builds src/ and launches Electron
```

## Building a distributable

```bash
# 1. build the web app with standalone output (already configured via
#    output: 'standalone' in apps/web/next.config.js)
npm run build --workspace=apps/web

# 2. package the desktop app — bundles the standalone server as an
#    extra resource (see the "build.extraResources" in package.json)
cd apps/desktop
npm run package
```

The packaged app still expects the API to be reachable — it does not
bundle `apps/api`. Point it at a deployed backend with
`NEXT_PUBLIC_API_URL` (baked in at web-build time, same as the browser
version) rather than expecting the desktop app to run its own copy of
the backend locally.

## How this was actually verified

This environment has no real display, so full manual QA (does the app
look right, does the packaged installer work on each OS) still needs a
real machine before shipping. But more was verified for real here than
that limit might suggest — worth being specific about exactly what:

- `resolve-app-url.ts` and `wait-for-server.ts` — the two files with
  actual logic in them — have full unit test coverage and pass
- The exact path structure the packaged build depends on
  (`.next/standalone/apps/web/server.js`, plus `.next/static` and
  `public` needing to be copied alongside it) was confirmed by actually
  running `apps/web`'s standalone build output as a plain Node process,
  not assumed from documentation — it started, and served real pages
  correctly (200 for `/` and `/login`, 404 for an unknown route)
- **The actual Electron app was launched for real**, headless, under
  Xvfb (`xvfb-run ... electron dist/main.js --no-sandbox --disable-gpu`)
  with a real `next dev` server running alongside it: the window
  initialized, `waitForServer` polled and succeeded, and
  `mainWindow.loadURL()` completed against the real running web app —
  confirmed via a log line, not inferred. This is dev mode (loading
  `localhost:3000`); it exercises the same window-creation and
  load/error-handling code path the packaged build uses, just pointed at
  a different URL.

What's still unverified, specifically:

- The packaged build's own code path — `startBundledServer()` spawning
  the bundled server via `process.resourcesPath` — wasn't exercised
  end-to-end, because that only resolves meaningfully inside a real
  `electron-builder` package, which wasn't built here (it's a slow,
  disk-heavy step, and the two things it would additionally prove —
  child-process spawning and `resourcesPath` resolution — are both
  standard, well-documented Electron/electron-builder behavior rather
  than custom logic worth re-deriving from scratch). Worth a real test
  before the first packaged release.
- Visual appearance, and the packaged installer on each target OS
