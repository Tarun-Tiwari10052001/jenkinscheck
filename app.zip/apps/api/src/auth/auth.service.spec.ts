import { Test } from '@nestjs/testing';
import { ConflictException, UnauthorizedException } from '@nestjs/common';
import * as bcrypt from 'bcrypt';
import { AuthService } from './auth.service';
import { UsersService } from '../users/users.service';
import { JwtService } from '@nestjs/jwt';

describe('AuthService', () => {
  let service: AuthService;

  const usersServiceMock = {
    findByEmail: jest.fn(),
    create: jest.fn(),
  };

  const jwtServiceMock = {
    sign: jest.fn().mockReturnValue('signed.jwt.token'),
  };

  beforeEach(async () => {
    jest.clearAllMocks();
    jwtServiceMock.sign.mockReturnValue('signed.jwt.token');

    const moduleRef = await Test.createTestingModule({
      providers: [
        AuthService,
        { provide: UsersService, useValue: usersServiceMock },
        { provide: JwtService, useValue: jwtServiceMock },
      ],
    }).compile();

    service = moduleRef.get(AuthService);
  });

  describe('register', () => {
    it('creates a new user with a hashed password and returns a token', async () => {
      usersServiceMock.findByEmail.mockResolvedValue(null);
      usersServiceMock.create.mockResolvedValue({
        id: 'user-1',
        email: 'new@example.com',
        name: 'New User',
      });

      const result = await service.register({
        email: 'new@example.com',
        password: 'a-strong-password',
        name: 'New User',
      });

      // password must never be stored in plain text
      const createCallArgs = usersServiceMock.create.mock.calls[0][0];
      expect(createCallArgs.passwordHash).not.toBe('a-strong-password');
      expect(await bcrypt.compare('a-strong-password', createCallArgs.passwordHash)).toBe(true);

      expect(result).toEqual({
        accessToken: 'signed.jwt.token',
        user: { id: 'user-1', email: 'new@example.com', name: 'New User' },
      });
    });

    it('rejects registration when the email is already taken', async () => {
      usersServiceMock.findByEmail.mockResolvedValue({ id: 'existing-user' });

      await expect(
        service.register({ email: 'taken@example.com', password: 'whatever123' }),
      ).rejects.toBeInstanceOf(ConflictException);

      expect(usersServiceMock.create).not.toHaveBeenCalled();
    });
  });

  describe('login', () => {
    it('returns a token when the email and password are correct', async () => {
      const passwordHash = await bcrypt.hash('correct-password', 10);
      usersServiceMock.findByEmail.mockResolvedValue({
        id: 'user-1',
        email: 'user@example.com',
        name: null,
        passwordHash,
      });

      const result = await service.login({
        email: 'user@example.com',
        password: 'correct-password',
      });

      expect(result.accessToken).toBe('signed.jwt.token');
      expect(result.user).toEqual({ id: 'user-1', email: 'user@example.com', name: null });
    });

    it('rejects login when the password is wrong', async () => {
      const passwordHash = await bcrypt.hash('correct-password', 10);
      usersServiceMock.findByEmail.mockResolvedValue({
        id: 'user-1',
        email: 'user@example.com',
        passwordHash,
      });

      await expect(
        service.login({ email: 'user@example.com', password: 'wrong-password' }),
      ).rejects.toBeInstanceOf(UnauthorizedException);
    });

    it('rejects login when the email does not exist', async () => {
      usersServiceMock.findByEmail.mockResolvedValue(null);

      await expect(
        service.login({ email: 'nobody@example.com', password: 'whatever123' }),
      ).rejects.toBeInstanceOf(UnauthorizedException);
    });
  });
});
