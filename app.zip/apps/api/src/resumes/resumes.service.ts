import { Inject, Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { AI_PROVIDER, AiProvider } from '../ai/providers/ai-provider.interface';
import { parseFeedback } from '../ai/feedback-parser';
import { CreateResumeDto } from './dto/create-resume.dto';
import { GenerateCoverLetterDto } from './dto/generate-cover-letter.dto';
import {
  buildCoverLetterSystemPrompt,
  buildCoverLetterUserPrompt,
  buildResumeFeedbackSystemPrompt,
  buildResumeFeedbackUserPrompt,
  buildTailorSystemPrompt,
  buildTailorUserPrompt,
  parseTailorResult,
} from './resume-prompts';

@Injectable()
export class ResumesService {
  constructor(
    private readonly prisma: PrismaService,
    @Inject(AI_PROVIDER) private readonly ai: AiProvider,
  ) {}

  async create(userId: string, dto: CreateResumeDto) {
    const feedbackRaw = await this.ai.complete({
      system: buildResumeFeedbackSystemPrompt(),
      messages: [{ role: 'user', content: buildResumeFeedbackUserPrompt(dto.content) }],
      maxTokens: 512,
    });

    const parsed = parseFeedback(feedbackRaw);

    return this.prisma.resume.create({
      data: {
        userId,
        content: dto.content,
        latestFeedback: parsed ? JSON.stringify(parsed) : feedbackRaw,
      },
    });
  }

  listResumes(userId: string) {
    return this.prisma.resume.findMany({
      where: { userId },
      orderBy: { createdAt: 'desc' },
      select: { id: true, content: true, latestFeedback: true, createdAt: true, updatedAt: true },
    });
  }

  async getResume(userId: string, id: string) {
    return this.getOwnedResume(userId, id);
  }

  async remove(userId: string, id: string): Promise<void> {
    await this.getOwnedResume(userId, id);
    await this.prisma.resume.delete({ where: { id } });
  }

  /**
   * Does NOT persist anything — a tailoring result is specific to one job
   * description, not a property of the resume itself, so there's nothing
   * sensible to store it against. See docs/DATABASE.md.
   */
  async tailor(userId: string, id: string, jobDescription: string) {
    const resume = await this.getOwnedResume(userId, id);

    const raw = await this.ai.complete({
      system: buildTailorSystemPrompt(),
      messages: [{ role: 'user', content: buildTailorUserPrompt(resume.content, jobDescription) }],
      maxTokens: 512,
    });

    const parsed = parseTailorResult(raw);
    if (parsed) return parsed;

    return { matchScore: null, missingKeywords: [], suggestions: [raw] };
  }

  /** Also not persisted — same reasoning as tailor(). */
  async generateCoverLetter(userId: string, id: string, dto: GenerateCoverLetterDto) {
    const resume = await this.getOwnedResume(userId, id);

    const content = await this.ai.complete({
      system: buildCoverLetterSystemPrompt(),
      messages: [
        {
          role: 'user',
          content: buildCoverLetterUserPrompt(resume.content, dto.jobDescription, dto.company, dto.role),
        },
      ],
      maxTokens: 800,
    });

    return { content: content.trim() };
  }

  /**
   * Same ownership-check pattern as InterviewsService.getOwnedSession:
   * NotFoundException for both "doesn't exist" and "belongs to someone
   * else", so a user can't distinguish the two by probing IDs.
   */
  private async getOwnedResume(userId: string, id: string) {
    const resume = await this.prisma.resume.findUnique({ where: { id } });
    if (!resume || resume.userId !== userId) {
      throw new NotFoundException('Resume not found.');
    }
    return resume;
  }
}
