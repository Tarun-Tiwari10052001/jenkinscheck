import { Body, Controller, Delete, Get, HttpCode, Param, Post, Req, UseGuards } from '@nestjs/common';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { ResumesService } from './resumes.service';
import { CreateResumeDto } from './dto/create-resume.dto';
import { TailorResumeDto } from './dto/tailor-resume.dto';
import { GenerateCoverLetterDto } from './dto/generate-cover-letter.dto';

@UseGuards(JwtAuthGuard)
@Controller('resumes')
export class ResumesController {
  constructor(private readonly resumesService: ResumesService) {}

  @Post()
  create(@Req() req: any, @Body() dto: CreateResumeDto) {
    return this.resumesService.create(req.user.userId, dto);
  }

  @Get()
  list(@Req() req: any) {
    return this.resumesService.listResumes(req.user.userId);
  }

  @Get(':id')
  getOne(@Req() req: any, @Param('id') id: string) {
    return this.resumesService.getResume(req.user.userId, id);
  }

  @Delete(':id')
  @HttpCode(204)
  async remove(@Req() req: any, @Param('id') id: string) {
    await this.resumesService.remove(req.user.userId, id);
  }

  @Post(':id/tailor')
  tailor(@Req() req: any, @Param('id') id: string, @Body() dto: TailorResumeDto) {
    return this.resumesService.tailor(req.user.userId, id, dto.jobDescription);
  }

  @Post(':id/cover-letter')
  coverLetter(@Req() req: any, @Param('id') id: string, @Body() dto: GenerateCoverLetterDto) {
    return this.resumesService.generateCoverLetter(req.user.userId, id, dto);
  }
}
