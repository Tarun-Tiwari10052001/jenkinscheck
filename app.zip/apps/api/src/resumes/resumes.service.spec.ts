import { Test } from '@nestjs/testing';
import { NotFoundException } from '@nestjs/common';
import { ResumesService } from './resumes.service';
import { PrismaService } from '../prisma/prisma.service';
import { AI_PROVIDER } from '../ai/providers/ai-provider.interface';

describe('ResumesService', () => {
  let service: ResumesService;

  const prismaMock = {
    resume: {
      create: jest.fn(),
      findUnique: jest.fn(),
      findMany: jest.fn(),
      delete: jest.fn(),
    },
  };

  const aiProviderMock = { complete: jest.fn() };

  beforeEach(async () => {
    jest.clearAllMocks();

    const moduleRef = await Test.createTestingModule({
      providers: [
        ResumesService,
        { provide: PrismaService, useValue: prismaMock },
        { provide: AI_PROVIDER, useValue: aiProviderMock },
      ],
    }).compile();

    service = moduleRef.get(ResumesService);
  });

  const longResumeText = 'A'.repeat(60);

  describe('create', () => {
    it('generates feedback and stores it as parsed JSON', async () => {
      aiProviderMock.complete.mockResolvedValue(
        '{"score": 75, "strengths": ["Quantified impact"], "improvements": ["Trim older roles"]}',
      );
      prismaMock.resume.create.mockResolvedValue({
        id: 'resume-1',
        userId: 'user-1',
        content: longResumeText,
        latestFeedback: '{"score":75,"strengths":["Quantified impact"],"improvements":["Trim older roles"]}',
      });

      const result = await service.create('user-1', { content: longResumeText });

      const createArgs = prismaMock.resume.create.mock.calls[0][0];
      expect(createArgs.data.userId).toBe('user-1');
      expect(createArgs.data.content).toBe(longResumeText);
      expect(JSON.parse(createArgs.data.latestFeedback).score).toBe(75);
      expect(result.id).toBe('resume-1');
    });

    it('falls back to storing raw text when the AI response is not valid JSON', async () => {
      aiProviderMock.complete.mockResolvedValue('I could not evaluate this resume.');
      prismaMock.resume.create.mockResolvedValue({ id: 'resume-2' });

      await service.create('user-1', { content: longResumeText });

      const createArgs = prismaMock.resume.create.mock.calls[0][0];
      expect(createArgs.data.latestFeedback).toBe('I could not evaluate this resume.');
    });
  });

  describe('getResume', () => {
    it('throws NotFoundException when the resume does not exist', async () => {
      prismaMock.resume.findUnique.mockResolvedValue(null);

      await expect(service.getResume('user-1', 'missing')).rejects.toBeInstanceOf(NotFoundException);
    });

    it('throws NotFoundException when the resume belongs to another user', async () => {
      prismaMock.resume.findUnique.mockResolvedValue({ id: 'resume-1', userId: 'someone-else' });

      await expect(service.getResume('user-1', 'resume-1')).rejects.toBeInstanceOf(NotFoundException);
    });

    it('returns the resume when owned by the requesting user', async () => {
      prismaMock.resume.findUnique.mockResolvedValue({ id: 'resume-1', userId: 'user-1' });

      const result = await service.getResume('user-1', 'resume-1');

      expect(result).toEqual({ id: 'resume-1', userId: 'user-1' });
    });
  });

  describe('remove', () => {
    it('throws NotFoundException when not owned, and does not delete', async () => {
      prismaMock.resume.findUnique.mockResolvedValue(null);

      await expect(service.remove('user-1', 'missing')).rejects.toBeInstanceOf(NotFoundException);
      expect(prismaMock.resume.delete).not.toHaveBeenCalled();
    });

    it('deletes when owned', async () => {
      prismaMock.resume.findUnique.mockResolvedValue({ id: 'resume-1', userId: 'user-1' });

      await service.remove('user-1', 'resume-1');

      expect(prismaMock.resume.delete).toHaveBeenCalledWith({ where: { id: 'resume-1' } });
    });
  });

  describe('tailor', () => {
    it('throws NotFoundException when the resume is not owned', async () => {
      prismaMock.resume.findUnique.mockResolvedValue(null);

      await expect(
        service.tailor('user-1', 'missing', 'a'.repeat(60)),
      ).rejects.toBeInstanceOf(NotFoundException);
    });

    it('returns the parsed match result on success', async () => {
      prismaMock.resume.findUnique.mockResolvedValue({
        id: 'resume-1',
        userId: 'user-1',
        content: longResumeText,
      });
      aiProviderMock.complete.mockResolvedValue(
        '{"matchScore": 64, "missingKeywords": ["Kubernetes"], "suggestions": ["Mention container orchestration experience"]}',
      );

      const result = await service.tailor('user-1', 'resume-1', 'a'.repeat(60));

      expect(result).toEqual({
        matchScore: 64,
        missingKeywords: ['Kubernetes'],
        suggestions: ['Mention container orchestration experience'],
      });
    });

    it('does not write to the database — tailoring is not persisted', async () => {
      prismaMock.resume.findUnique.mockResolvedValue({
        id: 'resume-1',
        userId: 'user-1',
        content: longResumeText,
      });
      aiProviderMock.complete.mockResolvedValue(
        '{"matchScore": 50, "missingKeywords": [], "suggestions": []}',
      );

      await service.tailor('user-1', 'resume-1', 'a'.repeat(60));

      expect(prismaMock.resume.create).not.toHaveBeenCalled();
    });

    it('falls back to a null score with the raw text as a suggestion when parsing fails', async () => {
      prismaMock.resume.findUnique.mockResolvedValue({
        id: 'resume-1',
        userId: 'user-1',
        content: longResumeText,
      });
      aiProviderMock.complete.mockResolvedValue('not valid json');

      const result = await service.tailor('user-1', 'resume-1', 'a'.repeat(60));

      expect(result).toEqual({ matchScore: null, missingKeywords: [], suggestions: ['not valid json'] });
    });
  });

  describe('generateCoverLetter', () => {
    it('throws NotFoundException when the resume is not owned', async () => {
      prismaMock.resume.findUnique.mockResolvedValue(null);

      await expect(
        service.generateCoverLetter('user-1', 'missing', { jobDescription: 'a'.repeat(60) }),
      ).rejects.toBeInstanceOf(NotFoundException);
    });

    it('returns the trimmed letter text and does not persist it', async () => {
      prismaMock.resume.findUnique.mockResolvedValue({
        id: 'resume-1',
        userId: 'user-1',
        content: longResumeText,
      });
      aiProviderMock.complete.mockResolvedValue('  Dear Hiring Manager, ...  \n');

      const result = await service.generateCoverLetter('user-1', 'resume-1', {
        jobDescription: 'a'.repeat(60),
        company: 'Acme',
        role: 'Backend Engineer',
      });

      expect(result).toEqual({ content: 'Dear Hiring Manager, ...' });
      expect(prismaMock.resume.create).not.toHaveBeenCalled();
    });
  });

  describe('listResumes', () => {
    it('scopes results to the requesting user', async () => {
      prismaMock.resume.findMany.mockResolvedValue([]);

      await service.listResumes('user-1');

      expect(prismaMock.resume.findMany).toHaveBeenCalledWith(
        expect.objectContaining({ where: { userId: 'user-1' } }),
      );
    });
  });
});
