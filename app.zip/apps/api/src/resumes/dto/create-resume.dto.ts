import { IsString, MaxLength, MinLength } from 'class-validator';

export class CreateResumeDto {
  @IsString()
  @MinLength(50, { message: 'Paste your full resume text (at least 50 characters).' })
  @MaxLength(20000)
  content!: string;
}
