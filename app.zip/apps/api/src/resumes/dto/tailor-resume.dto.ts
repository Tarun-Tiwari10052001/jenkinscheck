import { IsString, MaxLength, MinLength } from 'class-validator';

export class TailorResumeDto {
  @IsString()
  @MinLength(50, { message: 'Paste the full job description (at least 50 characters).' })
  @MaxLength(10000)
  jobDescription!: string;
}
