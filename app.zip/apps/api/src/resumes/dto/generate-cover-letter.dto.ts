import { IsOptional, IsString, MaxLength, MinLength } from 'class-validator';

export class GenerateCoverLetterDto {
  @IsString()
  @MinLength(50, { message: 'Paste the full job description (at least 50 characters).' })
  @MaxLength(10000)
  jobDescription!: string;

  @IsOptional()
  @IsString()
  @MaxLength(100)
  company?: string;

  @IsOptional()
  @IsString()
  @MaxLength(100)
  role?: string;
}
