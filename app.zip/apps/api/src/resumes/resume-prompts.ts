/**
 * All prompt text for the resume tools lives in this one file — see
 * docs/CHANGE-GUIDE.md. Tuning feedback quality, tailoring behavior, or
 * cover letter tone should only ever mean editing this file.
 */

export function buildResumeFeedbackSystemPrompt(): string {
  return [
    'You are an experienced recruiter and resume reviewer giving direct, practical feedback.',
    'Review the resume text the candidate provides and respond with ONLY a JSON object,',
    'no other text, no markdown code fences, in exactly this shape:',
    '{"score": <integer 0-100>, "strengths": [<2-4 short strings>], "improvements": [<2-4 short strings>]}',
    'Score holistically: clarity, impact (quantified results over vague duties), structure,',
    'and likely performance against automated resume-screening tools (ATS).',
  ].join(' ');
}

export function buildResumeFeedbackUserPrompt(content: string): string {
  return `Here is the resume:\n\n${content}`;
}

export function buildTailorSystemPrompt(): string {
  return [
    'You compare a resume against a specific job description and assess fit.',
    'Respond with ONLY a JSON object, no other text, no markdown code fences,',
    'in exactly this shape:',
    '{"matchScore": <integer 0-100>, "missingKeywords": [<3-8 short strings>], "suggestions": [<2-5 short strings>]}',
    'matchScore reflects how well the resume, as written, matches this specific job description.',
    'missingKeywords are role-relevant skills/terms from the job description absent from the resume.',
    'suggestions are concrete edits to improve the match — not generic resume advice.',
  ].join(' ');
}

export function buildTailorUserPrompt(resumeContent: string, jobDescription: string): string {
  return [
    `Resume:\n\n${resumeContent}`,
    `\n\nJob description:\n\n${jobDescription}`,
  ].join('');
}

export function buildCoverLetterSystemPrompt(): string {
  return [
    'You write concise, specific, non-generic cover letters grounded in the details of the',
    "candidate's actual resume and the specific job description — never generic filler.",
    'Three to four short paragraphs. Professional but not stiff. Reference specific,',
    'relevant experience from the resume. Do not invent experience not present in the resume.',
    'Output ONLY the letter body text — no subject line, no "Dear Hiring Manager" placeholder',
    'brackets, no preamble or explanation before or after the letter.',
  ].join(' ');
}

export function buildCoverLetterUserPrompt(
  resumeContent: string,
  jobDescription: string,
  company?: string,
  role?: string,
): string {
  const context = [
    role ? `Role: ${role}` : null,
    company ? `Company: ${company}` : null,
  ]
    .filter(Boolean)
    .join('\n');

  return [
    context ? `${context}\n\n` : '',
    `Resume:\n\n${resumeContent}`,
    `\n\nJob description:\n\n${jobDescription}`,
  ].join('');
}

export interface ParsedTailorResult {
  matchScore: number;
  missingKeywords: string[];
  suggestions: string[];
}

/**
 * Same defensive-parsing approach as apps/api/src/ai/feedback-parser.ts,
 * but for the tailor endpoint's distinct shape (matchScore/missingKeywords
 * rather than score/strengths). Kept separate rather than generalizing the
 * shared parser further, since forcing two different shapes through one
 * generic parser would make both harder to read for little real reuse.
 */
export function parseTailorResult(raw: string): ParsedTailorResult | null {
  const cleaned = raw.trim().replace(/^```(json)?/i, '').replace(/```$/, '').trim();
  try {
    const parsed = JSON.parse(cleaned);
    if (
      typeof parsed.matchScore === 'number' &&
      Array.isArray(parsed.missingKeywords) &&
      Array.isArray(parsed.suggestions)
    ) {
      return parsed;
    }
    return null;
  } catch {
    return null;
  }
}
