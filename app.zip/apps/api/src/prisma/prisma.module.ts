import { Global, Module } from '@nestjs/common';
import { PrismaService } from './prisma.service';

/**
 * Global so any module can inject PrismaService without re-importing
 * this module everywhere. See docs/CHANGE-GUIDE.md before changing the
 * schema this service points at.
 */
@Global()
@Module({
  providers: [PrismaService],
  exports: [PrismaService],
})
export class PrismaModule {}
