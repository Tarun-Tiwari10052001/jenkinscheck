/**
 * Shared by any feature that asks the AI provider for a JSON evaluation
 * shaped like { score, strengths, improvements }. Extracted here instead
 * of duplicated because multiple features need defensive parsing of the
 * same shape. 
 * features need identical, defensive parsing of the same shape; see
 * docs/CHANGE-GUIDE.md before changing this shape, since two modules
 * depend on it.
 */

export interface ParsedFeedback {
  score: number;
  strengths: string[];
  improvements: string[];
}

/**
 * The model is asked for raw JSON but occasionally wraps it in code
 * fences or adds stray whitespace — this strips that before parsing.
 * Returns null (never throws) if the response still isn't valid JSON, so
 * callers can fall back to storing the raw text instead of failing the
 * whole request.
 */
export function parseFeedback(raw: string): ParsedFeedback | null {
  const cleaned = raw.trim().replace(/^```(json)?/i, '').replace(/```$/, '').trim();
  try {
    const parsed = JSON.parse(cleaned);
    if (
      typeof parsed.score === 'number' &&
      Array.isArray(parsed.strengths) &&
      Array.isArray(parsed.improvements)
    ) {
      return parsed;
    }
    return null;
  } catch {
    return null;
  }
}
