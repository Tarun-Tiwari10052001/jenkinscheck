import { Module } from '@nestjs/common';
import { aiProviderFactory } from './providers/ai-provider.factory';
import { AI_PROVIDER } from './providers/ai-provider.interface';

@Module({
  providers: [aiProviderFactory],
  exports: [AI_PROVIDER],
})
export class AiModule {}
