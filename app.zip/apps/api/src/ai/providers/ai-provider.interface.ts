/**
 * Every AI vendor implements this one interface. Features that call an LLM
 * depend only on this — never on
 * a specific vendor's SDK. See docs/CHANGE-GUIDE.md before changing this
 * shape, since it's the contract every provider and every caller share.
 */

export interface CompletionMessage {
  role: 'user' | 'assistant';
  content: string;
}

export interface CompletionParams {
  system: string;
  messages: CompletionMessage[];
  maxTokens?: number;
}

export interface AiProvider {
  complete(params: CompletionParams): Promise<string>;
}

/** DI token — providers are plain classes, not @Injectable, since the
 * factory constructs the selected one manually with its own API key. */
export const AI_PROVIDER = 'AI_PROVIDER';
