import { GoogleProvider } from './google.provider';

const generateContentMock = jest.fn();

jest.mock('@google/genai', () => ({
  GoogleGenAI: jest.fn().mockImplementation(() => ({
    models: { generateContent: generateContentMock },
  })),
}));

describe('GoogleProvider', () => {
  beforeEach(() => jest.clearAllMocks());

  it('returns response.text and maps assistant/user roles to model/user', async () => {
    generateContentMock.mockResolvedValue({ text: 'Hello from Gemini' });

    const provider = new GoogleProvider('test-key', 'gemini-2.5-flash');
    const result = await provider.complete({
      system: 'You are an interviewer.',
      messages: [
        { role: 'assistant', content: 'What is your name?' },
        { role: 'user', content: 'Jane.' },
      ],
    });

    expect(result).toBe('Hello from Gemini');
    expect(generateContentMock).toHaveBeenCalledWith(
      expect.objectContaining({
        model: 'gemini-2.5-flash',
        contents: [
          { role: 'model', parts: [{ text: 'What is your name?' }] },
          { role: 'user', parts: [{ text: 'Jane.' }] },
        ],
        config: expect.objectContaining({ systemInstruction: 'You are an interviewer.' }),
      }),
    );
  });

  it('throws when the response has no text', async () => {
    generateContentMock.mockResolvedValue({ text: undefined });

    const provider = new GoogleProvider('test-key', 'gemini-2.5-flash');

    await expect(
      provider.complete({ system: 'sys', messages: [{ role: 'user', content: 'hi' }] }),
    ).rejects.toThrow('Gemini did not return a text response');
  });
});
