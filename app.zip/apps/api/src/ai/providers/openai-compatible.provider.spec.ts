import { OpenAiCompatibleProvider } from './openai-compatible.provider';

describe('OpenAiCompatibleProvider', () => {
  const originalFetch = global.fetch;

  afterEach(() => {
    global.fetch = originalFetch;
  });

  it('sends the system prompt as the first message and returns the reply text', async () => {
    const fetchMock = jest.fn().mockResolvedValue({
      ok: true,
      json: async () => ({ choices: [{ message: { content: 'Hello from an OpenAI-style API' } }] }),
    });
    global.fetch = fetchMock as any;

    const provider = new OpenAiCompatibleProvider('test-key', 'gpt-4o-mini', 'https://api.openai.com/v1');
    const result = await provider.complete({
      system: 'You are an interviewer.',
      messages: [{ role: 'user', content: 'Begin.' }],
    });

    expect(result).toBe('Hello from an OpenAI-style API');
    const [url, options] = fetchMock.mock.calls[0];
    expect(url).toBe('https://api.openai.com/v1/chat/completions');
    const body = JSON.parse(options.body);
    expect(body.messages[0]).toEqual({ role: 'system', content: 'You are an interviewer.' });
    expect(options.headers.Authorization).toBe('Bearer test-key');
  });

  it('works against a custom base URL, for non-OpenAI compatible services', async () => {
    const fetchMock = jest.fn().mockResolvedValue({
      ok: true,
      json: async () => ({ choices: [{ message: { content: 'ok' } }] }),
    });
    global.fetch = fetchMock as any;

    const provider = new OpenAiCompatibleProvider('key', 'llama-3.3-70b', 'https://api.groq.com/openai/v1');
    await provider.complete({ system: 'sys', messages: [{ role: 'user', content: 'hi' }] });

    expect(fetchMock).toHaveBeenCalledWith(
      'https://api.groq.com/openai/v1/chat/completions',
      expect.anything(),
    );
  });

  it('throws with the status code when the request fails', async () => {
    global.fetch = jest.fn().mockResolvedValue({
      ok: false,
      status: 401,
      text: async () => 'invalid api key',
    }) as any;

    const provider = new OpenAiCompatibleProvider('bad-key', 'gpt-4o-mini', 'https://api.openai.com/v1');

    await expect(
      provider.complete({ system: 'sys', messages: [{ role: 'user', content: 'hi' }] }),
    ).rejects.toThrow('AI provider request failed with status 401');
  });

  it('throws when the response has no message content', async () => {
    global.fetch = jest.fn().mockResolvedValue({
      ok: true,
      json: async () => ({ choices: [] }),
    }) as any;

    const provider = new OpenAiCompatibleProvider('key', 'gpt-4o-mini', 'https://api.openai.com/v1');

    await expect(
      provider.complete({ system: 'sys', messages: [{ role: 'user', content: 'hi' }] }),
    ).rejects.toThrow('AI provider did not return a text response');
  });
});
