import { Logger } from '@nestjs/common';
import { AiProvider, CompletionParams } from './ai-provider.interface';

/**
 * Works with OpenAI itself, and with anything that mirrors OpenAI's
 * /chat/completions REST shape — Groq, DeepSeek, Together, OpenRouter,
 * a locally running Ollama server, Azure OpenAI (with the right base URL),
 * and most other "OpenAI-compatible" providers. No vendor SDK is used on
 * purpose: this is the intentionally generic fallback for "some other
 * provider" rather than a dedicated integration. Set OPENAI_BASE_URL to
 * point it at any compatible endpoint.
 */
export class OpenAiCompatibleProvider implements AiProvider {
  private readonly logger = new Logger(OpenAiCompatibleProvider.name);

  constructor(
    private readonly apiKey: string,
    private readonly model: string,
    private readonly baseUrl: string,
  ) {}

  async complete(params: CompletionParams): Promise<string> {
    const res = await fetch(`${this.baseUrl}/chat/completions`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${this.apiKey}`,
      },
      body: JSON.stringify({
        model: this.model,
        max_tokens: params.maxTokens ?? 1024,
        messages: [{ role: 'system', content: params.system }, ...params.messages],
      }),
    });

    if (!res.ok) {
      const body = await res.text().catch(() => '');
      this.logger.error(`OpenAI-compatible request failed: ${res.status} ${body}`);
      throw new Error(`AI provider request failed with status ${res.status}`);
    }

    // Explicitly typed rather than relying on fetch()'s inferred return
    // type, which differs depending on which @types/node version resolves
    // (some type json() as Promise<any>, others as Promise<unknown>).
    const data = (await res.json()) as ChatCompletionResponse;
    const text = data.choices?.[0]?.message?.content;

    if (!text) {
      this.logger.error('OpenAI-compatible response contained no message content');
      throw new Error('AI provider did not return a text response');
    }

    return text;
  }
}

interface ChatCompletionResponse {
  choices?: { message?: { content?: string } }[];
}
