import { Logger } from '@nestjs/common';
import { GoogleGenAI } from '@google/genai';
import { AiProvider, CompletionParams } from './ai-provider.interface';

/**
 * Works with Gemini models via a Google AI Studio API key (or Vertex AI,
 * if the underlying SDK is configured for it — see @google/genai docs).
 * Uses the current unified SDK, not the deprecated @google/generative-ai
 * package.
 */
export class GoogleProvider implements AiProvider {
  private readonly logger = new Logger(GoogleProvider.name);
  private readonly client: GoogleGenAI;

  constructor(apiKey: string, private readonly model: string) {
    this.client = new GoogleGenAI({ apiKey });
  }

  async complete(params: CompletionParams): Promise<string> {
    const response = await this.client.models.generateContent({
      model: this.model,
      contents: params.messages.map((m) => ({
        role: m.role === 'assistant' ? 'model' : 'user',
        parts: [{ text: m.content }],
      })),
      config: {
        systemInstruction: params.system,
        maxOutputTokens: params.maxTokens ?? 1024,
      },
    });

    if (!response.text) {
      this.logger.error('Gemini response contained no text');
      throw new Error('Gemini did not return a text response');
    }

    return response.text;
  }
}
