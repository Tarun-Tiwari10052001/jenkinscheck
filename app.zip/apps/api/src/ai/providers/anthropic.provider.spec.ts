import { AnthropicProvider } from './anthropic.provider';

const createMock = jest.fn();

jest.mock('@anthropic-ai/sdk', () => {
  return jest.fn().mockImplementation(() => ({
    messages: { create: createMock },
  }));
});

describe('AnthropicProvider', () => {
  beforeEach(() => jest.clearAllMocks());

  it('returns the text content from a successful response', async () => {
    createMock.mockResolvedValue({ content: [{ type: 'text', text: 'Hello from Claude' }] });

    const provider = new AnthropicProvider('test-key', 'claude-sonnet-5');
    const result = await provider.complete({
      system: 'You are an interviewer.',
      messages: [{ role: 'user', content: 'Begin.' }],
    });

    expect(result).toBe('Hello from Claude');
    expect(createMock).toHaveBeenCalledWith(
      expect.objectContaining({ model: 'claude-sonnet-5', system: 'You are an interviewer.' }),
    );
  });

  it('throws when the response has no text block', async () => {
    createMock.mockResolvedValue({ content: [{ type: 'tool_use' }] });

    const provider = new AnthropicProvider('test-key', 'claude-sonnet-5');

    await expect(
      provider.complete({ system: 'sys', messages: [{ role: 'user', content: 'hi' }] }),
    ).rejects.toThrow('Anthropic did not return a text response');
  });
});
