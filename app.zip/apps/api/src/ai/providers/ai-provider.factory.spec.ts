import { ConfigService } from '@nestjs/config';
import { buildAiProvider } from './ai-provider.factory';
import { AnthropicProvider } from './anthropic.provider';
import { GoogleProvider } from './google.provider';
import { OpenAiCompatibleProvider } from './openai-compatible.provider';

function configWith(values: Record<string, string | undefined>): ConfigService {
  return { get: (key: string) => values[key] } as unknown as ConfigService;
}

describe('buildAiProvider', () => {
  it('defaults to Anthropic when AI_PROVIDER is not set', () => {
    const provider = buildAiProvider(configWith({ ANTHROPIC_API_KEY: 'key' }));
    expect(provider).toBeInstanceOf(AnthropicProvider);
  });

  it('does not throw at construction when the Anthropic key is missing (deferred to first use)', () => {
    expect(() => buildAiProvider(configWith({ AI_PROVIDER: 'anthropic' }))).not.toThrow();
  });

  it('rejects with a clear error on first use when the Anthropic key is missing', async () => {
    const provider = buildAiProvider(configWith({ AI_PROVIDER: 'anthropic' }));
    await expect(
      provider.complete({ system: 'sys', messages: [{ role: 'user', content: 'hi' }] }),
    ).rejects.toThrow('ANTHROPIC_API_KEY is required');
  });

  it('builds a GoogleProvider when AI_PROVIDER=google', () => {
    const provider = buildAiProvider(
      configWith({ AI_PROVIDER: 'google', GOOGLE_API_KEY: 'key' }),
    );
    expect(provider).toBeInstanceOf(GoogleProvider);
  });

  it('rejects with a clear error on first use when the Google key is missing', async () => {
    const provider = buildAiProvider(configWith({ AI_PROVIDER: 'google' }));
    await expect(
      provider.complete({ system: 'sys', messages: [{ role: 'user', content: 'hi' }] }),
    ).rejects.toThrow('GOOGLE_API_KEY is required');
  });

  it('builds an OpenAiCompatibleProvider when AI_PROVIDER=openai, defaulting the base URL', () => {
    const provider = buildAiProvider(
      configWith({ AI_PROVIDER: 'openai', OPENAI_API_KEY: 'key', OPENAI_MODEL: 'gpt-4o-mini' }),
    );
    expect(provider).toBeInstanceOf(OpenAiCompatibleProvider);
  });

  it('rejects on first use when AI_PROVIDER=openai and OPENAI_MODEL is missing (no safe default)', async () => {
    const provider = buildAiProvider(configWith({ AI_PROVIDER: 'openai', OPENAI_API_KEY: 'key' }));
    await expect(
      provider.complete({ system: 'sys', messages: [{ role: 'user', content: 'hi' }] }),
    ).rejects.toThrow('OPENAI_MODEL is required');
  });

  it('accepts a custom base URL for OpenAI-compatible providers like Groq', () => {
    const provider = buildAiProvider(
      configWith({
        AI_PROVIDER: 'openai',
        OPENAI_API_KEY: 'key',
        OPENAI_MODEL: 'llama-3.3-70b',
        OPENAI_BASE_URL: 'https://api.groq.com/openai/v1',
      }),
    );
    expect(provider).toBeInstanceOf(OpenAiCompatibleProvider);
  });

  it('rejects on first use with a clear error for an unknown provider name', async () => {
    const provider = buildAiProvider(configWith({ AI_PROVIDER: 'not-a-real-provider' }));
    await expect(
      provider.complete({ system: 'sys', messages: [{ role: 'user', content: 'hi' }] }),
    ).rejects.toThrow('Unknown AI_PROVIDER');
  });

  it('is case-insensitive on the provider name', () => {
    const provider = buildAiProvider(
      configWith({ AI_PROVIDER: 'GOOGLE', GOOGLE_API_KEY: 'key' }),
    );
    expect(provider).toBeInstanceOf(GoogleProvider);
  });
});
