import { Provider } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { AI_PROVIDER, AiProvider } from './ai-provider.interface';
import { AnthropicProvider } from './anthropic.provider';
import { GoogleProvider } from './google.provider';
import { OpenAiCompatibleProvider } from './openai-compatible.provider';

/**
 * Picks which AI vendor to use, from one env var: AI_PROVIDER =
 * "anthropic" | "google" | "openai". Everything else in the app depends
 * on the AI_PROVIDER token and the AiProvider interface — nothing else
 * needs to change to switch vendors or add a new one.
 *
 * To add a new provider: implement AiProvider in a new file in this
 * folder, add a case below, add its API key/model env vars to
 * .env.example. That's the whole change — see docs/CHANGE-GUIDE.md.
 *
 * Misconfiguration (missing key, unknown provider name) is NOT thrown
 * here — it's deferred to the first `.complete()` call. Throwing during
 * module construction would mean the entire app fails to boot whenever
 * AI config is missing, even for people only working on auth or the
 * dashboard. Instead, every other feature works normally, and only a
 * request that actually needs the AI provider fails, with a clear message.
 */
export function buildAiProvider(config: ConfigService): AiProvider {
  try {
    return buildConfiguredProvider(config);
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    return {
      complete: () => Promise.reject(new Error(message)),
    };
  }
}

function buildConfiguredProvider(config: ConfigService): AiProvider {
  const providerName = (config.get<string>('AI_PROVIDER') ?? 'anthropic').toLowerCase();

  switch (providerName) {
    case 'anthropic': {
      const apiKey = config.get<string>('ANTHROPIC_API_KEY');
      if (!apiKey) throw new Error('ANTHROPIC_API_KEY is required when AI_PROVIDER=anthropic');
      return new AnthropicProvider(apiKey, config.get<string>('CLAUDE_MODEL') ?? 'claude-sonnet-5');
    }

    case 'google': {
      const apiKey = config.get<string>('GOOGLE_API_KEY');
      if (!apiKey) throw new Error('GOOGLE_API_KEY is required when AI_PROVIDER=google');
      return new GoogleProvider(apiKey, config.get<string>('GEMINI_MODEL') ?? 'gemini-2.5-flash');
    }

    case 'openai': {
      const apiKey = config.get<string>('OPENAI_API_KEY');
      if (!apiKey) throw new Error('OPENAI_API_KEY is required when AI_PROVIDER=openai');
      const baseUrl = config.get<string>('OPENAI_BASE_URL') ?? 'https://api.openai.com/v1';
      const model = config.get<string>('OPENAI_MODEL');
      if (!model) {
        throw new Error(
          'OPENAI_MODEL is required when AI_PROVIDER=openai — there is no safe default ' +
            'since this path is used for many different compatible services.',
        );
      }
      return new OpenAiCompatibleProvider(apiKey, model, baseUrl);
    }

    default:
      throw new Error(
        `Unknown AI_PROVIDER "${providerName}". Expected "anthropic", "google", or "openai".`,
      );
  }
}

export const aiProviderFactory: Provider = {
  provide: AI_PROVIDER,
  inject: [ConfigService],
  useFactory: buildAiProvider,
};
