import { parseFeedback } from './feedback-parser';

describe('parseFeedback', () => {
  it('parses a clean JSON response', () => {
    const result = parseFeedback(
      '{"score": 82, "strengths": ["Clear communication"], "improvements": ["Be more specific"]}',
    );
    expect(result).toEqual({
      score: 82,
      strengths: ['Clear communication'],
      improvements: ['Be more specific'],
    });
  });

  it('strips markdown code fences before parsing', () => {
    const result = parseFeedback(
      '```json\n{"score": 70, "strengths": ["Good pacing"], "improvements": ["More detail"]}\n```',
    );
    expect(result?.score).toBe(70);
  });

  it('strips leading/trailing whitespace', () => {
    const result = parseFeedback(
      '   \n{"score": 55, "strengths": ["Ok"], "improvements": ["Ok"]}\n   ',
    );
    expect(result?.score).toBe(55);
  });

  it('returns null for invalid JSON', () => {
    expect(parseFeedback('Sorry, I cannot evaluate this.')).toBeNull();
  });

  it('returns null when the JSON is missing required fields', () => {
    expect(parseFeedback('{"score": 82}')).toBeNull();
  });

  it('returns null when strengths/improvements are not arrays', () => {
    expect(
      parseFeedback('{"score": 82, "strengths": "good", "improvements": ["ok"]}'),
    ).toBeNull();
  });

  it('returns null when score is not a number', () => {
    expect(
      parseFeedback('{"score": "high", "strengths": ["ok"], "improvements": ["ok"]}'),
    ).toBeNull();
  });
});
