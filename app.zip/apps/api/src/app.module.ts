import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { PrismaModule } from './prisma/prisma.module';
import { UsersModule } from './users/users.module';
import { AuthModule } from './auth/auth.module';
import { HealthModule } from './health/health.module';
import { InterviewsModule } from './interviews/interviews.module';
import { ResumesModule } from './resumes/resumes.module';
import { QuestionsModule } from './questions/questions.module';
import { MeetingAssistantModule } from './meeting-assistant/meeting-assistant.module';

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true }),
    PrismaModule,
    UsersModule,
    AuthModule,
    HealthModule,
    InterviewsModule,
    ResumesModule,
    QuestionsModule,
    MeetingAssistantModule,
  ],
})
export class AppModule {}
