import { Test } from '@nestjs/testing';
import { BadRequestException, NotFoundException } from '@nestjs/common';
import { InterviewsService } from './interviews.service';
import { PrismaService } from '../prisma/prisma.service';
import { AI_PROVIDER } from '../ai/providers/ai-provider.interface';

describe('InterviewsService', () => {
  let service: InterviewsService;

  const prismaMock = {
    interviewSession: {
      create: jest.fn(),
      findUnique: jest.fn(),
      update: jest.fn(),
      findMany: jest.fn(),
    },
    interviewMessage: {
      create: jest.fn(),
      findMany: jest.fn(),
    },
  };

  const aiProviderMock = { complete: jest.fn() };

  beforeEach(async () => {
    jest.clearAllMocks();

    const moduleRef = await Test.createTestingModule({
      providers: [
        InterviewsService,
        { provide: PrismaService, useValue: prismaMock },
        { provide: AI_PROVIDER, useValue: aiProviderMock },
      ],
    }).compile();

    service = moduleRef.get(InterviewsService);
  });

  describe('startSession', () => {
    it('creates a session, asks Claude for an opening question, and stores it', async () => {
      prismaMock.interviewSession.create.mockResolvedValue({
        id: 'session-1',
        userId: 'user-1',
        role: 'Backend Engineer',
        company: 'Acme',
        status: 'IN_PROGRESS',
      });
      aiProviderMock.complete.mockResolvedValue('Tell me about yourself.');
      prismaMock.interviewMessage.create.mockResolvedValue({
        id: 'msg-1',
        sequenceNumber: 1,
        role: 'INTERVIEWER',
        content: 'Tell me about yourself.',
      });

      const result = await service.startSession('user-1', {
        role: 'Backend Engineer',
        company: 'Acme',
      });

      expect(prismaMock.interviewSession.create).toHaveBeenCalledWith({
        data: { userId: 'user-1', role: 'Backend Engineer', company: 'Acme' },
      });

      const claudeCallArgs = aiProviderMock.complete.mock.calls[0][0];
      expect(claudeCallArgs.system).toContain('Backend Engineer');
      expect(claudeCallArgs.system).toContain('Acme');

      expect(prismaMock.interviewMessage.create).toHaveBeenCalledWith({
        data: {
          sessionId: 'session-1',
          role: 'INTERVIEWER',
          content: 'Tell me about yourself.',
          sequenceNumber: 1,
        },
      });

      expect(result).toEqual({
        session: expect.objectContaining({ id: 'session-1' }),
        question: 'Tell me about yourself.',
      });
    });
  });

  describe('submitAnswer', () => {
    it('throws NotFoundException when the session does not exist', async () => {
      prismaMock.interviewSession.findUnique.mockResolvedValue(null);

      await expect(service.submitAnswer('user-1', 'missing', 'answer')).rejects.toBeInstanceOf(
        NotFoundException,
      );
    });

    it('throws NotFoundException when the session belongs to a different user', async () => {
      prismaMock.interviewSession.findUnique.mockResolvedValue({
        id: 'session-1',
        userId: 'someone-else',
        status: 'IN_PROGRESS',
      });

      await expect(service.submitAnswer('user-1', 'session-1', 'answer')).rejects.toBeInstanceOf(
        NotFoundException,
      );
    });

    it('throws BadRequestException when the interview has already ended', async () => {
      prismaMock.interviewSession.findUnique.mockResolvedValue({
        id: 'session-1',
        userId: 'user-1',
        status: 'COMPLETED',
      });

      await expect(service.submitAnswer('user-1', 'session-1', 'answer')).rejects.toBeInstanceOf(
        BadRequestException,
      );
    });

    it('stores the answer, asks Claude for the next question, and returns it', async () => {
      prismaMock.interviewSession.findUnique.mockResolvedValue({
        id: 'session-1',
        userId: 'user-1',
        role: 'Backend Engineer',
        company: null,
        status: 'IN_PROGRESS',
      });
      prismaMock.interviewMessage.findMany.mockResolvedValue([
        { role: 'INTERVIEWER', content: 'Tell me about yourself.', sequenceNumber: 1 },
      ]);
      prismaMock.interviewMessage.create
        .mockResolvedValueOnce({
          role: 'CANDIDATE',
          content: 'I am a backend engineer with 5 years of experience.',
          sequenceNumber: 2,
        })
        .mockResolvedValueOnce({
          role: 'INTERVIEWER',
          content: 'What was the hardest bug you fixed?',
          sequenceNumber: 3,
        });
      aiProviderMock.complete.mockResolvedValue('What was the hardest bug you fixed?');

      const result = await service.submitAnswer(
        'user-1',
        'session-1',
        'I am a backend engineer with 5 years of experience.',
      );

      expect(prismaMock.interviewMessage.create).toHaveBeenNthCalledWith(1, {
        data: {
          sessionId: 'session-1',
          role: 'CANDIDATE',
          content: 'I am a backend engineer with 5 years of experience.',
          sequenceNumber: 2,
        },
      });

      expect(result).toEqual({
        question: 'What was the hardest bug you fixed?',
        questionCount: 2,
        suggestWrapUp: false,
      });
    });
  });

  describe('completeSession', () => {
    const inProgressSession = {
      id: 'session-1',
      userId: 'user-1',
      role: 'Backend Engineer',
      company: 'Acme',
      status: 'IN_PROGRESS',
    };

    it('throws BadRequestException when fewer than 2 messages exist', async () => {
      prismaMock.interviewSession.findUnique.mockResolvedValue(inProgressSession);
      prismaMock.interviewMessage.findMany.mockResolvedValue([
        { role: 'INTERVIEWER', content: 'Q1', sequenceNumber: 1 },
      ]);

      await expect(service.completeSession('user-1', 'session-1')).rejects.toBeInstanceOf(
        BadRequestException,
      );
    });

    it('parses valid JSON feedback and updates the session', async () => {
      prismaMock.interviewSession.findUnique.mockResolvedValue(inProgressSession);
      prismaMock.interviewMessage.findMany.mockResolvedValue([
        { role: 'INTERVIEWER', content: 'Q1', sequenceNumber: 1 },
        { role: 'CANDIDATE', content: 'A1', sequenceNumber: 2 },
      ]);
      aiProviderMock.complete.mockResolvedValue(
        '{"score": 82, "strengths": ["Clear communication"], "improvements": ["More specific examples"]}',
      );
      prismaMock.interviewSession.update.mockResolvedValue({
        ...inProgressSession,
        status: 'COMPLETED',
        score: 82,
      });

      const result = await service.completeSession('user-1', 'session-1');

      expect(prismaMock.interviewSession.update).toHaveBeenCalledWith({
        where: { id: 'session-1' },
        data: expect.objectContaining({
          status: 'COMPLETED',
          score: 82,
          feedback: expect.stringContaining('Clear communication'),
        }),
      });
      expect(result.score).toBe(82);
    });

    it('falls back to storing raw text when Claude does not return valid JSON', async () => {
      prismaMock.interviewSession.findUnique.mockResolvedValue(inProgressSession);
      prismaMock.interviewMessage.findMany.mockResolvedValue([
        { role: 'INTERVIEWER', content: 'Q1', sequenceNumber: 1 },
        { role: 'CANDIDATE', content: 'A1', sequenceNumber: 2 },
      ]);
      aiProviderMock.complete.mockResolvedValue('Sorry, I cannot evaluate this.');
      prismaMock.interviewSession.update.mockResolvedValue({ ...inProgressSession, score: null });

      await service.completeSession('user-1', 'session-1');

      expect(prismaMock.interviewSession.update).toHaveBeenCalledWith({
        where: { id: 'session-1' },
        data: expect.objectContaining({
          score: null,
          feedback: 'Sorry, I cannot evaluate this.',
        }),
      });
    });

    it('throws BadRequestException when the session is already completed', async () => {
      prismaMock.interviewSession.findUnique.mockResolvedValue({
        ...inProgressSession,
        status: 'COMPLETED',
      });

      await expect(service.completeSession('user-1', 'session-1')).rejects.toBeInstanceOf(
        BadRequestException,
      );
    });
  });

  describe('getSession', () => {
    it('throws NotFoundException when not owned by the requesting user', async () => {
      prismaMock.interviewSession.findUnique.mockResolvedValue({
        id: 'session-1',
        userId: 'someone-else',
      });

      await expect(service.getSession('user-1', 'session-1')).rejects.toBeInstanceOf(
        NotFoundException,
      );
    });

    it('returns the session with its messages in order', async () => {
      prismaMock.interviewSession.findUnique.mockResolvedValue({
        id: 'session-1',
        userId: 'user-1',
      });
      prismaMock.interviewMessage.findMany.mockResolvedValue([
        { sequenceNumber: 1, content: 'Q1' },
        { sequenceNumber: 2, content: 'A1' },
      ]);

      const result = await service.getSession('user-1', 'session-1');

      expect(result.messages).toHaveLength(2);
      expect(prismaMock.interviewMessage.findMany).toHaveBeenCalledWith({
        where: { sessionId: 'session-1' },
        orderBy: { sequenceNumber: 'asc' },
      });
    });
  });
});
