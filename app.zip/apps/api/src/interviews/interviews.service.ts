import { BadRequestException, Inject, Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { AI_PROVIDER, AiProvider } from '../ai/providers/ai-provider.interface';
import { StartInterviewDto } from './dto/start-interview.dto';
import {
  buildFeedbackSystemPrompt,
  buildFeedbackUserPrompt,
  buildInterviewerSystemPrompt,
  buildOpeningUserPrompt,
  parseFeedback,
  toProviderMessages,
} from './interview-prompts';

const MAX_QUESTIONS_HINT = 8; // soft guidance surfaced to the client, not enforced server-side

@Injectable()
export class InterviewsService {
  constructor(
    private readonly prisma: PrismaService,
    @Inject(AI_PROVIDER) private readonly ai: AiProvider,
  ) {}

  async startSession(userId: string, dto: StartInterviewDto) {
    const session = await this.prisma.interviewSession.create({
      data: { userId, role: dto.role, company: dto.company },
    });

    const question = await this.ai.complete({
      system: buildInterviewerSystemPrompt(dto.role, dto.company),
      messages: [{ role: 'user', content: buildOpeningUserPrompt() }],
    });

    const message = await this.prisma.interviewMessage.create({
      data: {
        sessionId: session.id,
        role: 'INTERVIEWER',
        content: question,
        sequenceNumber: 1,
      },
    });

    return { session, question: message.content };
  }

  async submitAnswer(userId: string, sessionId: string, content: string) {
    const session = await this.getOwnedSession(userId, sessionId);

    if (session.status !== 'IN_PROGRESS') {
      throw new BadRequestException('This interview has already ended.');
    }

    const priorMessages = await this.prisma.interviewMessage.findMany({
      where: { sessionId },
      orderBy: { sequenceNumber: 'asc' },
    });

    const candidateMessage = await this.prisma.interviewMessage.create({
      data: {
        sessionId,
        role: 'CANDIDATE',
        content,
        sequenceNumber: priorMessages.length + 1,
      },
    });

    const nextQuestion = await this.ai.complete({
      system: buildInterviewerSystemPrompt(session.role, session.company ?? undefined),
      messages: toProviderMessages([...priorMessages, candidateMessage]),
    });

    const interviewerMessage = await this.prisma.interviewMessage.create({
      data: {
        sessionId,
        role: 'INTERVIEWER',
        content: nextQuestion,
        sequenceNumber: priorMessages.length + 2,
      },
    });

    return {
      question: interviewerMessage.content,
      questionCount: Math.ceil(interviewerMessage.sequenceNumber / 2),
      suggestWrapUp: interviewerMessage.sequenceNumber / 2 >= MAX_QUESTIONS_HINT,
    };
  }

  async completeSession(userId: string, sessionId: string) {
    const session = await this.getOwnedSession(userId, sessionId);

    if (session.status !== 'IN_PROGRESS') {
      throw new BadRequestException('This interview has already ended.');
    }

    const messages = await this.prisma.interviewMessage.findMany({
      where: { sessionId },
      orderBy: { sequenceNumber: 'asc' },
    });

    if (messages.length < 2) {
      throw new BadRequestException('Answer at least one question before completing the interview.');
    }

    const rawFeedback = await this.ai.complete({
      system: buildFeedbackSystemPrompt(session.role, session.company ?? undefined),
      messages: [...toProviderMessages(messages), { role: 'user', content: buildFeedbackUserPrompt() }],
      maxTokens: 512,
    });

    const parsed = parseFeedback(rawFeedback);

    return this.prisma.interviewSession.update({
      where: { id: sessionId },
      data: {
        status: 'COMPLETED',
        completedAt: new Date(),
        score: parsed?.score ?? null,
        feedback: parsed ? JSON.stringify(parsed) : rawFeedback,
      },
    });
  }

  async getSession(userId: string, sessionId: string) {
    const session = await this.getOwnedSession(userId, sessionId);
    const messages = await this.prisma.interviewMessage.findMany({
      where: { sessionId },
      orderBy: { sequenceNumber: 'asc' },
    });
    return { ...session, messages };
  }

  listSessions(userId: string) {
    return this.prisma.interviewSession.findMany({
      where: { userId },
      orderBy: { createdAt: 'desc' },
      select: {
        id: true,
        role: true,
        company: true,
        status: true,
        score: true,
        createdAt: true,
        completedAt: true,
      },
    });
  }

  /**
   * Looks up a session and confirms it belongs to the requesting user in
   * one step. Returns NotFoundException (never Forbidden) in both the
   * "doesn't exist" and "belongs to someone else" cases, deliberately, so
   * a user can't tell the difference between the two by probing IDs.
   */
  private async getOwnedSession(userId: string, sessionId: string) {
    const session = await this.prisma.interviewSession.findUnique({ where: { id: sessionId } });
    if (!session || session.userId !== userId) {
      throw new NotFoundException('Interview session not found.');
    }
    return session;
  }
}
