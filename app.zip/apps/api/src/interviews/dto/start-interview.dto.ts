import { IsOptional, IsString, MaxLength, MinLength } from 'class-validator';

export class StartInterviewDto {
  @IsString()
  @MinLength(2)
  @MaxLength(100)
  role!: string;

  @IsOptional()
  @IsString()
  @MaxLength(100)
  company?: string;
}
