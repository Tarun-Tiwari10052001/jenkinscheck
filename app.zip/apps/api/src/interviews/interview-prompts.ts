import { CompletionMessage } from '../ai/providers/ai-provider.interface';
export { parseFeedback, ParsedFeedback } from '../ai/feedback-parser';

/**
 * All prompt text for this engine lives in this one file. If prompt quality
 * needs tuning, this is the only file that should need editing — see
 * docs/CHANGE-GUIDE.md.
 */

export function buildInterviewerSystemPrompt(role: string, company?: string): string {
  const context = company ? `a ${role} position at ${company}` : `a ${role} position`;
  return [
    `You are an experienced, friendly interviewer conducting a mock interview for ${context}.`,
    'Ask exactly one question per turn. Base each question on the candidate\'s previous answer',
    'where it makes sense, the way a real interviewer follows up on what was just said.',
    'Mix behavioral and role-relevant technical questions. Keep questions concise —',
    'one to three sentences. Do not answer on the candidate\'s behalf, do not break character,',
    'and do not include any preamble like "Question 1:" — just ask the question directly.',
  ].join(' ');
}

export function buildOpeningUserPrompt(): string {
  return 'Begin the interview with your first question.';
}

export function buildFeedbackSystemPrompt(role: string, company?: string): string {
  const context = company ? `a ${role} position at ${company}` : `a ${role} position`;
  return [
    `You just finished mock-interviewing a candidate for ${context}.`,
    'Review the full transcript and respond with ONLY a JSON object, no other text,',
    'no markdown code fences, in exactly this shape:',
    '{"score": <integer 0-100>, "strengths": [<2-4 short strings>], "improvements": [<2-4 short strings>]}',
    'Score holistically: clarity, structure (e.g. STAR for behavioral answers), and relevance.',
  ].join(' ');
}

export function buildFeedbackUserPrompt(): string {
  return 'Here is the full transcript above. Provide your JSON evaluation now.';
}

/** Converts stored InterviewMessage rows into the role/content shape every AI provider expects. */
export function toProviderMessages(
  messages: { role: 'INTERVIEWER' | 'CANDIDATE'; content: string }[],
): CompletionMessage[] {
  return messages.map((m) => ({
    role: m.role === 'INTERVIEWER' ? 'assistant' : 'user',
    content: m.content,
  }));
}
