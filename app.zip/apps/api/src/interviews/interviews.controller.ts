import { Body, Controller, Get, Param, Post, Req, UseGuards } from '@nestjs/common';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { InterviewsService } from './interviews.service';
import { StartInterviewDto } from './dto/start-interview.dto';
import { SubmitAnswerDto } from './dto/submit-answer.dto';

@UseGuards(JwtAuthGuard)
@Controller('interviews')
export class InterviewsController {
  constructor(private readonly interviewsService: InterviewsService) {}

  @Post()
  start(@Req() req: any, @Body() dto: StartInterviewDto) {
    return this.interviewsService.startSession(req.user.userId, dto);
  }

  @Get()
  list(@Req() req: any) {
    return this.interviewsService.listSessions(req.user.userId);
  }

  @Get(':id')
  getOne(@Req() req: any, @Param('id') id: string) {
    return this.interviewsService.getSession(req.user.userId, id);
  }

  @Post(':id/answer')
  answer(@Req() req: any, @Param('id') id: string, @Body() dto: SubmitAnswerDto) {
    return this.interviewsService.submitAnswer(req.user.userId, id, dto.content);
  }

  @Post(':id/complete')
  complete(@Req() req: any, @Param('id') id: string) {
    return this.interviewsService.completeSession(req.user.userId, id);
  }
}
