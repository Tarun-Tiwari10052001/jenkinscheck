/**
 * Plain domain type mirroring the `User` model in prisma/schema.prisma.
 *
 * Why this exists instead of importing `User` from '@prisma/client':
 * the generated Prisma client types only exist after `npx prisma generate`
 * has run, which needs to download its query engine binary. In locked-down
 * network environments that download can be blocked, which would break
 * every file that imports model types from '@prisma/client' — even though
 * nothing here actually needs the generated client at compile time.
 * Keeping domain types here means the service layer compiles and tests run
 * regardless of that step. Once `prisma generate` has run in your
 * environment, PrismaService's return values structurally match this type,
 * so nothing else needs to change.
 */
export interface User {
  id: string;
  email: string;
  passwordHash: string;
  name: string | null;
  plan: 'FREE' | 'PRO';
  createdAt: Date;
  updatedAt: Date;
}
