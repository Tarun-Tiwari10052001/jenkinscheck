import { Test } from '@nestjs/testing';
import { UsersService } from './users.service';
import { PrismaService } from '../prisma/prisma.service';

describe('UsersService', () => {
  let service: UsersService;
  const prismaMock = {
    user: {
      findUnique: jest.fn(),
      create: jest.fn(),
    },
  };

  beforeEach(async () => {
    jest.clearAllMocks();
    const moduleRef = await Test.createTestingModule({
      providers: [UsersService, { provide: PrismaService, useValue: prismaMock }],
    }).compile();

    service = moduleRef.get(UsersService);
  });

  it('finds a user by email', async () => {
    prismaMock.user.findUnique.mockResolvedValue({ id: '1', email: 'a@b.com' });

    const result = await service.findByEmail('a@b.com');

    expect(prismaMock.user.findUnique).toHaveBeenCalledWith({ where: { email: 'a@b.com' } });
    expect(result).toEqual({ id: '1', email: 'a@b.com' });
  });

  it('returns null when no user matches the email', async () => {
    prismaMock.user.findUnique.mockResolvedValue(null);

    const result = await service.findByEmail('missing@b.com');

    expect(result).toBeNull();
  });

  it('finds a user by id', async () => {
    prismaMock.user.findUnique.mockResolvedValue({ id: '1', email: 'a@b.com' });

    const result = await service.findById('1');

    expect(prismaMock.user.findUnique).toHaveBeenCalledWith({ where: { id: '1' } });
    expect(result).toEqual({ id: '1', email: 'a@b.com' });
  });

  it('creates a user with the given data', async () => {
    const input = { email: 'new@b.com', passwordHash: 'hashed' };
    prismaMock.user.create.mockResolvedValue({ id: '2', ...input });

    const result = await service.create(input);

    expect(prismaMock.user.create).toHaveBeenCalledWith({ data: input });
    expect(result).toEqual({ id: '2', ...input });
  });
});
