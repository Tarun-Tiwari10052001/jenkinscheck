import { CompletionMessage } from '../ai/providers/ai-provider.interface';

/**
 * All prompt text for the Meeting Assistant lives in this one file — see
 * docs/CHANGE-GUIDE.md. The system prompt defines the assistant's intended
 * scope and behavior.
 */

export function buildSuggestSystemPrompt(title: string, contextNotes?: string): string {
  const context = contextNotes
    ? `Context the user provided about this call: ${contextNotes}`
    : 'No additional context was provided about this call.';

  return [
    `You are a real-time assistant helping a user respond well during their own work call, "${title}".`,
    context,
    'The user will show you what the other person just said. Suggest a short, natural response the',
    'user could say — specific and grounded in the context given, not generic advice. One to three',
    'sentences, in the first person, as if the user is about to say it themselves.',
    'This tool is for the user\'s own legitimate work calls (sales, support, internal meetings) —',
    'never for a job interview, licensing exam, academic exam, or any assessment meant to measure',
    'the user\'s own unaided ability. If the transcript sounds like it might be from one of those',
    'contexts instead, say so plainly and decline to suggest a scripted answer, since providing one',
    'would help misrepresent the user\'s actual ability to whoever is assessing them.',
    'Output ONLY the suggested response text, no labels, no preamble.',
  ].join(' ');
}

export function buildSuggestUserPrompt(transcript: string): string {
  return `The other person just said: "${transcript}"`;
}

/** Converts stored MeetingTurn rows into the role/content shape every AI provider expects. */
export function toProviderMessages(
  turns: { speaker: 'OTHER' | 'ME'; content: string }[],
): CompletionMessage[] {
  return turns.map((t) => ({
    role: t.speaker === 'OTHER' ? 'user' : 'assistant',
    content: t.content,
  }));
}
