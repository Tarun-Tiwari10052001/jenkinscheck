import { BadRequestException, Inject, Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { AI_PROVIDER, AiProvider } from '../ai/providers/ai-provider.interface';
import { StartSessionDto } from './dto/start-session.dto';
import { buildSuggestSystemPrompt, buildSuggestUserPrompt, toProviderMessages } from './meeting-prompts';

const MAX_CONTEXT_TURNS = 20; // recent turns sent to the AI, to bound token cost on long calls

@Injectable()
export class MeetingAssistantService {
  constructor(
    private readonly prisma: PrismaService,
    @Inject(AI_PROVIDER) private readonly ai: AiProvider,
  ) {}

  startSession(userId: string, dto: StartSessionDto) {
    return this.prisma.meetingSession.create({
      data: { userId, title: dto.title, contextNotes: dto.contextNotes },
    });
  }

  /**
   * Records what the other person said, asks the AI for a suggested
   * response grounded in the session's context and recent turns, and
   * returns it. Does not log the suggestion as something the user said —
   * see logTurn() for that, which the client calls separately once the
   * user has actually said something (whether or not they used the
   * suggestion verbatim).
   */
  async suggest(userId: string, sessionId: string, transcript: string) {
    const session = await this.getOwnedSession(userId, sessionId);
    if (session.status !== 'ACTIVE') {
      throw new BadRequestException('This session has already ended.');
    }

    const priorTurns = await this.prisma.meetingTurn.findMany({
      where: { sessionId },
      orderBy: { sequenceNumber: 'desc' },
      take: MAX_CONTEXT_TURNS,
    });
    priorTurns.reverse();

    const otherTurn = await this.prisma.meetingTurn.create({
      data: {
        sessionId,
        speaker: 'OTHER',
        content: transcript,
        sequenceNumber: priorTurns.length ? priorTurns[priorTurns.length - 1].sequenceNumber + 1 : 1,
      },
    });

    const suggestion = await this.ai.complete({
      system: buildSuggestSystemPrompt(session.title, session.contextNotes ?? undefined),
      messages: toProviderMessages([...priorTurns, otherTurn]),
      maxTokens: 300,
    });

    return { suggestion: suggestion.trim() };
  }

  /** Logs what the user actually said, for conversational context on the next suggest() call. */
  async logTurn(userId: string, sessionId: string, content: string) {
    const session = await this.getOwnedSession(userId, sessionId);
    if (session.status !== 'ACTIVE') {
      throw new BadRequestException('This session has already ended.');
    }

    const lastTurn = await this.prisma.meetingTurn.findFirst({
      where: { sessionId },
      orderBy: { sequenceNumber: 'desc' },
    });

    return this.prisma.meetingTurn.create({
      data: {
        sessionId,
        speaker: 'ME',
        content,
        sequenceNumber: (lastTurn?.sequenceNumber ?? 0) + 1,
      },
    });
  }

  async endSession(userId: string, sessionId: string) {
    const session = await this.getOwnedSession(userId, sessionId);
    if (session.status !== 'ACTIVE') {
      throw new BadRequestException('This session has already ended.');
    }

    return this.prisma.meetingSession.update({
      where: { id: sessionId },
      data: { status: 'ENDED', endedAt: new Date() },
    });
  }

  async getSession(userId: string, sessionId: string) {
    const session = await this.getOwnedSession(userId, sessionId);
    const turns = await this.prisma.meetingTurn.findMany({
      where: { sessionId },
      orderBy: { sequenceNumber: 'asc' },
    });
    return { ...session, turns };
  }

  listSessions(userId: string) {
    return this.prisma.meetingSession.findMany({
      where: { userId },
      orderBy: { createdAt: 'desc' },
      select: { id: true, title: true, status: true, createdAt: true, endedAt: true },
    });
  }

  async remove(userId: string, sessionId: string): Promise<void> {
    await this.getOwnedSession(userId, sessionId);
    await this.prisma.meetingTurn.deleteMany({ where: { sessionId } });
    await this.prisma.meetingSession.delete({ where: { id: sessionId } });
  }

  /** Same ownership-check pattern as InterviewsService/ResumesService. */
  private async getOwnedSession(userId: string, sessionId: string) {
    const session = await this.prisma.meetingSession.findUnique({ where: { id: sessionId } });
    if (!session || session.userId !== userId) {
      throw new NotFoundException('Meeting session not found.');
    }
    return session;
  }
}
