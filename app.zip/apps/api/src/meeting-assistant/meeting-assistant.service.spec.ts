import { Test } from '@nestjs/testing';
import { BadRequestException, NotFoundException } from '@nestjs/common';
import { MeetingAssistantService } from './meeting-assistant.service';
import { PrismaService } from '../prisma/prisma.service';
import { AI_PROVIDER } from '../ai/providers/ai-provider.interface';

describe('MeetingAssistantService', () => {
  let service: MeetingAssistantService;

  const prismaMock = {
    meetingSession: {
      create: jest.fn(),
      findUnique: jest.fn(),
      update: jest.fn(),
      findMany: jest.fn(),
      delete: jest.fn(),
    },
    meetingTurn: {
      create: jest.fn(),
      findMany: jest.fn(),
      findFirst: jest.fn(),
      deleteMany: jest.fn(),
    },
  };

  const aiProviderMock = { complete: jest.fn() };

  beforeEach(async () => {
    jest.clearAllMocks();

    const moduleRef = await Test.createTestingModule({
      providers: [
        MeetingAssistantService,
        { provide: PrismaService, useValue: prismaMock },
        { provide: AI_PROVIDER, useValue: aiProviderMock },
      ],
    }).compile();

    service = moduleRef.get(MeetingAssistantService);
  });

  describe('startSession', () => {
    it('creates a session with the given title and optional context notes', async () => {
      prismaMock.meetingSession.create.mockResolvedValue({ id: 'session-1' });

      await service.startSession('user-1', {
        title: 'Customer renewal call',
        contextNotes: 'Customer is unhappy about pricing',
      });

      expect(prismaMock.meetingSession.create).toHaveBeenCalledWith({
        data: {
          userId: 'user-1',
          title: 'Customer renewal call',
          contextNotes: 'Customer is unhappy about pricing',
        },
      });
    });
  });

  describe('suggest', () => {
    const activeSession = {
      id: 'session-1',
      userId: 'user-1',
      title: 'Customer renewal call',
      contextNotes: null,
      status: 'ACTIVE',
    };

    it('throws NotFoundException when the session is not owned', async () => {
      prismaMock.meetingSession.findUnique.mockResolvedValue(null);

      await expect(service.suggest('user-1', 'missing', 'hello')).rejects.toBeInstanceOf(
        NotFoundException,
      );
    });

    it('throws BadRequestException when the session has already ended', async () => {
      prismaMock.meetingSession.findUnique.mockResolvedValue({ ...activeSession, status: 'ENDED' });

      await expect(service.suggest('user-1', 'session-1', 'hello')).rejects.toBeInstanceOf(
        BadRequestException,
      );
    });

    it('stores the transcript, includes session context in the prompt, and returns the suggestion', async () => {
      prismaMock.meetingSession.findUnique.mockResolvedValue(activeSession);
      prismaMock.meetingTurn.findMany.mockResolvedValue([]);
      prismaMock.meetingTurn.create.mockResolvedValue({
        id: 't1',
        speaker: 'OTHER',
        content: 'Can you lower the price?',
        sequenceNumber: 1,
      });
      aiProviderMock.complete.mockResolvedValue('  I can look at a multi-year discount instead.  ');

      const result = await service.suggest('user-1', 'session-1', 'Can you lower the price?');

      expect(prismaMock.meetingTurn.create).toHaveBeenCalledWith({
        data: { sessionId: 'session-1', speaker: 'OTHER', content: 'Can you lower the price?', sequenceNumber: 1 },
      });

      const callArgs = aiProviderMock.complete.mock.calls[0][0];
      expect(callArgs.system).toContain('Customer renewal call');

      expect(result).toEqual({ suggestion: 'I can look at a multi-year discount instead.' });
    });

    it('caps the conversation history sent to the AI at 20 recent turns', async () => {
      prismaMock.meetingSession.findUnique.mockResolvedValue(activeSession);
      prismaMock.meetingTurn.findMany.mockResolvedValue([]);
      prismaMock.meetingTurn.create.mockResolvedValue({
        id: 't1',
        speaker: 'OTHER',
        content: 'hi',
        sequenceNumber: 1,
      });
      aiProviderMock.complete.mockResolvedValue('response');

      await service.suggest('user-1', 'session-1', 'hi');

      expect(prismaMock.meetingTurn.findMany).toHaveBeenCalledWith(
        expect.objectContaining({ take: 20 }),
      );
    });
  });

  describe('logTurn', () => {
    it('throws NotFoundException when the session is not owned', async () => {
      prismaMock.meetingSession.findUnique.mockResolvedValue(null);

      await expect(service.logTurn('user-1', 'missing', 'my answer')).rejects.toBeInstanceOf(
        NotFoundException,
      );
    });

    it('assigns the next sequence number after the last turn', async () => {
      prismaMock.meetingSession.findUnique.mockResolvedValue({
        id: 'session-1',
        userId: 'user-1',
        status: 'ACTIVE',
      });
      prismaMock.meetingTurn.findFirst.mockResolvedValue({ sequenceNumber: 4 });
      prismaMock.meetingTurn.create.mockResolvedValue({ id: 't5' });

      await service.logTurn('user-1', 'session-1', 'my answer');

      expect(prismaMock.meetingTurn.create).toHaveBeenCalledWith({
        data: { sessionId: 'session-1', speaker: 'ME', content: 'my answer', sequenceNumber: 5 },
      });
    });

    it('starts at sequence 1 when there are no prior turns', async () => {
      prismaMock.meetingSession.findUnique.mockResolvedValue({
        id: 'session-1',
        userId: 'user-1',
        status: 'ACTIVE',
      });
      prismaMock.meetingTurn.findFirst.mockResolvedValue(null);
      prismaMock.meetingTurn.create.mockResolvedValue({ id: 't1' });

      await service.logTurn('user-1', 'session-1', 'first thing I said');

      expect(prismaMock.meetingTurn.create).toHaveBeenCalledWith(
        expect.objectContaining({ data: expect.objectContaining({ sequenceNumber: 1 }) }),
      );
    });
  });

  describe('endSession', () => {
    it('throws BadRequestException when already ended', async () => {
      prismaMock.meetingSession.findUnique.mockResolvedValue({
        id: 'session-1',
        userId: 'user-1',
        status: 'ENDED',
      });

      await expect(service.endSession('user-1', 'session-1')).rejects.toBeInstanceOf(
        BadRequestException,
      );
    });

    it('marks the session ended with a timestamp', async () => {
      prismaMock.meetingSession.findUnique.mockResolvedValue({
        id: 'session-1',
        userId: 'user-1',
        status: 'ACTIVE',
      });
      prismaMock.meetingSession.update.mockResolvedValue({ id: 'session-1', status: 'ENDED' });

      await service.endSession('user-1', 'session-1');

      expect(prismaMock.meetingSession.update).toHaveBeenCalledWith({
        where: { id: 'session-1' },
        data: { status: 'ENDED', endedAt: expect.any(Date) },
      });
    });
  });

  describe('remove', () => {
    it('throws NotFoundException when not owned, and deletes nothing', async () => {
      prismaMock.meetingSession.findUnique.mockResolvedValue(null);

      await expect(service.remove('user-1', 'missing')).rejects.toBeInstanceOf(NotFoundException);
      expect(prismaMock.meetingSession.delete).not.toHaveBeenCalled();
    });

    it('deletes turns before deleting the session', async () => {
      prismaMock.meetingSession.findUnique.mockResolvedValue({ id: 'session-1', userId: 'user-1' });

      await service.remove('user-1', 'session-1');

      expect(prismaMock.meetingTurn.deleteMany).toHaveBeenCalledWith({ where: { sessionId: 'session-1' } });
      expect(prismaMock.meetingSession.delete).toHaveBeenCalledWith({ where: { id: 'session-1' } });
    });
  });

  describe('listSessions', () => {
    it('scopes results to the requesting user', async () => {
      prismaMock.meetingSession.findMany.mockResolvedValue([]);

      await service.listSessions('user-1');

      expect(prismaMock.meetingSession.findMany).toHaveBeenCalledWith(
        expect.objectContaining({ where: { userId: 'user-1' } }),
      );
    });
  });
});
