import { Body, Controller, Delete, Get, HttpCode, Param, Post, Req, UseGuards } from '@nestjs/common';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { MeetingAssistantService } from './meeting-assistant.service';
import { StartSessionDto } from './dto/start-session.dto';
import { SuggestDto } from './dto/suggest.dto';
import { LogTurnDto } from './dto/log-turn.dto';

@UseGuards(JwtAuthGuard)
@Controller('meeting-assistant/sessions')
export class MeetingAssistantController {
  constructor(private readonly meetingAssistantService: MeetingAssistantService) {}

  @Post()
  start(@Req() req: any, @Body() dto: StartSessionDto) {
    return this.meetingAssistantService.startSession(req.user.userId, dto);
  }

  @Get()
  list(@Req() req: any) {
    return this.meetingAssistantService.listSessions(req.user.userId);
  }

  @Get(':id')
  getOne(@Req() req: any, @Param('id') id: string) {
    return this.meetingAssistantService.getSession(req.user.userId, id);
  }

  @Delete(':id')
  @HttpCode(204)
  async remove(@Req() req: any, @Param('id') id: string) {
    await this.meetingAssistantService.remove(req.user.userId, id);
  }

  @Post(':id/suggest')
  suggest(@Req() req: any, @Param('id') id: string, @Body() dto: SuggestDto) {
    return this.meetingAssistantService.suggest(req.user.userId, id, dto.transcript);
  }

  @Post(':id/log')
  log(@Req() req: any, @Param('id') id: string, @Body() dto: LogTurnDto) {
    return this.meetingAssistantService.logTurn(req.user.userId, id, dto.content);
  }

  @Post(':id/end')
  end(@Req() req: any, @Param('id') id: string) {
    return this.meetingAssistantService.endSession(req.user.userId, id);
  }
}
