import { Module } from '@nestjs/common';
import { MeetingAssistantService } from './meeting-assistant.service';
import { MeetingAssistantController } from './meeting-assistant.controller';
import { AiModule } from '../ai/ai.module';

@Module({
  imports: [AiModule],
  controllers: [MeetingAssistantController],
  providers: [MeetingAssistantService],
  exports: [MeetingAssistantService],
})
export class MeetingAssistantModule {}
