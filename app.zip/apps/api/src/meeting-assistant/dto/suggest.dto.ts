import { IsString, MinLength } from 'class-validator';

export class SuggestDto {
  /** What the other person on the call just said, transcribed. */
  @IsString()
  @MinLength(1, { message: 'Transcript cannot be empty' })
  transcript!: string;
}
