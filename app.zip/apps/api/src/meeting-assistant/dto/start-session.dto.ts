import { IsOptional, IsString, MaxLength, MinLength } from 'class-validator';

export class StartSessionDto {
  @IsString()
  @MinLength(2)
  @MaxLength(150)
  title!: string;

  /** Free text: what the call is about, the user's role in it, anything
   * that helps the AI give relevant suggestions — e.g. "quarterly
   * renewal call with a customer who's unhappy about pricing." */
  @IsOptional()
  @IsString()
  @MaxLength(2000)
  contextNotes?: string;
}
