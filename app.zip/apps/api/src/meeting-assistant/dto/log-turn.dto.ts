import { IsString, MinLength } from 'class-validator';

/** Records what the user actually said, for conversational context —
 * separate from suggest() so the user can log their real words even
 * when they didn't use the suggested response verbatim. */
export class LogTurnDto {
  @IsString()
  @MinLength(1, { message: 'Content cannot be empty' })
  content!: string;
}
