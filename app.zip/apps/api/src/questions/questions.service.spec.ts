import { Test } from '@nestjs/testing';
import { BadGatewayException } from '@nestjs/common';
import { QuestionsService } from './questions.service';
import { PrismaService } from '../prisma/prisma.service';
import { AI_PROVIDER } from '../ai/providers/ai-provider.interface';

describe('QuestionsService', () => {
  let service: QuestionsService;

  const prismaMock = {
    questionBankItem: {
      create: jest.fn(),
      findMany: jest.fn(),
    },
  };

  const aiProviderMock = { complete: jest.fn() };

  beforeEach(async () => {
    jest.clearAllMocks();

    const moduleRef = await Test.createTestingModule({
      providers: [
        QuestionsService,
        { provide: PrismaService, useValue: prismaMock },
        { provide: AI_PROVIDER, useValue: aiProviderMock },
      ],
    }).compile();

    service = moduleRef.get(QuestionsService);
  });

  describe('generate', () => {
    it('parses generated questions and saves each one to the bank', async () => {
      aiProviderMock.complete.mockResolvedValue(
        JSON.stringify([
          { question: 'Tell me about a time you disagreed with a teammate.', category: 'behavioral' },
          { question: 'How would you design a rate limiter?', category: 'system-design' },
        ]),
      );
      prismaMock.questionBankItem.create
        .mockResolvedValueOnce({ id: 'q-1', role: 'Backend Engineer', category: 'behavioral' })
        .mockResolvedValueOnce({ id: 'q-2', role: 'Backend Engineer', category: 'system-design' });

      const result = await service.generate({ role: 'Backend Engineer' });

      expect(prismaMock.questionBankItem.create).toHaveBeenCalledTimes(2);
      expect(prismaMock.questionBankItem.create).toHaveBeenNthCalledWith(1, {
        data: {
          role: 'Backend Engineer',
          company: undefined,
          topic: undefined,
          category: 'behavioral',
          question: 'Tell me about a time you disagreed with a teammate.',
        },
      });
      expect(result).toHaveLength(2);
    });

    it('asks for the default count of 5 when count is not provided', async () => {
      aiProviderMock.complete.mockResolvedValue(
        JSON.stringify([{ question: 'Q1', category: 'other' }]),
      );
      prismaMock.questionBankItem.create.mockResolvedValue({ id: 'q-1' });

      await service.generate({ role: 'Backend Engineer' });

      const systemPrompt = aiProviderMock.complete.mock.calls[0][0].system;
      expect(systemPrompt).toContain('exactly 5');
    });

    it('respects a custom count', async () => {
      aiProviderMock.complete.mockResolvedValue(
        JSON.stringify([{ question: 'Q1', category: 'other' }]),
      );
      prismaMock.questionBankItem.create.mockResolvedValue({ id: 'q-1' });

      await service.generate({ role: 'Backend Engineer', count: 3 });

      const systemPrompt = aiProviderMock.complete.mock.calls[0][0].system;
      expect(systemPrompt).toContain('exactly 3');
    });

    it('throws BadGatewayException when the AI response cannot be parsed, and saves nothing', async () => {
      aiProviderMock.complete.mockResolvedValue('Sorry, I cannot help with that.');

      await expect(service.generate({ role: 'Backend Engineer' })).rejects.toBeInstanceOf(
        BadGatewayException,
      );
      expect(prismaMock.questionBankItem.create).not.toHaveBeenCalled();
    });
  });

  describe('list', () => {
    it('builds case-insensitive contains filters only for provided fields', async () => {
      prismaMock.questionBankItem.findMany.mockResolvedValue([]);

      await service.list({ role: 'Backend', limit: 10 });

      expect(prismaMock.questionBankItem.findMany).toHaveBeenCalledWith({
        where: { role: { contains: 'Backend', mode: 'insensitive' } },
        orderBy: { createdAt: 'desc' },
        take: 10,
      });
    });

    it('defaults the limit to 30 when not provided', async () => {
      prismaMock.questionBankItem.findMany.mockResolvedValue([]);

      await service.list({});

      expect(prismaMock.questionBankItem.findMany).toHaveBeenCalledWith(
        expect.objectContaining({ take: 30 }),
      );
    });

    it('filters by category with an exact match, not contains', async () => {
      prismaMock.questionBankItem.findMany.mockResolvedValue([]);

      await service.list({ category: 'behavioral' });

      expect(prismaMock.questionBankItem.findMany).toHaveBeenCalledWith(
        expect.objectContaining({ where: { category: 'behavioral' } }),
      );
    });
  });

  describe('filters', () => {
    it('returns sorted distinct roles/companies/topics, excluding nulls', async () => {
      prismaMock.questionBankItem.findMany
        .mockResolvedValueOnce([{ role: 'Frontend Engineer' }, { role: 'Backend Engineer' }])
        .mockResolvedValueOnce([{ company: 'Acme' }])
        .mockResolvedValueOnce([{ topic: 'System Design' }]);

      const result = await service.filters();

      expect(result).toEqual({
        roles: ['Backend Engineer', 'Frontend Engineer'],
        companies: ['Acme'],
        topics: ['System Design'],
      });
    });
  });
});
