/**
 * All prompt text for question generation lives in this one file — see
 * docs/CHANGE-GUIDE.md.
 */

/**
 * Fixed category set, used both to validate what the AI returns and (as a
 * plain duplicated array, not a shared import — these are separate
 * deployables) to power the category dropdown in apps/web. Keep the two
 * lists in sync by hand if this ever changes; see
 * apps/web/lib/question-categories.ts.
 */
export const QUESTION_CATEGORIES = [
  'behavioral',
  'technical',
  'system-design',
  'culture-fit',
  'other',
] as const;

export type QuestionCategory = (typeof QUESTION_CATEGORIES)[number];

export function buildGenerateQuestionsSystemPrompt(count: number): string {
  return [
    `Generate exactly ${count} realistic interview questions.`,
    'Respond with ONLY a JSON array, no other text, no markdown code fences,',
    'in exactly this shape:',
    `[{"question": "<the question text>", "category": "<one of: ${QUESTION_CATEGORIES.join(', ')}>"}]`,
    'Vary the questions — do not ask near-duplicates of each other.',
    'Each question should be something a real interviewer would actually ask,',
    'not a generic textbook prompt.',
  ].join(' ');
}

export function buildGenerateQuestionsUserPrompt(
  role: string,
  company?: string,
  topic?: string,
  categoryHint?: string,
): string {
  const parts = [`Role: ${role}`];
  if (company) parts.push(`Company: ${company}`);
  if (topic) parts.push(`Topic/focus area: ${topic}`);
  if (categoryHint) parts.push(`Prefer questions in this category where it makes sense: ${categoryHint}`);
  return parts.join('\n');
}

export interface GeneratedQuestion {
  question: string;
  category: QuestionCategory;
}

/**
 * Unlike apps/api/src/ai/feedback-parser.ts, there's no sensible fallback
 * for a malformed question list — a partially-garbled array of questions
 * can't be salvaged the way raw feedback text can just be displayed as-is.
 * Returns null on any problem; the caller turns that into a clear error
 * for the client rather than silently returning nothing.
 */
export function parseGeneratedQuestions(raw: string): GeneratedQuestion[] | null {
  const cleaned = raw.trim().replace(/^```(json)?/i, '').replace(/```$/, '').trim();
  try {
    const parsed = JSON.parse(cleaned);
    if (!Array.isArray(parsed) || parsed.length === 0) return null;

    const questions: GeneratedQuestion[] = [];
    for (const item of parsed) {
      if (typeof item?.question !== 'string' || item.question.trim().length === 0) return null;
      const category = QUESTION_CATEGORIES.includes(item.category) ? item.category : 'other';
      questions.push({ question: item.question.trim(), category });
    }
    return questions;
  } catch {
    return null;
  }
}
