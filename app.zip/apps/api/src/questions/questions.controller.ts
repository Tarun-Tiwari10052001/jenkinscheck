import { Body, Controller, Get, Post, Query, UseGuards } from '@nestjs/common';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { QuestionsService } from './questions.service';
import { GenerateQuestionsDto } from './dto/generate-questions.dto';
import { ListQuestionsDto } from './dto/list-questions.dto';

/**
 * Every route requires login (prevents unauthenticated abuse of the
 * AI-generation endpoint), even though the data itself is shared across
 * all users, not scoped to whoever created it — see docs/DATABASE.md.
 */
@UseGuards(JwtAuthGuard)
@Controller('questions')
export class QuestionsController {
  constructor(private readonly questionsService: QuestionsService) {}

  @Get()
  list(@Query() query: ListQuestionsDto) {
    return this.questionsService.list(query);
  }

  @Get('filters')
  filters() {
    return this.questionsService.filters();
  }

  @Post('generate')
  generate(@Body() dto: GenerateQuestionsDto) {
    return this.questionsService.generate(dto);
  }
}
