import { BadGatewayException, Inject, Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { AI_PROVIDER, AiProvider } from '../ai/providers/ai-provider.interface';
import { GenerateQuestionsDto } from './dto/generate-questions.dto';
import { ListQuestionsDto } from './dto/list-questions.dto';
import {
  buildGenerateQuestionsSystemPrompt,
  buildGenerateQuestionsUserPrompt,
  parseGeneratedQuestions,
} from './question-prompts';

const DEFAULT_GENERATE_COUNT = 5;
const DEFAULT_LIST_LIMIT = 30;

@Injectable()
export class QuestionsService {
  constructor(
    private readonly prisma: PrismaService,
    @Inject(AI_PROVIDER) private readonly ai: AiProvider,
  ) {}

  /**
   * Generates new questions and saves them to the shared bank — this is
   * the only way new rows get into QuestionBankItem right now (no manual
   * curation UI yet). See docs/DATABASE.md for why the bank isn't scoped
   * to a user.
   */
  async generate(dto: GenerateQuestionsDto) {
    const count = dto.count ?? DEFAULT_GENERATE_COUNT;

    const raw = await this.ai.complete({
      system: buildGenerateQuestionsSystemPrompt(count),
      messages: [
        {
          role: 'user',
          content: buildGenerateQuestionsUserPrompt(dto.role, dto.company, dto.topic, dto.category),
        },
      ],
      maxTokens: 200 * count,
    });

    const generated = parseGeneratedQuestions(raw);
    if (!generated) {
      throw new BadGatewayException(
        'Could not generate questions right now — the AI provider returned an unusable response. Please try again.',
      );
    }

    return Promise.all(
      generated.map((g) =>
        this.prisma.questionBankItem.create({
          data: {
            role: dto.role,
            company: dto.company,
            topic: dto.topic,
            category: g.category,
            question: g.question,
          },
        }),
      ),
    );
  }

  list(query: ListQuestionsDto) {
    const where: Record<string, unknown> = {};
    if (query.role) where.role = { contains: query.role, mode: 'insensitive' };
    if (query.company) where.company = { contains: query.company, mode: 'insensitive' };
    if (query.topic) where.topic = { contains: query.topic, mode: 'insensitive' };
    if (query.category) where.category = query.category;

    return this.prisma.questionBankItem.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      take: query.limit ?? DEFAULT_LIST_LIMIT,
    });
  }

  /** Powers the filter dropdowns in the web UI without hardcoding known values. */
  async filters() {
    const [roles, companies, topics] = await Promise.all([
      this.prisma.questionBankItem.findMany({ distinct: ['role'], select: { role: true } }),
      this.prisma.questionBankItem.findMany({
        distinct: ['company'],
        select: { company: true },
        where: { company: { not: null } },
      }),
      this.prisma.questionBankItem.findMany({
        distinct: ['topic'],
        select: { topic: true },
        where: { topic: { not: null } },
      }),
    ]);

    return {
      roles: roles.map((r: { role: string }) => r.role).sort(),
      companies: companies.map((c: { company: string | null }) => c.company as string).sort(),
      topics: topics.map((t: { topic: string | null }) => t.topic as string).sort(),
    };
  }
}
