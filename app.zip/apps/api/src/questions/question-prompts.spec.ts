import { parseGeneratedQuestions } from './question-prompts';

describe('parseGeneratedQuestions', () => {
  it('parses a clean JSON array', () => {
    const result = parseGeneratedQuestions(
      '[{"question": "Tell me about a conflict with a teammate.", "category": "behavioral"}]',
    );
    expect(result).toEqual([
      { question: 'Tell me about a conflict with a teammate.', category: 'behavioral' },
    ]);
  });

  it('strips markdown code fences before parsing', () => {
    const result = parseGeneratedQuestions(
      '```json\n[{"question": "Explain a system you designed.", "category": "system-design"}]\n```',
    );
    expect(result?.[0].category).toBe('system-design');
  });

  it('falls back to "other" for an unrecognized category', () => {
    const result = parseGeneratedQuestions('[{"question": "What is a hash map?", "category": "made-up"}]');
    expect(result?.[0].category).toBe('other');
  });

  it('returns null for invalid JSON', () => {
    expect(parseGeneratedQuestions('Sorry, I cannot generate questions.')).toBeNull();
  });

  it('returns null for an empty array', () => {
    expect(parseGeneratedQuestions('[]')).toBeNull();
  });

  it('returns null when an item is missing a question field', () => {
    expect(parseGeneratedQuestions('[{"category": "behavioral"}]')).toBeNull();
  });

  it('returns null when an item has an empty question string', () => {
    expect(parseGeneratedQuestions('[{"question": "   ", "category": "behavioral"}]')).toBeNull();
  });

  it('returns null when the response is a JSON object instead of an array', () => {
    expect(parseGeneratedQuestions('{"question": "not an array"}')).toBeNull();
  });
});
