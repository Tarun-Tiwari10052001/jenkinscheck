# API (NestJS)

See `../../docs/CHANGE-GUIDE.md` first.

## Modules in this app

- `src/auth` — register, login, JWT issuing and verification (live)
- `src/users` — user lookups/creation, used by auth (live)
- `src/interviews` — AI conversation engine: start, answer, complete, review (live)
- `src/resumes` — resume feedback, job-description tailoring, cover letter generation (live)
- `src/questions` — shared, AI-generated question bank: generate, browse, filter (live)
- `src/meeting-assistant` — transparent, real-time assistance during the
  user's own work calls (sales, support, internal meetings) — never for
  hiring interviews or exams, enforced in the prompt itself, not just
  docs. See `docs/CHANGE-GUIDE.md`'s Meeting Assistant row before
  touching this module. (live)
- `src/ai` — vendor-agnostic AI provider layer (Anthropic, Google, or any
  OpenAI-compatible API — see "Choosing an AI provider" below), used by
  `interviews`, `resumes`, `questions`, and `meeting-assistant` (live)
- `src/health` — `GET /health` liveness check, used by the e2e smoke test
- `src/prisma` — shared database connection, injected into other modules

## Endpoints (current)

| Method | Path | Auth required | Body |
|---|---|---|---|
| POST | `/auth/register` | no | `{ email, password, name? }` |
| POST | `/auth/login` | no | `{ email, password }` |
| GET | `/auth/me` | yes (Bearer token) | — |
| POST | `/interviews` | yes | `{ role, company? }` — starts a session, returns the opening question |
| GET | `/interviews` | yes | — lists the caller's sessions (summary only) |
| GET | `/interviews/:id` | yes | — full session + transcript |
| POST | `/interviews/:id/answer` | yes | `{ content }` — stores the answer, returns the next question |
| POST | `/interviews/:id/complete` | yes | — ends the session, returns `{ score, strengths, improvements }` as parsed feedback |
| POST | `/resumes` | yes | `{ content }` — pasted resume text (50–20,000 chars), returns the resume with generated feedback |
| GET | `/resumes` | yes | — lists the caller's resumes |
| GET | `/resumes/:id` | yes | — full resume + feedback |
| DELETE | `/resumes/:id` | yes | — 204 on success |
| POST | `/resumes/:id/tailor` | yes | `{ jobDescription }` — returns `{ matchScore, missingKeywords, suggestions }`, not persisted |
| POST | `/resumes/:id/cover-letter` | yes | `{ jobDescription, company?, role? }` — returns `{ content }`, not persisted |
| POST | `/questions/generate` | yes | `{ role, company?, topic?, category?, count? }` (count 1–10, default 5) — generates and saves questions to the shared bank |
| GET | `/questions` | yes | query: `role?, company?, topic?, category?, limit?` — case-insensitive `contains` filtering |
| GET | `/questions/filters` | yes | — distinct `{ roles, companies, topics }` currently in the bank, for building filter UIs |
| POST | `/meeting-assistant/sessions` | yes | `{ title, contextNotes? }` — starts a session |
| GET | `/meeting-assistant/sessions` | yes | — lists the caller's sessions (summary only) |
| GET | `/meeting-assistant/sessions/:id` | yes | — full session + turns |
| DELETE | `/meeting-assistant/sessions/:id` | yes | — 204 on success |
| POST | `/meeting-assistant/sessions/:id/suggest` | yes | `{ transcript }` — what the other person said; returns `{ suggestion }` |
| POST | `/meeting-assistant/sessions/:id/log` | yes | `{ content }` — what the user actually said, for context continuity |
| POST | `/meeting-assistant/sessions/:id/end` | yes | — marks the session ended |
| GET | `/health` | no | — |

Requires an AI provider configured in `.env` for the AI-powered endpoints
to work — see "Choosing an AI provider" below and `.env.example`.

## Choosing an AI provider

Set `AI_PROVIDER` in `.env` to one of:

| `AI_PROVIDER` value | Vendor | Required env vars |
|---|---|---|
| `anthropic` (default) | Claude, via Anthropic | `ANTHROPIC_API_KEY`, optionally `CLAUDE_MODEL` |
| `google` | Gemini, via Google AI Studio | `GOOGLE_API_KEY`, optionally `GEMINI_MODEL` |
| `openai` | OpenAI, or any OpenAI-compatible API (Groq, DeepSeek, Together, OpenRouter, a local Ollama server, etc.) | `OPENAI_API_KEY`, `OPENAI_MODEL` (required, no default), `OPENAI_BASE_URL` (defaults to `https://api.openai.com/v1`) |

Only the section for the vendor you pick needs real values — see
`.env.example`. If the selected vendor's key is missing, the app still
starts; only a request that actually needs the AI provider fails, with a clear error naming
the missing variable.

Adding a new vendor entirely (not just a new OpenAI-compatible endpoint)
means implementing `AiProvider` in `src/ai/providers/` and adding a case
in `ai-provider.factory.ts` — see `docs/CHANGE-GUIDE.md`.

## Commands

```bash
npm run start:dev        # run locally with hot reload
npm run test              # unit tests (src/**/*.spec.ts)
npm run test:e2e          # e2e tests (test/*.e2e-spec.ts)
npm run prisma:migrate    # apply schema changes to the database
```
