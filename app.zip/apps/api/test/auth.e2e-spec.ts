import { Test } from '@nestjs/testing';
import { INestApplication, ValidationPipe } from '@nestjs/common';
import request from 'supertest';
import { AppModule } from '../src/app.module';
import { PrismaService } from '../src/prisma/prisma.service';

/**
 * These tests run against a real (in-memory-mocked) request pipeline —
 * validation pipes, controllers, guards — with only the database layer
 * faked. This is what catches "the route exists but validation is wrong"
 * bugs that pure unit tests miss. Requires no running Postgres.
 */
describe('Auth (e2e)', () => {
  let app: INestApplication;

  const users = new Map<string, any>();
  const prismaMock = {
    onModuleInit: jest.fn(),
    onModuleDestroy: jest.fn(),
    user: {
      findUnique: jest.fn(({ where: { email, id } }: any) =>
        Promise.resolve(
          email ? users.get(email) ?? null : [...users.values()].find((u) => u.id === id) ?? null,
        ),
      ),
      create: jest.fn(({ data }: any) => {
        const user = { id: `user-${users.size + 1}`, ...data };
        users.set(user.email, user);
        return Promise.resolve(user);
      }),
    },
  };

  beforeAll(async () => {
    const moduleRef = await Test.createTestingModule({ imports: [AppModule] })
      .overrideProvider(PrismaService)
      .useValue(prismaMock)
      .compile();

    app = moduleRef.createNestApplication();
    app.useGlobalPipes(new ValidationPipe({ whitelist: true, transform: true }));
    await app.init();
  });

  afterAll(async () => {
    await app.close();
  });

  it('rejects registration with an invalid email', () => {
    return request(app.getHttpServer())
      .post('/auth/register')
      .send({ email: 'not-an-email', password: 'password123' })
      .expect(400);
  });

  it('rejects registration with a short password', () => {
    return request(app.getHttpServer())
      .post('/auth/register')
      .send({ email: 'shortpw@example.com', password: '123' })
      .expect(400);
  });

  it('registers a user and returns a token', async () => {
    const res = await request(app.getHttpServer())
      .post('/auth/register')
      .send({ email: 'e2e@example.com', password: 'password123', name: 'E2E User' })
      .expect(201);

    expect(res.body.accessToken).toBeDefined();
    expect(res.body.user.email).toBe('e2e@example.com');
  });

  it('rejects a duplicate registration', () => {
    return request(app.getHttpServer())
      .post('/auth/register')
      .send({ email: 'e2e@example.com', password: 'password123' })
      .expect(409);
  });

  it('logs in with correct credentials and can access a protected route', async () => {
    const loginRes = await request(app.getHttpServer())
      .post('/auth/login')
      .send({ email: 'e2e@example.com', password: 'password123' })
      .expect(201);

    const token = loginRes.body.accessToken;

    await request(app.getHttpServer())
      .get('/auth/me')
      .set('Authorization', `Bearer ${token}`)
      .expect(200)
      .expect((r: request.Response) => {
        if (r.body.email !== 'e2e@example.com') throw new Error('unexpected user in /auth/me');
      });
  });

  it('rejects the protected route without a token', () => {
    return request(app.getHttpServer()).get('/auth/me').expect(401);
  });

  it('rejects login with the wrong password', () => {
    return request(app.getHttpServer())
      .post('/auth/login')
      .send({ email: 'e2e@example.com', password: 'wrong-password' })
      .expect(401);
  });
});
