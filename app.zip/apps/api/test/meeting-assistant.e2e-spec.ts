import { Test } from '@nestjs/testing';
import { INestApplication, ValidationPipe } from '@nestjs/common';
import request from 'supertest';
import { AppModule } from '../src/app.module';
import { PrismaService } from '../src/prisma/prisma.service';
import { AI_PROVIDER } from '../src/ai/providers/ai-provider.interface';

describe('MeetingAssistant (e2e)', () => {
  let app: INestApplication;
  let authToken: string;
  let otherUserToken: string;

  const users = new Map<string, any>();
  let sessionIdCounter = 0;
  let turnIdCounter = 0;
  const sessions = new Map<string, any>();
  const turnsBySession = new Map<string, any[]>();

  const prismaMock = {
    onModuleInit: jest.fn(),
    onModuleDestroy: jest.fn(),
    user: {
      findUnique: jest.fn(({ where: { email, id } }: any) =>
        Promise.resolve(
          email ? users.get(email) ?? null : [...users.values()].find((u) => u.id === id) ?? null,
        ),
      ),
      create: jest.fn(({ data }: any) => {
        const user = { id: `user-${users.size + 1}`, ...data };
        users.set(user.email, user);
        return Promise.resolve(user);
      }),
    },
    meetingSession: {
      create: jest.fn(({ data }: any) => {
        sessionIdCounter += 1;
        const session = {
          id: `session-${sessionIdCounter}`,
          status: 'ACTIVE',
          endedAt: null,
          createdAt: new Date(),
          ...data,
        };
        sessions.set(session.id, session);
        turnsBySession.set(session.id, []);
        return Promise.resolve(session);
      }),
      findUnique: jest.fn(({ where: { id } }: any) => Promise.resolve(sessions.get(id) ?? null)),
      update: jest.fn(({ where: { id }, data }: any) => {
        const updated = { ...sessions.get(id), ...data };
        sessions.set(id, updated);
        return Promise.resolve(updated);
      }),
      findMany: jest.fn(({ where: { userId } }: any) =>
        Promise.resolve([...sessions.values()].filter((s) => s.userId === userId)),
      ),
      delete: jest.fn(({ where: { id } }: any) => {
        const session = sessions.get(id);
        sessions.delete(id);
        return Promise.resolve(session);
      }),
    },
    meetingTurn: {
      create: jest.fn(({ data }: any) => {
        turnIdCounter += 1;
        const turn = { id: `turn-${turnIdCounter}`, ...data };
        turnsBySession.get(data.sessionId)!.push(turn);
        return Promise.resolve(turn);
      }),
      findMany: jest.fn(({ where: { sessionId } }: any) =>
        Promise.resolve(turnsBySession.get(sessionId) ?? []),
      ),
      findFirst: jest.fn(({ where: { sessionId } }: any) => {
        const turns = turnsBySession.get(sessionId) ?? [];
        return Promise.resolve(turns.length ? turns[turns.length - 1] : null);
      }),
      deleteMany: jest.fn(({ where: { sessionId } }: any) => {
        turnsBySession.set(sessionId, []);
        return Promise.resolve({ count: 0 });
      }),
    },
  };

  const aiProviderMock = { complete: jest.fn() };

  beforeAll(async () => {
    const moduleRef = await Test.createTestingModule({ imports: [AppModule] })
      .overrideProvider(PrismaService)
      .useValue(prismaMock)
      .overrideProvider(AI_PROVIDER)
      .useValue(aiProviderMock)
      .compile();

    app = moduleRef.createNestApplication();
    app.useGlobalPipes(new ValidationPipe({ whitelist: true, transform: true }));
    await app.init();

    const primaryUser = await request(app.getHttpServer())
      .post('/auth/register')
      .send({ email: 'employee@example.com', password: 'password123' });
    authToken = primaryUser.body.accessToken;

    const secondUser = await request(app.getHttpServer())
      .post('/auth/register')
      .send({ email: 'colleague@example.com', password: 'password123' });
    otherUserToken = secondUser.body.accessToken;
  });

  afterAll(async () => {
    await app.close();
  });

  it('rejects every route without a token', async () => {
    await request(app.getHttpServer())
      .post('/meeting-assistant/sessions')
      .send({ title: 'Call' })
      .expect(401);
    await request(app.getHttpServer()).get('/meeting-assistant/sessions').expect(401);
  });

  it('rejects starting a session without a title', () => {
    return request(app.getHttpServer())
      .post('/meeting-assistant/sessions')
      .set('Authorization', `Bearer ${authToken}`)
      .send({})
      .expect(400);
  });

  let sessionId: string;

  it('starts a session', async () => {
    const res = await request(app.getHttpServer())
      .post('/meeting-assistant/sessions')
      .set('Authorization', `Bearer ${authToken}`)
      .send({ title: 'Customer renewal call', contextNotes: 'Discussing pricing' })
      .expect(201);

    expect(res.body.status).toBe('ACTIVE');
    sessionId = res.body.id;
  });

  it('returns a suggestion and stores the transcript turn', async () => {
    aiProviderMock.complete.mockResolvedValueOnce('I can offer a multi-year discount instead.');

    const res = await request(app.getHttpServer())
      .post(`/meeting-assistant/sessions/${sessionId}/suggest`)
      .set('Authorization', `Bearer ${authToken}`)
      .send({ transcript: 'Can you lower the price?' })
      .expect(201);

    expect(res.body).toEqual({ suggestion: 'I can offer a multi-year discount instead.' });
  });

  it('rejects an empty transcript', () => {
    return request(app.getHttpServer())
      .post(`/meeting-assistant/sessions/${sessionId}/suggest`)
      .set('Authorization', `Bearer ${authToken}`)
      .send({ transcript: '' })
      .expect(400);
  });

  it('logs what the user actually said', async () => {
    const res = await request(app.getHttpServer())
      .post(`/meeting-assistant/sessions/${sessionId}/log`)
      .set('Authorization', `Bearer ${authToken}`)
      .send({ content: 'Let me check what I can do on pricing.' })
      .expect(201);

    expect(res.body.speaker).toBe('ME');
  });

  it("rejects another user's attempt to use this session", () => {
    return request(app.getHttpServer())
      .post(`/meeting-assistant/sessions/${sessionId}/suggest`)
      .set('Authorization', `Bearer ${otherUserToken}`)
      .send({ transcript: 'trying to hijack this session' })
      .expect(404);
  });

  it('returns the full session with its turns for the owner', async () => {
    const res = await request(app.getHttpServer())
      .get(`/meeting-assistant/sessions/${sessionId}`)
      .set('Authorization', `Bearer ${authToken}`)
      .expect(200);

    expect(res.body.turns).toHaveLength(2);
  });

  it('ends the session', async () => {
    const res = await request(app.getHttpServer())
      .post(`/meeting-assistant/sessions/${sessionId}/end`)
      .set('Authorization', `Bearer ${authToken}`)
      .expect(201);

    expect(res.body.status).toBe('ENDED');
  });

  it('rejects a suggestion request after the session has ended', () => {
    return request(app.getHttpServer())
      .post(`/meeting-assistant/sessions/${sessionId}/suggest`)
      .set('Authorization', `Bearer ${authToken}`)
      .send({ transcript: 'too late' })
      .expect(400);
  });

  it('lists sessions only for the requesting user', async () => {
    const mine = await request(app.getHttpServer())
      .get('/meeting-assistant/sessions')
      .set('Authorization', `Bearer ${authToken}`)
      .expect(200);
    expect(mine.body).toHaveLength(1);

    const theirs = await request(app.getHttpServer())
      .get('/meeting-assistant/sessions')
      .set('Authorization', `Bearer ${otherUserToken}`)
      .expect(200);
    expect(theirs.body).toEqual([]);
  });

  it('deletes the session for its owner', async () => {
    await request(app.getHttpServer())
      .delete(`/meeting-assistant/sessions/${sessionId}`)
      .set('Authorization', `Bearer ${authToken}`)
      .expect(204);

    await request(app.getHttpServer())
      .get(`/meeting-assistant/sessions/${sessionId}`)
      .set('Authorization', `Bearer ${authToken}`)
      .expect(404);
  });
});
