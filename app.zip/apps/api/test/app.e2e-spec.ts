import { Test } from '@nestjs/testing';
import { INestApplication, ValidationPipe } from '@nestjs/common';
import request from 'supertest';
import { AppModule } from '../src/app.module';
import { PrismaService } from '../src/prisma/prisma.service';

/**
 * Smoke test: confirms the app boots and the health route responds.
 * Does not require a real database connection, unlike auth.e2e-spec.ts.
 *
 * This also intentionally runs with NO AI provider env vars set (no
 * ANTHROPIC_API_KEY, GOOGLE_API_KEY, etc.) — it's the regression test for
 * "the app must boot even when nobody has configured an AI provider yet".
 * See the comment on buildAiProvider in
 * src/ai/providers/ai-provider.factory.ts for why that matters.
 */
describe('Health (e2e)', () => {
  let app: INestApplication;

  beforeAll(async () => {
    const moduleRef = await Test.createTestingModule({ imports: [AppModule] })
      .overrideProvider(PrismaService)
      .useValue({ onModuleInit: jest.fn(), onModuleDestroy: jest.fn() })
      .compile();

    app = moduleRef.createNestApplication();
    app.useGlobalPipes(new ValidationPipe({ whitelist: true, transform: true }));
    await app.init();
  });

  afterAll(async () => {
    await app.close();
  });

  it('GET /health returns ok', () => {
    return request(app.getHttpServer())
      .get('/health')
      .expect(200)
      .expect({ status: 'ok' });
  });
});
