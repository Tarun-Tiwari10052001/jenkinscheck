import { Test } from '@nestjs/testing';
import { INestApplication, ValidationPipe } from '@nestjs/common';
import request from 'supertest';
import { AppModule } from '../src/app.module';
import { PrismaService } from '../src/prisma/prisma.service';
import { AI_PROVIDER } from '../src/ai/providers/ai-provider.interface';

/**
 * Same pattern as test/interviews.e2e-spec.ts — real HTTP through
 * validation/controllers/guards, database and AI provider both faked.
 */
describe('Resumes (e2e)', () => {
  let app: INestApplication;
  let authToken: string;
  let otherUserToken: string;

  const users = new Map<string, any>();
  let resumeIdCounter = 0;
  const resumes = new Map<string, any>();

  const prismaMock = {
    onModuleInit: jest.fn(),
    onModuleDestroy: jest.fn(),
    user: {
      findUnique: jest.fn(({ where: { email, id } }: any) =>
        Promise.resolve(
          email ? users.get(email) ?? null : [...users.values()].find((u) => u.id === id) ?? null,
        ),
      ),
      create: jest.fn(({ data }: any) => {
        const user = { id: `user-${users.size + 1}`, ...data };
        users.set(user.email, user);
        return Promise.resolve(user);
      }),
    },
    resume: {
      create: jest.fn(({ data }: any) => {
        resumeIdCounter += 1;
        const resume = { id: `resume-${resumeIdCounter}`, createdAt: new Date(), updatedAt: new Date(), ...data };
        resumes.set(resume.id, resume);
        return Promise.resolve(resume);
      }),
      findUnique: jest.fn(({ where: { id } }: any) => Promise.resolve(resumes.get(id) ?? null)),
      findMany: jest.fn(({ where: { userId } }: any) =>
        Promise.resolve([...resumes.values()].filter((r) => r.userId === userId)),
      ),
      delete: jest.fn(({ where: { id } }: any) => {
        const resume = resumes.get(id);
        resumes.delete(id);
        return Promise.resolve(resume);
      }),
    },
  };

  const aiProviderMock = { complete: jest.fn() };

  beforeAll(async () => {
    const moduleRef = await Test.createTestingModule({ imports: [AppModule] })
      .overrideProvider(PrismaService)
      .useValue(prismaMock)
      .overrideProvider(AI_PROVIDER)
      .useValue(aiProviderMock)
      .compile();

    app = moduleRef.createNestApplication();
    app.useGlobalPipes(new ValidationPipe({ whitelist: true, transform: true }));
    await app.init();

    const primaryUser = await request(app.getHttpServer())
      .post('/auth/register')
      .send({ email: 'candidate2@example.com', password: 'password123' });
    authToken = primaryUser.body.accessToken;

    const secondUser = await request(app.getHttpServer())
      .post('/auth/register')
      .send({ email: 'other2@example.com', password: 'password123' });
    otherUserToken = secondUser.body.accessToken;
  });

  afterAll(async () => {
    await app.close();
  });

  const longResumeText = 'Experienced backend engineer. '.repeat(5);
  const longJobDescription = 'We are hiring a backend engineer with Kubernetes experience. '.repeat(3);

  it('rejects every resume route without a token', async () => {
    await request(app.getHttpServer()).post('/resumes').send({ content: longResumeText }).expect(401);
    await request(app.getHttpServer()).get('/resumes').expect(401);
  });

  it('rejects a resume shorter than 50 characters', () => {
    return request(app.getHttpServer())
      .post('/resumes')
      .set('Authorization', `Bearer ${authToken}`)
      .send({ content: 'too short' })
      .expect(400);
  });

  let resumeId: string;

  it('creates a resume and returns generated feedback', async () => {
    aiProviderMock.complete.mockResolvedValueOnce(
      '{"score": 78, "strengths": ["Strong quantified results"], "improvements": ["Add a summary section"]}',
    );

    const res = await request(app.getHttpServer())
      .post('/resumes')
      .set('Authorization', `Bearer ${authToken}`)
      .send({ content: longResumeText })
      .expect(201);

    expect(JSON.parse(res.body.latestFeedback).score).toBe(78);
    resumeId = res.body.id;
  });

  it('lists resumes for the requesting user only', async () => {
    const mine = await request(app.getHttpServer())
      .get('/resumes')
      .set('Authorization', `Bearer ${authToken}`)
      .expect(200);
    expect(mine.body).toHaveLength(1);

    const theirs = await request(app.getHttpServer())
      .get('/resumes')
      .set('Authorization', `Bearer ${otherUserToken}`)
      .expect(200);
    expect(theirs.body).toEqual([]);
  });

  it("rejects another user's attempt to read this resume", () => {
    return request(app.getHttpServer())
      .get(`/resumes/${resumeId}`)
      .set('Authorization', `Bearer ${otherUserToken}`)
      .expect(404);
  });

  it('returns a tailoring match result without persisting anything new', async () => {
    aiProviderMock.complete.mockResolvedValueOnce(
      '{"matchScore": 61, "missingKeywords": ["Kubernetes"], "suggestions": ["Mention container orchestration"]}',
    );

    const res = await request(app.getHttpServer())
      .post(`/resumes/${resumeId}/tailor`)
      .set('Authorization', `Bearer ${authToken}`)
      .send({ jobDescription: longJobDescription })
      .expect(201);

    expect(res.body).toEqual({
      matchScore: 61,
      missingKeywords: ['Kubernetes'],
      suggestions: ['Mention container orchestration'],
    });

    const list = await request(app.getHttpServer())
      .get('/resumes')
      .set('Authorization', `Bearer ${authToken}`)
      .expect(200);
    expect(list.body).toHaveLength(1);
  });

  it('rejects tailoring with a job description shorter than 50 characters', () => {
    return request(app.getHttpServer())
      .post(`/resumes/${resumeId}/tailor`)
      .set('Authorization', `Bearer ${authToken}`)
      .send({ jobDescription: 'too short' })
      .expect(400);
  });

  it('generates a cover letter', async () => {
    aiProviderMock.complete.mockResolvedValueOnce('Dear Hiring Manager, I am excited to apply...');

    const res = await request(app.getHttpServer())
      .post(`/resumes/${resumeId}/cover-letter`)
      .set('Authorization', `Bearer ${authToken}`)
      .send({ jobDescription: longJobDescription, company: 'Acme', role: 'Backend Engineer' })
      .expect(201);

    expect(res.body.content).toContain('Dear Hiring Manager');
  });

  it("rejects another user's attempt to delete this resume", () => {
    return request(app.getHttpServer())
      .delete(`/resumes/${resumeId}`)
      .set('Authorization', `Bearer ${otherUserToken}`)
      .expect(404);
  });

  it('deletes the resume for its owner', async () => {
    await request(app.getHttpServer())
      .delete(`/resumes/${resumeId}`)
      .set('Authorization', `Bearer ${authToken}`)
      .expect(204);

    await request(app.getHttpServer())
      .get(`/resumes/${resumeId}`)
      .set('Authorization', `Bearer ${authToken}`)
      .expect(404);
  });
});
