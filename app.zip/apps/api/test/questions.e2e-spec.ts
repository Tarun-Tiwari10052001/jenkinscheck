import { Test } from '@nestjs/testing';
import { INestApplication, ValidationPipe } from '@nestjs/common';
import request from 'supertest';
import { AppModule } from '../src/app.module';
import { PrismaService } from '../src/prisma/prisma.service';
import { AI_PROVIDER } from '../src/ai/providers/ai-provider.interface';

describe('Questions (e2e)', () => {
  let app: INestApplication;
  let authToken: string;

  const users = new Map<string, any>();
  let questionIdCounter = 0;
  const questions: any[] = [];

  const prismaMock = {
    onModuleInit: jest.fn(),
    onModuleDestroy: jest.fn(),
    user: {
      findUnique: jest.fn(({ where: { email, id } }: any) =>
        Promise.resolve(
          email ? users.get(email) ?? null : [...users.values()].find((u) => u.id === id) ?? null,
        ),
      ),
      create: jest.fn(({ data }: any) => {
        const user = { id: `user-${users.size + 1}`, ...data };
        users.set(user.email, user);
        return Promise.resolve(user);
      }),
    },
    questionBankItem: {
      create: jest.fn(({ data }: any) => {
        questionIdCounter += 1;
        const item = { id: `q-${questionIdCounter}`, createdAt: new Date(), ...data };
        questions.push(item);
        return Promise.resolve(item);
      }),
      findMany: jest.fn((args: any = {}) => {
        let results = [...questions];
        const where = args.where ?? {};

        if (where.role?.contains) {
          const needle = where.role.contains.toLowerCase();
          results = results.filter((q) => q.role.toLowerCase().includes(needle));
        }
        if (where.category) {
          results = results.filter((q) => q.category === where.category);
        }
        if (args.distinct?.includes('role')) {
          const seen = new Set<string>();
          results = results.filter((q) => (seen.has(q.role) ? false : (seen.add(q.role), true)));
        }
        if (args.distinct?.includes('company')) {
          const seen = new Set<string | null>();
          results = results.filter((q) => (seen.has(q.company) ? false : (seen.add(q.company), true)));
        }
        if (args.distinct?.includes('topic')) {
          const seen = new Set<string | null>();
          results = results.filter((q) => (seen.has(q.topic) ? false : (seen.add(q.topic), true)));
        }
        if (args.take) results = results.slice(0, args.take);
        return Promise.resolve(results);
      }),
    },
  };

  const aiProviderMock = { complete: jest.fn() };

  beforeAll(async () => {
    const moduleRef = await Test.createTestingModule({ imports: [AppModule] })
      .overrideProvider(PrismaService)
      .useValue(prismaMock)
      .overrideProvider(AI_PROVIDER)
      .useValue(aiProviderMock)
      .compile();

    app = moduleRef.createNestApplication();
    app.useGlobalPipes(new ValidationPipe({ whitelist: true, transform: true }));
    await app.init();

    const user = await request(app.getHttpServer())
      .post('/auth/register')
      .send({ email: 'jobseeker@example.com', password: 'password123' });
    authToken = user.body.accessToken;
  });

  afterAll(async () => {
    await app.close();
  });

  it('rejects every question route without a token', async () => {
    await request(app.getHttpServer()).get('/questions').expect(401);
    await request(app.getHttpServer())
      .post('/questions/generate')
      .send({ role: 'Backend Engineer' })
      .expect(401);
  });

  it('rejects generation without a role', () => {
    return request(app.getHttpServer())
      .post('/questions/generate')
      .set('Authorization', `Bearer ${authToken}`)
      .send({})
      .expect(400);
  });

  it('rejects a count above 10', () => {
    return request(app.getHttpServer())
      .post('/questions/generate')
      .set('Authorization', `Bearer ${authToken}`)
      .send({ role: 'Backend Engineer', count: 20 })
      .expect(400);
  });

  it('generates questions and saves them to the bank', async () => {
    aiProviderMock.complete.mockResolvedValueOnce(
      JSON.stringify([
        { question: 'Tell me about a challenging deploy.', category: 'behavioral' },
        { question: 'Design a URL shortener.', category: 'system-design' },
      ]),
    );

    const res = await request(app.getHttpServer())
      .post('/questions/generate')
      .set('Authorization', `Bearer ${authToken}`)
      .send({ role: 'Backend Engineer', company: 'Acme' })
      .expect(201);

    expect(res.body).toHaveLength(2);
    expect(res.body[0].role).toBe('Backend Engineer');
  });

  it('returns a clear error when the AI response cannot be parsed', async () => {
    aiProviderMock.complete.mockResolvedValueOnce('not valid json at all');

    return request(app.getHttpServer())
      .post('/questions/generate')
      .set('Authorization', `Bearer ${authToken}`)
      .send({ role: 'Frontend Engineer' })
      .expect(502);
  });

  it('lists questions, filterable by role', async () => {
    const all = await request(app.getHttpServer())
      .get('/questions')
      .set('Authorization', `Bearer ${authToken}`)
      .expect(200);
    expect(all.body.length).toBeGreaterThanOrEqual(2);

    const filtered = await request(app.getHttpServer())
      .get('/questions?role=Backend')
      .set('Authorization', `Bearer ${authToken}`)
      .expect(200);
    expect(filtered.body.every((q: any) => q.role.includes('Backend'))).toBe(true);
  });

  it('returns distinct filter values', async () => {
    const res = await request(app.getHttpServer())
      .get('/questions/filters')
      .set('Authorization', `Bearer ${authToken}`)
      .expect(200);

    expect(res.body.roles).toContain('Backend Engineer');
  });
});
