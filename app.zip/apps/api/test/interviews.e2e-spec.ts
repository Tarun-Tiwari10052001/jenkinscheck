import { Test } from '@nestjs/testing';
import { INestApplication, ValidationPipe } from '@nestjs/common';
import request from 'supertest';
import { AppModule } from '../src/app.module';
import { PrismaService } from '../src/prisma/prisma.service';
import { AI_PROVIDER } from '../src/ai/providers/ai-provider.interface';

/**
 * Exercises the full interview flow over real HTTP — auth, validation,
 * ownership checks, and the request/response shape — with the database
 * and the AI provider both faked. See docs/TESTING.md for why e2e tests fake the
 * database while unit tests fake the service layer.
 */
describe('Interviews (e2e)', () => {
  let app: INestApplication;
  let authToken: string;
  let otherUserToken: string;

  const users = new Map<string, any>();
  let sessionIdCounter = 0;
  let messageIdCounter = 0;
  const sessions = new Map<string, any>();
  const messagesBySession = new Map<string, any[]>();

  const prismaMock = {
    onModuleInit: jest.fn(),
    onModuleDestroy: jest.fn(),
    user: {
      findUnique: jest.fn(({ where: { email, id } }: any) =>
        Promise.resolve(
          email ? users.get(email) ?? null : [...users.values()].find((u) => u.id === id) ?? null,
        ),
      ),
      create: jest.fn(({ data }: any) => {
        const user = { id: `user-${users.size + 1}`, ...data };
        users.set(user.email, user);
        return Promise.resolve(user);
      }),
    },
    interviewSession: {
      create: jest.fn(({ data }: any) => {
        sessionIdCounter += 1;
        const session = {
          id: `session-${sessionIdCounter}`,
          status: 'IN_PROGRESS',
          score: null,
          feedback: null,
          completedAt: null,
          createdAt: new Date(),
          ...data,
        };
        sessions.set(session.id, session);
        messagesBySession.set(session.id, []);
        return Promise.resolve(session);
      }),
      findUnique: jest.fn(({ where: { id } }: any) => Promise.resolve(sessions.get(id) ?? null)),
      update: jest.fn(({ where: { id }, data }: any) => {
        const updated = { ...sessions.get(id), ...data };
        sessions.set(id, updated);
        return Promise.resolve(updated);
      }),
      findMany: jest.fn(({ where: { userId } }: any) =>
        Promise.resolve([...sessions.values()].filter((s) => s.userId === userId)),
      ),
    },
    interviewMessage: {
      create: jest.fn(({ data }: any) => {
        messageIdCounter += 1;
        const message = { id: `message-${messageIdCounter}`, ...data };
        messagesBySession.get(data.sessionId)!.push(message);
        return Promise.resolve(message);
      }),
      findMany: jest.fn(({ where: { sessionId } }: any) =>
        Promise.resolve(messagesBySession.get(sessionId) ?? []),
      ),
    },
  };

  const aiProviderMock = {
    complete: jest.fn().mockResolvedValue('What is your greatest strength?'),
  };

  beforeAll(async () => {
    const moduleRef = await Test.createTestingModule({ imports: [AppModule] })
      .overrideProvider(PrismaService)
      .useValue(prismaMock)
      .overrideProvider(AI_PROVIDER)
      .useValue(aiProviderMock)
      .compile();

    app = moduleRef.createNestApplication();
    app.useGlobalPipes(new ValidationPipe({ whitelist: true, transform: true }));
    await app.init();

    const primaryUser = await request(app.getHttpServer())
      .post('/auth/register')
      .send({ email: 'candidate@example.com', password: 'password123' });
    authToken = primaryUser.body.accessToken;

    const secondUser = await request(app.getHttpServer())
      .post('/auth/register')
      .send({ email: 'other@example.com', password: 'password123' });
    otherUserToken = secondUser.body.accessToken;
  });

  afterAll(async () => {
    await app.close();
  });

  it('rejects every interview route without a token', async () => {
    await request(app.getHttpServer()).post('/interviews').send({ role: 'Engineer' }).expect(401);
    await request(app.getHttpServer()).get('/interviews').expect(401);
  });

  it('rejects starting an interview without a role', () => {
    return request(app.getHttpServer())
      .post('/interviews')
      .set('Authorization', `Bearer ${authToken}`)
      .send({})
      .expect(400);
  });

  let sessionId: string;

  it('starts an interview and returns the opening question', async () => {
    aiProviderMock.complete.mockResolvedValueOnce('Tell me about a challenging project.');

    const res = await request(app.getHttpServer())
      .post('/interviews')
      .set('Authorization', `Bearer ${authToken}`)
      .send({ role: 'Backend Engineer', company: 'Acme' })
      .expect(201);

    expect(res.body.question).toBe('Tell me about a challenging project.');
    expect(res.body.session.status).toBe('IN_PROGRESS');
    sessionId = res.body.session.id;
  });

  it('accepts an answer and returns the next question', async () => {
    aiProviderMock.complete.mockResolvedValueOnce('What would you do differently next time?');

    const res = await request(app.getHttpServer())
      .post(`/interviews/${sessionId}/answer`)
      .set('Authorization', `Bearer ${authToken}`)
      .send({ content: 'I led a migration that reduced latency by 40%.' })
      .expect(201);

    expect(res.body.question).toBe('What would you do differently next time?');
    expect(res.body.questionCount).toBe(2);
  });

  it('rejects an empty answer', () => {
    return request(app.getHttpServer())
      .post(`/interviews/${sessionId}/answer`)
      .set('Authorization', `Bearer ${authToken}`)
      .send({ content: '' })
      .expect(400);
  });

  it("rejects another user's attempt to answer this session", () => {
    return request(app.getHttpServer())
      .post(`/interviews/${sessionId}/answer`)
      .set('Authorization', `Bearer ${otherUserToken}`)
      .send({ content: 'trying to hijack this session' })
      .expect(404);
  });

  it('returns the full transcript for the owner', async () => {
    const res = await request(app.getHttpServer())
      .get(`/interviews/${sessionId}`)
      .set('Authorization', `Bearer ${authToken}`)
      .expect(200);

    expect(res.body.messages).toHaveLength(3);
  });

  it('completes the interview and returns parsed feedback', async () => {
    aiProviderMock.complete.mockResolvedValueOnce(
      '{"score": 88, "strengths": ["Specific examples"], "improvements": ["Quantify more"]}',
    );

    const res = await request(app.getHttpServer())
      .post(`/interviews/${sessionId}/complete`)
      .set('Authorization', `Bearer ${authToken}`)
      .expect(201);

    expect(res.body.status).toBe('COMPLETED');
    expect(res.body.score).toBe(88);
  });

  it('rejects answering an already-completed interview', () => {
    return request(app.getHttpServer())
      .post(`/interviews/${sessionId}/answer`)
      .set('Authorization', `Bearer ${authToken}`)
      .send({ content: 'too late' })
      .expect(400);
  });

  it('lists sessions only for the requesting user', async () => {
    const res = await request(app.getHttpServer())
      .get('/interviews')
      .set('Authorization', `Bearer ${otherUserToken}`)
      .expect(200);

    expect(res.body).toEqual([]);
  });

  it('returns 404 for a session that does not exist', () => {
    return request(app.getHttpServer())
      .get('/interviews/does-not-exist')
      .set('Authorization', `Bearer ${authToken}`)
      .expect(404);
  });
});
