# Architecture

## Layers

```
Clients        apps/web (Next.js)        apps/desktop (Electron, wraps apps/web — live, Phase 4)
                        |
Gateway         apps/api NestJS app entrypoint (main.ts) — auth guard, global
                validation, CORS, rate limiting live here
                        |
Core services   apps/api/src/auth        account creation, login, JWT
                apps/api/src/users       profile, plan/subscription state
                apps/api/src/interviews  mock-interview engine — live (Phase 1)
                apps/api/src/resumes     resume feedback, tailoring, cover letters — live (Phase 2)
                apps/api/src/questions   shared question bank, AI-generated — live (Phase 3)
                apps/api/src/meeting-assistant  transparent real-time call assistance — live
                apps/api/src/ai          AI provider abstraction — live, vendor-agnostic
                        |
Data & AI       Postgres (via Prisma)    apps/api/prisma/schema.prisma
                AI provider (any of)     Anthropic, Google Gemini, or any OpenAI-compatible
                                         API — selected by the AI_PROVIDER env var, called
                                         from apps/api/src/ai/providers/**
                Speech APIs (STT/TTS)    will be called from interviews (voice mode) + copilot
                Object storage (S3/R2)   will store resumes, recordings
```

This matches the four-layer diagram from planning: interface layer, gateway,
application services, data/AI layer. Each service in the core-services layer
is an independent NestJS module — it can be built, tested, and reasoned
about without touching the others. That independence is enforced by the
rule in `docs/CHANGE-GUIDE.md`: a module only imports another module's
public service interface, never its internals.

## Why NestJS modules instead of microservices (for now)

All core services currently run inside one NestJS process (`apps/api`),
organized as separate modules. This keeps local development and deployment
simple while the product is still finding its shape. Because each module
already has a clean boundary (its own folder, its own service class, its
own tests), splitting a module out into its own deployed service later is a
matter of infrastructure, not a rewrite.

## Why the AI layer is vendor-agnostic

`InterviewsService` — and every future feature that calls an LLM — depends
only on the `AiProvider` interface (`complete({ system, messages, maxTokens })
=> Promise<string>`), injected via the `AI_PROVIDER` token. It never imports
an Anthropic, Google, or OpenAI SDK directly.

Three implementations exist today, selected by the `AI_PROVIDER` env var:

- `AnthropicProvider` — Claude, via the official Anthropic SDK
- `GoogleProvider` — Gemini, via Google AI Studio (the `@google/genai` SDK)
- `OpenAiCompatibleProvider` — a generic REST client for OpenAI itself, or
  any service that mirrors OpenAI's `/chat/completions` shape (Groq,
  DeepSeek, Together, OpenRouter, a local Ollama server, etc.), via
  `OPENAI_BASE_URL`

Switching vendors is a config change (`AI_PROVIDER` + that vendor's API
key in `.env`), not a code change. If a required key is missing, the app
still boots — the error only surfaces when a feature actually tries to
call the AI provider, so working on auth, the dashboard, or anything
unrelated never requires an AI key to be configured. See the comment on
`buildAiProvider` in `apps/api/src/ai/providers/ai-provider.factory.ts`
for why that matters, and `apps/api/test/app.e2e-spec.ts` for the
regression test that guards it.

## Request flow example: logging in

1. `apps/web/app/login/page.tsx` submits the login form
2. `apps/web/lib/api-client.ts` sends `POST /auth/login` to the API
3. `apps/api/src/auth/auth.controller.ts` receives it, calls `AuthService`
4. `AuthService` checks the password hash via `UsersService`, then issues a
   JWT
5. The web app stores the token and redirects to `/dashboard`

Every future feature follows this same shape: a page/component in `web`,
a thin controller in `api`, and the real logic in a service class that's
unit tested on its own.

## Request flow example: a mock interview turn

"Client" below is `apps/web/components/interview-chat.tsx` and
`start-interview-form.tsx` in practice — this is the actual flow those
components drive.

1. Client calls `POST /interviews` with `{ role, company? }`
2. `InterviewsController.start` calls `InterviewsService.startSession`
3. The service creates an `InterviewSession` row, then calls
   the injected AI provider's `.complete()` with a system prompt built in
   `interview-prompts.ts` to get the opening question, and stores it as
   an `InterviewMessage`
4. Client calls `POST /interviews/:id/answer` with `{ content }` for each
   turn; the service stores the candidate's answer, replays the whole
   transcript to the AI provider so follow-ups stay contextual, and stores the
   next question
5. Client calls `POST /interviews/:id/complete`; the service sends the
   full transcript to the AI provider with a prompt asking for JSON-only scored
   feedback, parses it (falling back to storing raw text if parsing
   fails), and marks the session `COMPLETED`

All prompt text lives in one file (`interview-prompts.ts`) precisely so
that improving interview quality later doesn't require touching
`InterviewsService`, `InterviewsController`, or their tests.

## Request flow example: resume feedback and tailoring

"Client" below is `apps/web/components/resume-upload-form.tsx` and
`resume-detail.tsx`.

1. Client calls `POST /resumes` with `{ content }` (pasted resume text)
2. `ResumesService.create` sends it to the AI provider with a feedback
   prompt from `resume-prompts.ts`, parses the JSON response with the
   shared `parseFeedback` from `apps/api/src/ai/feedback-parser.ts`
   (the same parser the interview engine uses — same response shape),
   and stores the resume with its feedback in one row
3. Client calls `POST /resumes/:id/tailor` with `{ jobDescription }`;
   the service loads the resume, sends both to the AI provider with a
   different prompt asking for a match score and missing keywords, and
   returns the result directly — nothing is written to the database
4. Client calls `POST /resumes/:id/cover-letter` similarly; the AI
   provider returns letter text, which is also returned directly, not
   persisted

See `docs/DATABASE.md` for why tailoring and cover letter results
specifically aren't stored.

## Why voice mode uses the browser's Web Speech API

Interview practice can run with voice: questions are read aloud, and an
answer can be dictated instead of typed. This is built entirely on the
browser's native Web Speech API (`SpeechRecognition` for dictation,
`speechSynthesis` for reading questions aloud) — see
`apps/web/lib/speech.ts` — not a paid third-party vendor like Deepgram
or ElevenLabs, which the original Phase 1 plan mentioned as an option.

That trade-off, spelled out rather than left implicit:

- No API key, no new backend endpoint, no per-minute usage cost. Speech
  never leaves the browser or touches `apps/api` at all — a dictated
  answer becomes plain text that goes through the exact same
  `POST /interviews/:id/answer` call typing does. The backend has no
  idea whether an answer was typed or spoken, and needed zero changes to
  support this.
- Text-to-speech (`speechSynthesis`) is broadly supported. Speech-to-text
  (`SpeechRecognition`) is not — it works well in Chrome and Edge, and is
  unsupported or limited in Firefox and Safari as of this writing.
  `apps/web/lib/speech.ts` exports `isSpeechRecognitionSupported()` /
  `isSpeechSynthesisSupported()` specifically so the UI can offer only
  what actually works in the visitor's browser — see how
  `interview-chat.tsx` gates the voice-mode toggle and mic button on
  these, rather than showing controls that would silently fail.
- If browser support gaps become a real problem, swapping in a vendor
  API is a contained change: replace the implementation inside
  `speech.ts` (which would then need a backend endpoint, since a vendor
  API key can't live in the browser) — nothing in `interview-chat.tsx`
  would need to change, since it only calls `speak()` /
  `createSpeechRecognition()`, never a vendor SDK directly. Same pattern
  as swapping AI providers behind `AiProvider` — see the AI provider
  section above.



"Client" below is `apps/web/components/question-bank.tsx`.

1. Client calls `POST /questions/generate` with `{ role, company?, topic?,
   category?, count? }`
2. `QuestionsService.generate` sends a prompt from `question-prompts.ts`
   asking for exactly `count` questions as a JSON array; each generated
   question is saved as its own `QuestionBankItem` row — this data is
   shared across all users, not scoped to whoever generated it (see
   `docs/DATABASE.md`)
3. Client calls `GET /questions?role=...&company=...` to browse/filter
   the shared bank with simple case-insensitive `contains` matching — no
   vector/semantic search yet (also explained in `docs/DATABASE.md`)
4. Client calls `GET /questions/filters` to populate the role/company/topic
   dropdowns from what's actually in the bank, rather than a hardcoded list

## Meeting Assistant: what it is, and the boundary it's built around

"Client" below is `apps/web/components/meeting-assistant.tsx`.

1. Client calls `POST /meeting-assistant/sessions` with `{ title,
   contextNotes? }` to start a session for the user's own work call
2. As the call happens, the client sends what the other person said —
   captured by the user's own mic via `apps/web/lib/speech.ts` (the same
   Web Speech API wrapper voice mode uses), or typed as a fallback — to
   `POST /meeting-assistant/sessions/:id/suggest`
3. `MeetingAssistantService.suggest` stores that as a `MeetingTurn`,
   sends it plus recent conversation history and the session's context
   notes to the AI provider, and returns a suggested response as plain
   text — displayed on the user's own screen, never auto-sent or
   auto-spoken anywhere
4. The client can optionally log what the user actually said via
   `POST /meeting-assistant/sessions/:id/log`, so later suggestions in
   the same call stay consistent with what's already been said

This module exists because an earlier, differently-scoped version of
"real-time call assistance" was explicitly declined during this
project's development: one engineered to stay hidden from screen
sharing, so a hiring interviewer couldn't tell a candidate's answers
were AI-generated. That mechanism — hiding the tool's use from whoever
you're talking to — is what made that version a decline, not the
underlying idea of real-time assistance during a call. This module is a
genuinely different design, not the same thing renamed:

- The scope boundary is enforced in the AI's system prompt itself
  (`buildSuggestSystemPrompt()` in `meeting-prompts.ts`), not just in
  the UI or documentation — if a transcript sounds like it's from a
  hiring interview, exam, or certification instead of the user's own
  work call, the model is instructed to say so and decline to give a
  scripted answer, since doing so would help misrepresent the user's own
  ability to whoever is assessing them.
- The "active" indicator in the UI is persistent and visible — see
  `meeting-assistant.tsx` — with no code path that hides it, excludes it
  from screen capture, or otherwise makes the assistant's use
  undetectable to other call participants. `apps/web/components/start-meeting-form.tsx`
  shows a consent/visibility reminder before a session even starts.
- See `docs/DATABASE.md`'s Meeting Assistant section for why the data
  model itself was kept separate from `InterviewSession` rather than
  reusing/rebranding it.

## Why the desktop app wraps the web app instead of being rebuilt

`apps/desktop` doesn't reimplement any UI — it's a thin Electron shell
that loads `apps/web` in a native window, unchanged. This was the
explicit Phase 4 scope: "wrap the same web experience," not "build a
second frontend." Two consequences worth knowing:

- Every feature (interviews, resumes, questions) works in the desktop
  app automatically, since it's the same web app rendering. Adding a
  feature to `apps/web` never requires a corresponding change in
  `apps/desktop`.
- The desktop app doesn't bundle `apps/api`. It expects the backend to
  be reachable the same way the browser version does — locally in dev,
  or a deployed backend in production, configured via
  `NEXT_PUBLIC_API_URL` at web-build time. See `apps/desktop/README.md`.

In dev, the shell loads the already-running `next dev` server directly.
In a packaged build, `apps/web`'s `next.config.js` uses
`output: 'standalone'` (a minimal, self-contained Next.js server, no
`next` CLI or full `node_modules` needed at runtime) — the Electron main
process spawns that as a child process, waits for it to respond, then
loads it. Both paths funnel through the same `resolveAppUrl()` /
`waitForServer()` logic, which is unit tested; see
`apps/desktop/README.md`'s "How this was actually verified" for the
distinction between what has real automated coverage and what still
needs a real display/machine.
