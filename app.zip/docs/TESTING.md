# Testing conventions

**Rule for this project: no module ships without tests in the same change.**
That applies to every phase going forward, not just Phase 0.

## Where tests live

| Type | Location | Runs against | Example |
|---|---|---|---|
| Backend unit tests | `apps/api/src/**/*.spec.ts`, next to the file they test | Nothing external — dependencies are mocked | `auth.service.spec.ts` tests password hashing and JWT issuing without a real database; `feedback-parser.spec.ts` tests the shared JSON-parsing utility with no dependencies at all |
| Backend e2e tests | `apps/api/test/*.e2e-spec.ts` | A real running instance of the API | `app.e2e-spec.ts` hits `/health` over HTTP |
| Frontend component tests | `apps/web/__tests__/*.test.tsx` | Rendered components, no real API calls (API is mocked) | `login-form.test.tsx` checks validation messages and the submit call |

## Why unit tests mock the database

Unit tests should tell you in milliseconds whether your logic is correct,
without needing Postgres running. `AuthService`'s tests pass in a fake
`UsersService` so they test "does login reject a wrong password", not
"is Postgres reachable". The e2e tests are what actually exercise the
database — they're slower and fewer in number by design.

## Running tests

```bash
npm run test:api      # unit + e2e for the backend
npm run test:web      # component tests for the frontend
npm test              # both
```

## Testing code that calls the AI provider

Never call a real AI API in a test. The `AI_PROVIDER` token is injected
like any other dependency, so unit tests mock it directly (see
`interviews.service.spec.ts`), and e2e tests override the `AI_PROVIDER`
provider with a `jest.fn()` (see `test/interviews.e2e-spec.ts`) the same
way they override `PrismaService`. Each vendor implementation
(`AnthropicProvider`, `GoogleProvider`, `OpenAiCompatibleProvider`) has
its own unit tests that mock that vendor's SDK/HTTP call at the boundary —
see `src/ai/providers/*.spec.ts`. This keeps the suite fast, free, and
deterministic — and means a prompt-wording change, or switching which
vendor is configured, can't accidentally turn into an API bill.

## Testing code that touches browser Web APIs

jsdom (the test environment for `apps/web`) doesn't implement every
browser API — `SpeechRecognition` and `speechSynthesis` (used by
`lib/speech.ts` for voice mode) don't exist in it by default. Two
different test boundaries handle this, matching how the AI provider
layer is tested at two boundaries:

- `__tests__/speech.test.tsx` tests `lib/speech.ts` itself, by directly
  assigning mock implementations onto `window` (e.g.
  `(window as any).SpeechRecognition = jest.fn()...`) before each test,
  then removing them in `afterEach` — this is the "does our wrapper code
  behave correctly against the real browser API shape" boundary.
- `interview-chat.test.tsx` mocks the whole `@/lib/speech` module with
  `jest.mock('@/lib/speech', ...)` and never touches `window` directly —
  this is the "does the component behave correctly given what the speech
  module reports/calls back" boundary, the same pattern used for mocking
  `api-client.ts` in every other component test.

Neither test suite needs a real browser or real microphone access.

## Testing GUI/shell code (the desktop app)

Not everything can be unit tested the same way. `apps/desktop`'s pure
logic — deciding which URL to load, polling until a server is ready —
has full unit test coverage, same as any other module (see
`apps/desktop/src/*.spec.ts`). But `main.ts` and `preload.ts` themselves
(window creation, process spawning) are Electron shell code with no unit
tests, because that kind of code doesn't unit test meaningfully — the
value is in it actually running. `apps/desktop/README.md`'s "How this
was actually verified" section is the record of what was confirmed by
actually launching the app (headless, under Xvfb, with a real dev server)
versus what still needs a real machine with a display. Follow that
pattern for any future GUI code in this repo: factor out everything
testable into plain functions, and be explicit in the module's README
about what the remaining shell code has and hasn't been verified against.

## Adding a new module's tests

1. Write the `.spec.ts` file next to the service, covering: the happy path,
   the main failure path (bad input, not found, unauthorized), and any edge
   case that caused a bug once
2. If the module adds an HTTP endpoint, add or extend an e2e test in
   `apps/api/test/`
3. Add a row for the module in `docs/CHANGE-GUIDE.md` while you're there —
   tests and the change guide are written together, not as an afterthought
