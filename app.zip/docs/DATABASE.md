# Database

Schema lives at `apps/api/prisma/schema.prisma`. This doc explains each
table in plain language — read this instead of the schema file if you just
need to know what data exists and how it connects.

| Table | Purpose | Connects to | Status |
|---|---|---|---|
| `User` | One row per account: email, hashed password, plan, timestamps | Everything below hangs off `userId` | live |
| `InterviewSession` | One row per mock-interview attempt: role, company, status, score, JSON feedback string | `User`, `InterviewMessage` | live |
| `InterviewMessage` | One row per question/answer turn inside a session, in order | `InterviewSession` | live |
| `Resume` | Resume text (pasted, not uploaded — see below) plus its general feedback | `User` | live |
| `QuestionBankItem` | A single practice question tagged by role/company/topic/category — shared across all users, not private | standalone | live |
| `MeetingSession` | One row per Meeting Assistant session: title, optional context notes, active/ended status | `User`, `MeetingTurn` | live |
| `MeetingTurn` | One row per transcribed utterance ("OTHER") or logged thing the user said ("ME"), in order | `MeetingSession` | live |

`InterviewSession.feedback` and `Resume.latestFeedback` both store the same
raw JSON string shape, `{ score, strengths, improvements }` — parsed by
the shared `apps/api/src/ai/feedback-parser.ts` on the backend and
`apps/web/lib/parse-feedback.ts` on the frontend. See
`apps/api/src/interviews/interview-prompts.ts` /
`apps/api/src/resumes/resume-prompts.ts` for the exact prompts that
produce it.

## Why `Resume.fileUrl` is nullable and unused right now

The original schema design assumed file upload (PDF/DOCX) with the file
stored in object storage and `fileUrl` pointing at it. Building real file
upload + parsing + S3-compatible storage is a substantial addition on its
own, so Phase 2 shipped with a smaller, still-genuinely-useful scope
first: paste your resume as text, get feedback immediately — the same
"simplest version first" call the interview engine made by launching
text-only before voice. `content` holds that pasted text. `fileUrl` stays
in the schema, nullable, for when real file upload is added — at that
point `content` (the extracted text) keeps working exactly as it does
today; only a new upload path needs building, not a schema migration that
reshapes existing rows.

## Why `QuestionBankItem` has no `userId`

Every other table in this schema is private per-user. `QuestionBankItem`
is deliberately different: it's a shared, growing resource — anyone's
generated questions become visible to everyone, the same way a public
wiki page isn't owned by whoever last edited it. This means the API
routes still require login (to stop unauthenticated abuse of the
AI-generation endpoint, which costs real money per call), but the data
itself isn't filtered by who created it. If a future need arises for
private, per-user question lists (e.g. "questions I've saved"), that's an
argument for a new join table, not for retrofitting `userId` onto this
one and breaking the shared-bank model.

## Why real semantic/vector search isn't built yet

The original architecture plan called for a vector store (pgvector) so
users could search "questions like this one" by meaning, not just exact
role/company/topic match. Building that requires an embeddings API,
which is a different capability than the text-completion `AiProvider`
interface this app is built around (see `apps/api/src/ai/providers/`) —
none of Anthropic, Google, or an OpenAI-compatible endpoint necessarily
expose embeddings through the same interface a chat completion does,
and adding it properly means extending `AiProvider` with a second
method, which is real design work best done deliberately rather than
bolted on here. Phase 3 shipped with simple SQL `contains` filtering on
role/company/topic instead — genuinely useful today, and doesn't block
adding real semantic search later; it would live alongside the current
filters, not replace them.

## Why tailoring and cover letter results aren't stored

A tailoring result and a generated cover letter are both specific to one
job description, not a general property of the resume. Persisting them
would mean either one row per (resume, job description) pair — schema
complexity with no user-facing feature asking for a history of past
tailoring attempts — or overwriting a single field and silently losing
the previous result. Neither seemed better than the resume equivalent of
`InterviewSession.feedback`, so for now they're computed fresh on each
request and returned directly, not persisted. Revisit this if/when users
actually want to revisit past tailoring results.

## Meeting Assistant: why it's not just a renamed InterviewSession

`MeetingSession`/`MeetingTurn` look structurally similar to
`InterviewSession`/`InterviewMessage` — both are a session with ordered
turns tied to a user. They're separate models, not a shared/rebranded
one, for a specific reason: an interview session has a defined end state
(scored feedback) and a defined purpose (practice, assessed by the AI
itself). A meeting session has neither — there's no score, no "correct"
answer, and its purpose is entirely defined by whatever the user is
actually on a call about. Collapsing them into one model would either
force meeting sessions to have a meaningless score field, or force
interview sessions to lose theirs. Keeping them separate also makes the
boundary between the two features structurally visible in the schema,
not just in code comments: a `MeetingSession` cannot accidentally end up
reachable from interview-scoring logic, or vice versa.

Two more choices worth being explicit about, since this module's
existence follows directly from a boundary set earlier in this
project's history (see `apps/api/src/meeting-assistant/meeting-prompts.ts`'s
top comment for the full context):

- `AiProvider.complete()` is asked, in the system prompt itself (not
  just the UI), to decline generating a scripted answer if the
  transcript looks like it's from a hiring interview, exam, or
  certification rather than the user's own work call. This is a
  content-level safeguard, not just an access-control one — see
  `buildSuggestSystemPrompt()` in `meeting-prompts.ts`.
- Nothing in this schema, or anywhere in `apps/web`'s Meeting Assistant
  UI, supports hiding a session's existence or its "active" indicator
  from anyone. There's no field for it, and there shouldn't be one added
  later without a real conversation about why.

## Why most tables exist before their features do

Designing the schema once, up front, means Phase 1–3 don't require
migrations that reshape data created by earlier phases. Only `User` is
actually read/written today — the rest are defined so the shape is
settled and reviewable now, not discovered mid-build.

## Making a schema change

1. Edit `apps/api/prisma/schema.prisma`
2. Run `npm run --workspace=apps/api prisma:migrate -- --name describe_your_change`
3. Update the table above if you added/removed a table or changed its purpose
4. If you changed a table another module already reads (see
   `docs/CHANGE-GUIDE.md`), update that module's tests too
