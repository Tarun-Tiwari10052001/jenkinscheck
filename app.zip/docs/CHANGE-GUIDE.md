# Change guide

Read this before editing anything. It tells you, in plain language, what
each part of the codebase is responsible for, which files it lives in, and
what else in the system could be affected if you change it — so you can
plan an edit without opening the code first.

Status key: `live` = working and tested today. `scaffolded` = folder/module
exists as a placeholder for a future phase, not yet implemented.

| Module | Status | What it does | Files | If you change it, this could be affected | Safe to change alone? |
|---|---|---|---|---|---|
| Auth | live | Register, login, password hashing, JWT issuing/verification | `apps/api/src/auth/**` | Anything behind `@UseGuards(JwtAuthGuard)` — i.e. every future protected route (interviews, resumes, dashboard data). Changing the JWT payload shape breaks any code reading `req.user`. | Yes, if you keep the public method signatures (`register()`, `login()`, `validateUser()`) the same. Changing what they return is not safe alone. |
| Users | live | User profile data, plan/subscription flag | `apps/api/src/users/**` | Auth (looks up users to check passwords), and later Billing/Stripe once it's built | Yes — it only exposes `findByEmail`, `create`, `findById`. Add fields freely; don't rename existing ones without updating Auth. |
| Database schema | live (partial) | Defines every table: users, interview sessions, messages, resumes, question bank | `apps/api/prisma/schema.prisma` | Everything. This is the single source of truth for the data layer — every module's tables live here. Renaming or removing a column requires a migration and touches whichever service reads that table. | Adding a new table or a new optional column: yes. Renaming/removing an existing column: no, coordinate with whoever owns that module first. |
| Web — login/signup pages | live | Forms that call the Auth API and store the returned token | `apps/web/app/login`, `apps/web/app/signup` | The dashboard's auth check and every other protected page (all read the same stored token) | Yes |
| Web — dashboard | live | Lists the user's past interviews and resumes, links to start each, links to the question bank | `apps/web/app/dashboard/page.tsx` | Nothing else yet | Yes |
| Web — interview flow | live | `interview/new` starts a session; `interview/[id]` is the chat UI, submits answers, ends the interview, shows parsed feedback. Also drives voice mode (questions read aloud, answers dictated) via `lib/speech.ts`. | `apps/web/app/interview/**`, `components/start-interview-form.tsx`, `components/interview-chat.tsx`, `lib/parse-feedback.ts` | Calls the Interview engine's API endpoints. Nothing else depends on it. | Yes — the page files are thin wrappers; almost all logic lives in the two components above, which have their own tests. |
| Voice mode (`lib/speech.ts`) | live | Wraps the browser's native Web Speech API — dictation and text-to-speech — for `interview-chat.tsx`. No API key, no backend involvement; a dictated answer becomes plain text through the same endpoint typing uses. | `apps/web/lib/speech.ts`, `apps/web/lib/speech.d.ts` | Only `interview-chat.tsx` calls this today. | Yes — exposes `isSpeechRecognitionSupported`, `isSpeechSynthesisSupported`, `createSpeechRecognition`, `speak`, `cancelSpeech`. Swapping in a paid vendor API later means changing only this file's internals (and adding a backend endpoint, since a vendor key can't live in the browser) — `interview-chat.tsx` wouldn't need to change. See "Why voice mode uses the browser's Web Speech API" in `ARCHITECTURE.md`. |
| Interview engine | live | Runs the AI mock interview: opening question, follow-ups based on the candidate's answers, and a scored JSON feedback report at the end | `apps/api/src/interviews/**` | Calls the AI provider layer (see below) and the `InterviewSession`/`InterviewMessage` tables. The web interview flow above depends on its API shape. | Yes — it only exposes `startSession`, `submitAnswer`, `completeSession`, `getSession`, `listSessions`. Prompt wording lives entirely in `interview-prompts.ts`; tune it there without touching the service. Changing the response shape of any method means updating `apps/web/lib/api-client.ts` too. |
| AI provider layer | live | Talks to whichever AI vendor is configured (Anthropic, Google Gemini, or any OpenAI-compatible API) behind one shared interface | `apps/api/src/ai/**` | Any module that calls the AI provider — currently Interviews, Resumes, and Questions, later the Live copilot | Yes. Adding a new vendor means adding one file in `ai/providers/` that implements `AiProvider`, plus a case in `ai-provider.factory.ts` — nothing that calls `.complete()` needs to change. Changing what `.complete()` returns means updating every caller. |
| Resume tools | live | Paste-text resume feedback (score/strengths/improvements), tailoring against a specific job description, and cover letter generation | `apps/api/src/resumes/**` | Calls the AI provider layer and the `Resume` table. The web resume flow depends on its API shape. | Yes — it only exposes `create`, `listResumes`, `getResume`, `remove`, `tailor`, `generateCoverLetter`. Prompt wording lives entirely in `resume-prompts.ts`. `tailor()` and `generateCoverLetter()` deliberately don't write to the database — see `docs/DATABASE.md`. |
| Feedback parser (shared) | live | Defensively parses the `{score, strengths, improvements}` JSON shape both the interview engine and resume tools ask the AI provider for | `apps/api/src/ai/feedback-parser.ts` | Both `interview-prompts.ts` (re-exports it) and `resumes.service.ts` (imports it directly) | Yes, as long as the shape stays `{score, strengths, improvements}`. Both `apps/web/lib/parse-feedback.ts` (frontend) and this file must be changed together if the shape changes. |
| Web — resume flow | live | `resume/new` pastes resume text and gets feedback; `resume/[id]` shows feedback, the job-tailoring tool, cover letter generation, and delete | `apps/web/app/resume/**`, `components/resume-upload-form.tsx`, `components/resume-detail.tsx` | Calls the Resume tools' API endpoints. Dashboard also calls `resumesApi.list()`. | Yes — thin pages, logic lives in the two components, which have their own tests. |
| Question bank | live | Shared, AI-generated practice questions tagged by role/company/topic/category; browsable and filterable | `apps/api/src/questions/**` | Calls the AI provider layer. Not scoped to a user — see `docs/DATABASE.md` for why. Every route still requires login (abuse prevention on the generation endpoint), even though the data itself is shared. | Yes — exposes `generate`, `list`, `filters`. Category set lives in `question-prompts.ts`'s `QUESTION_CATEGORIES` and is duplicated (not imported) in `apps/web/lib/question-categories.ts` — update both if it changes. |
| Web — question bank | live | `questions` page: generate new questions for a role, browse/filter the shared bank | `apps/web/app/questions/page.tsx`, `components/question-bank.tsx` | Calls the Question bank's API endpoints | Yes — thin page, logic lives in the one component, which has its own tests. |
| Meeting Assistant | live | Real-time, transparent assistance during the user's own work calls (sales, support, internal meetings) — suggests responses grounded in call context, never auto-sent or auto-spoken. Deliberately **not** for hiring interviews or any assessment of the user's own unaided ability — enforced in the system prompt itself, not just the UI. Sessions are private per-user, never scoped to hide activity from other call participants. | `apps/api/src/meeting-assistant/**` | Calls the AI provider layer and the `MeetingSession`/`MeetingTurn` tables. Nothing else depends on it. | Yes — exposes `startSession`, `suggest`, `logTurn`, `endSession`, `getSession`, `listSessions`, `remove`. Prompt wording (including the scope boundary) lives entirely in `meeting-prompts.ts`. **If you're changing this module, read the boundary note in `meeting-prompts.ts` and this row before loosening what the assistant will suggest for — this module exists specifically because a differently-scoped version of it was declined.** |
| Web — Meeting Assistant | live | `assistant/new` starts a session (with a built-in consent/visibility reminder); `assistant/[id]` is the live session UI — persistent visible "active" indicator, voice or typed input, AI suggestion display, session end | `apps/web/app/assistant/**`, `components/start-meeting-form.tsx`, `components/meeting-assistant.tsx` | Calls the Meeting Assistant's API endpoints. Dashboard also calls `meetingAssistantApi.list()`. | Yes — thin pages, logic lives in the two components, which have their own tests. **Do not** add any code that hides the "active" indicator, excludes it from screen capture, or otherwise makes the assistant's use undetectable to other call participants — see the note above. |
| Desktop app | live | Electron shell wrapping `apps/web` unchanged in a native window; spawns a bundled Next.js server in packaged builds | `apps/desktop/**` | Nothing else depends on it. It depends on `apps/web`'s `output: 'standalone'` build and directory structure — see `apps/desktop/README.md`. | Yes, for `resolve-app-url.ts` / `wait-for-server.ts` (both unit tested). `main.ts`/`preload.ts` are Electron shell code without unit tests — see the "How this was actually verified" section in `apps/desktop/README.md` before assuming a change there is safe just because `npm test` passes. |
| Live copilot | scaffolded, Phase 5 | Real-time answer suggestions during a live interview | `apps/api/src/copilot/**` (folder only) | Isolated by design — kept as its own module with its own review, see `ARCHITECTURE.md` | N/A yet |

## Rule of thumb

If your change is inside one module's folder and you didn't have to touch
another module's files to make it compile, it's a safe, isolated change.
If you find yourself editing two modules' folders for one change, stop and
check this table first — it usually means the boundary between them needs
a shared interface instead of a direct edit.

## Where to look for X

- "Why did my login fail" → `apps/api/src/auth/auth.service.ts`, then check
  `apps/api/src/auth/auth.service.spec.ts` for the exact expected behavior
- "Why did the interviewer ask a weird/off-topic question" → the model
  itself, not a bug you can fix in code — but check
  `apps/api/src/interviews/interview-prompts.ts` first, since a vague or
  contradictory prompt is the most common cause
- "How do I change what the interviewer asks or how feedback is scored" →
  `apps/api/src/interviews/interview-prompts.ts` only — the service layer
  doesn't need to change
- "What columns does a user have" → `docs/DATABASE.md`
- "How do I add a new protected page" → copy the pattern in
  `apps/web/app/dashboard/page.tsx`, wrap it with the same auth check
- "How do I change what the interview chat page looks like or does" →
  `apps/web/components/interview-chat.tsx` only — the page file
  (`apps/web/app/interview/[id]/page.tsx`) is just a wrapper
- "How do I add a new authenticated API call from the frontend" → add it
  to `apps/web/lib/api-client.ts` with `{ auth: true }`, following the
  pattern of `interviewsApi`. Never call `fetch` directly from a component.
- "How do I change resume feedback wording, tailoring behavior, or cover
  letter tone" → `apps/api/src/resumes/resume-prompts.ts` only
- "Why isn't my tailoring result or cover letter saved anywhere" → by
  design — see the Resume tools row above and `docs/DATABASE.md`
- "How do I change the question categories" → update
  `QUESTION_CATEGORIES` in `apps/api/src/questions/question-prompts.ts`
  AND `apps/web/lib/question-categories.ts` — they're deliberately
  duplicated, not shared, since frontend and backend are separate
  deployables
- "Why can any user see questions another user generated" → by design —
  the question bank is a shared resource, not private data. See
  `docs/DATABASE.md`.
- "How do I change what the desktop app's window looks like (size, menu,
  title)" → `apps/desktop/src/main.ts` — the `BrowserWindow` constructor
  options and `buildMenu()`
- "Why does the desktop app show a blank/error screen" → most likely the
  API or web dev server isn't running (dev mode) or the bundled server
  failed to start (packaged mode) — check `wait-for-server.ts`'s timeout
  and `main.ts`'s error fallback page first
- "Why doesn't the mic button show up / voice mode isn't dictating" →
  check the browser first (Chrome/Edge only — see `apps/web/README.md`
  "Voice mode browser support") before assuming it's a bug; the button
  is deliberately hidden, not broken, in unsupported browsers
- "How do I change what voice mode says or how it behaves" →
  `apps/web/lib/speech.ts` for the speech API wrapper itself,
  `apps/web/components/interview-chat.tsx` for when it speaks/listens
- "How do I change what the Meeting Assistant suggests, or its tone" →
  `apps/api/src/meeting-assistant/meeting-prompts.ts` only — but read the
  scope-boundary comment at the top of that file first; the system prompt
  is what stops it being repurposed for hiring interviews or exams, not
  just documentation
- "Why won't the Meeting Assistant give a scripted answer for what sounds
  like an interview or exam question" → by design, enforced in
  `buildSuggestSystemPrompt()` — this is not a bug to work around
- "How do I add a new API endpoint" → copy the pattern in
  `apps/api/src/auth/auth.controller.ts` (controller → service → test)
- "How do I call the AI provider from a new module" → inject the
  `AI_PROVIDER` token from `apps/api/src/ai/providers/ai-provider.interface.ts`
  (typed as `AiProvider`), call `.complete()`. Never import a vendor SDK
  (Anthropic, `@google/genai`, etc.) directly in a feature module.
- "How do I switch which AI vendor is used, or add a new one" →
  switching: set `AI_PROVIDER` in `.env` to `anthropic`, `google`, or
  `openai`, plus that vendor's API key — no code change needed. Adding a
  new vendor: see the `AI provider layer` row above.
