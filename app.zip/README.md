# AI Practice Platform

An all-in-one practice product: AI mock interviews (text and
voice), resume/cover letter tools, a question bank, a transparent
real-time Meeting Assistant for the user's own work calls, and a desktop
app — see `apps/desktop/README.md`. See `ARCHITECTURE.md` for the system
diagram and `docs/CHANGE-GUIDE.md` before editing anything — it tells you
what each part of the codebase does and what breaks if you touch it,
without reading code.

## What's built so far (Phase 0 + Phase 1 + Phase 2 + Phase 3 + Phase 4)

- Monorepo with an `apps/api` (NestJS) backend and `apps/web` (Next.js) frontend
- Postgres schema (Prisma) covering users, interview sessions, resumes, and
  the question bank — resumes/question bank are still schema-only, see
  `docs/DATABASE.md` for exact status per table
- Working auth: register, login, JWT-protected routes, password hashing
- A working AI mock interview engine: start a session for a role/company,
  answer follow-up questions in a real back-and-forth, then get scored
  feedback (strengths/improvements) at the end — see `apps/api/src/interviews`
- Works with Claude, Gemini, or any OpenAI-compatible API (OpenAI, Groq,
  DeepSeek, a local Ollama server, etc.) — pick one via `AI_PROVIDER` in
  `.env`, no code changes needed. See `apps/api/src/ai` and
  `apps/api/README.md`.
- A full web UI for the interview flow: a dashboard listing past
  interviews, a "start a mock interview" form, and a chat page that walks
  through the whole session and shows feedback at the end — see
  `apps/web/app/interview` and `apps/web/components/interview-chat.tsx`
- Voice mode for interviews: questions read aloud, answers dictated —
  built on the browser's native Web Speech API, not a paid vendor, so it
  needs no API key and no backend change. See `apps/web/lib/speech.ts`
  and "Why voice mode uses the browser's Web Speech API" in
  `ARCHITECTURE.md` for what that trades off (Chrome/Edge only for
  dictation; the app still works fully text-only everywhere else).
- Resume tools: paste your resume text and get scored feedback, tailor it
  against a specific job description (match score + missing keywords),
  and generate a cover letter — see `apps/api/src/resumes` and
  `apps/web/app/resume`. MVP accepts pasted text, not file upload — see
  `docs/DATABASE.md` for why.
- A shared, growing question bank: generate practice questions for any
  role/company/topic (AI-tagged by category), browse and filter what
  exists — see `apps/api/src/questions` and `apps/web/app/questions`.
  Filtering is exact/`contains` text matching, not semantic search — see
  `docs/DATABASE.md` for why real vector search isn't built yet.
- A desktop app (`apps/desktop`, Electron) wrapping the same web
  frontend unchanged — see `apps/desktop/README.md`, including exactly
  what was and wasn't possible to verify without a real display.
- A Meeting Assistant for the user's own work calls (sales, support,
  internal meetings): transcribe what the other person said (by mic or
  typed), get an AI-suggested response grounded in call context, shown
  only on the user's own screen with a persistent visible "active"
  indicator. See `apps/api/src/meeting-assistant`,
  `apps/web/app/assistant`, and the "Meeting Assistant" section of
  `ARCHITECTURE.md` for the deliberate boundary this was built inside —
  including in the AI's own system prompt, not just the UI.
- Unit + e2e tests for everything above

## Still to build for a complete Phase 2 + Phase 3 + Phase 4

Real file upload (PDF/DOCX) with parsing and object storage isn't built
for resumes either — Phase 2 shipped with paste-text-only first, the same
"simplest version first" call. See `docs/DATABASE.md` ("Why
`Resume.fileUrl` is nullable") for the plan to add it without a schema
rewrite.

Semantic/vector search on the question bank isn't built — needs an
embeddings API, which the current `AiProvider` interface doesn't expose
(it's built around text completion). See `docs/DATABASE.md` ("Why real
semantic/vector search isn't built yet").

The desktop app hasn't been packaged and run on a real machine yet — see
`apps/desktop/README.md` for exactly what was verified (real headless
launch, real standalone-server test) versus what still needs a machine
with a display (the packaged installer, visual QA).

## Requirements

- Node.js 20+
- Docker (for local Postgres) — or point `DATABASE_URL` at your own Postgres

## Quick start

```bash
# 1. install everything (root + both workspaces)
npm install

# 2. start local Postgres
docker compose up -d

# 3. configure the API
cp apps/api/.env.example apps/api/.env
# then edit apps/api/.env: set AI_PROVIDER (anthropic/google/openai) and
# that provider's API key — required for the interview endpoints to work.
# See apps/api/README.md "Choosing an AI provider" for the full list.

# 4. create the database tables
npm run --workspace=apps/api prisma:migrate

# 5. run both apps (in separate terminals)
npm run dev:api      # http://localhost:3001
npm run dev:web      # http://localhost:3000
```

To run the desktop shell instead of/alongside the browser, start
`dev:api` and `dev:web` as above, then see `apps/desktop/README.md` for
`npm run dev:desktop`.

## Running tests

```bash
npm test             # everything
npm run test:api     # backend unit + e2e tests
npm run test:web     # frontend component tests
npm run test:desktop # desktop shell's testable logic (see apps/desktop/README.md
                      # for what unit tests do and don't cover for GUI code)
```

Every module that ships in this repo ships with tests in the same PR/commit
— see `docs/TESTING.md` for the convention and where each type of test
lives.

## Repo layout

```
apps/
  api/       NestJS backend — see apps/api/README.md
  web/       Next.js frontend — see apps/web/README.md
  desktop/   Electron shell wrapping the web app — see apps/desktop/README.md
docs/
  CHANGE-GUIDE.md   what each module does, what changes to it affect
  DATABASE.md       schema walkthrough, table by table
  TESTING.md        testing conventions and how to run each suite
ARCHITECTURE.md      system diagram + how the pieces fit together
```

